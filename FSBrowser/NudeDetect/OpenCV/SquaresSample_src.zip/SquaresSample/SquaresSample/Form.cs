//*******************************************************************
// File name: $ Form.cs $
// Author:		$ Heiko Kie�ling, (c) iib-chemnitz.de $
// Email:			info@iib-chemnitz.de
// 
// License:		There is no explicit license attached. The code is
//						provided 'as is'. Feel free to use the code how you like 
//						but without any warranty.
//						If you include the code in your own projects and/or
//						redistribute pls. include this header.
//
// Purpose:		Demonstration of using the cvlib with the square.
//						In difference to the original demo implementation
//						it uses a graphic window for switching modes insted of
//						keys. Theres no explicit exeption handling implemented.
//						For example, if there are no dll's found, the application
//						will crash. But if an internal OpencV Error occures the
//						OnError Method sould be invoked (i still did not test it). 
//						To capture frames, a timer control
//						has been used (look for Timer_Tick event).
// History:		Rev. 1.0 (beta), hki - initial revision
//*******************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using openCV;
using System.Runtime.InteropServices;

namespace SquaresSample
{

	/// <summary>
	/// MainWindow class
	/// </summary>
	public partial class ControlWindow : Form
	{
		/// <summary>
		/// Image definitions
		/// </summary>
		private IplImage img;
		private IplImage img0;

		/// <summary>
		/// member used by the squares demo
		/// </summary>
		int thresh = 50;
		CvMemStorage storage;
		string wndname = "Square Detection Demo";
		//string[] names = {"sheet.jpg", "pic2.png", "pic3.png",
		//                  "pic4.png", "pic5.png", "pic6.png"};
		string[] names = {"sheet.jpg"};

		/// <summary>
		/// Initializes a new instance of the <see cref="Form"/> class.
		/// </summary>
		public ControlWindow()
		{
			// windows form desinger generated code
			InitializeComponent();
		}	

		/// <summary>
		/// Handles the Click event of the exit button.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void Exit_Click(object sender, EventArgs e)
		{
			// close this form (Form_FormClosed will be invoked)
			this.Close();
		}

		private double Angle(CvPoint pt1, CvPoint pt2, CvPoint pt0)
		{
			double dx1 = pt1.x - pt0.x;
			double dy1 = pt1.y - pt0.y;
			double dx2 = pt2.x - pt0.x;
			double dy2 = pt2.y - pt0.y;
			return (dx1 * dx2 + dy1 * dy2) / Math.Sqrt((dx1 * dx1 + dy1 * dy1) * (dx2 * dx2 + dy2 * dy2) + 1e-10);
		}

		private double CvContourPerimeter( IntPtr curve ) {
			return cvlib.CvArcLength(curve, cvlib.CV_WHOLE_SEQ, 1);
		}

		private CvSeq findSquares4(IplImage img, CvMemStorage storage)
		{
			CvSeq contours = new CvSeq();
			int i, c, l, N = 11;
			CvSize sz = new CvSize(img.width & -2, img.height & -2);
			IplImage timg = cvlib.CvCloneImage(ref img); // make a copy of input image
			IplImage gray = cvlib.CvCreateImage(sz, 8, 1);
			IplImage pyr = cvlib.CvCreateImage(new CvSize(sz.width / 2, sz.height / 2), 8, 3);
			IplImage tgray;
			CvSeq result;
			double s, t;

			// create empty sequence that will contain points -
			// 4 points per square (the square's vertices)
			CvSeq squares = cvlib.CvCreateSeq(0, Marshal.SizeOf(typeof(CvSeq)), Marshal.SizeOf(typeof(CvPoint)), ref storage);

			// select the maximum ROI in the image
			// with the width and height divisible by 2
			cvlib.CvSetImageROI(ref timg, new CvRect(0, 0, sz.width, sz.height));

			// down-scale and upscale the image to filter out the noise
			//cvlib.CvPyrDown(ref timg, ref pyr, 7);
			//cvlib.CvPyrUp(ref pyr, ref timg, 7);
			tgray = cvlib.CvCreateImage(sz, 8, 1);
			//cvlib.CvShowImage(wndname, ref tgray);

			// find squares in every color plane of the image
			for (c = 0; c < 3; c++)
			{
				// extract the c-th color plane
				cvlib.CvSetImageCOI(ref timg, c + 1);
				cvlib.CvCopy(ref timg, ref tgray);
				
				// try several threshold levels
				for (l = 0; l < N; l++)
				{
				  // hack: use Canny instead of zero threshold level.
				  // Canny helps to catch squares with gradient shading   
				  if (l == 0)
				  {
				    // apply Canny. Take the upper threshold from slider
				    // and set the lower to 0 (which forces edges merging) 
				    cvlib.CvCanny(ref tgray, ref gray, 0, thresh, 5);
				    // dilate canny output to remove potential
				    // holes between edge segments 
				    // create mask
				    // create kernel
				    IplConvKernel k = cvlib.CvCreateStructuringElementEx(3, 3, 1, 1, cvlib.CV_SHAPE_RECT, null);
				    cvlib.CvDilate(ref gray, ref gray, ref k, 1);
				  }
				  else
				  {
				    // apply threshold if l!=0:
				    //     tgray(x,y) = gray(x,y) < (l+1)*255/N ? 255 : 0
				    cvlib.CvThreshold(ref tgray, ref gray, (l + 1) * 255 / N, 255, cvlib.CV_THRESH_BINARY);
					}

					// find contours and store them all as a list
					GCHandle h;
					IntPtr p = cvtools.ConvertStructureToPtr(contours, out h);
					cvlib.CvFindContours(ref gray, ref storage, ref p, Marshal.SizeOf(typeof(CvContour)),
							cvlib.CV_RETR_LIST, cvlib.CV_CHAIN_APPROX_SIMPLE, new CvPoint(0, 0));

				  // test each contour
				  while (p != IntPtr.Zero)
				  {
						// approximate contour with accuracy proportional
						// to the contour perimeter
						result = cvlib.CvApproxPoly(p, Marshal.SizeOf(typeof(CvContour)), ref storage,
								cvlib.CV_POLY_APPROX_DP, CvContourPerimeter(p) * 0.02, 0);
						
						 //square contours should have 4 vertices after approximation
						 //relatively large area (to filter out noisy contours)
						 //and be convex.
						 //Note: absolute value of an area is used because
						 //area may be positive or negative - in accordance with the
						 //contour orientation
				    if ((result.total == 4) &&
				        (Math.Abs(cvlib.CvContourArea(ref result, cvlib.CV_WHOLE_SEQ)) > 100) &&
								(Math.Abs(cvlib.CvContourArea(ref result, cvlib.CV_WHOLE_SEQ)) < 500) &&
				        (cvlib.CvCheckContourConvexity(ref result) > 0))
				    {
				      s = 0;

				      for (i = 0; i < 5; i++)
				      {
				        // find minimum angle between joint
				        // edges (maximum of cosine)
				        if (i >= 2)
				        {
				          t = Math.Abs(Angle(
				          (CvPoint)cvtools.ConvertPtrToStructure(cvlib.CvGetSeqElem(ref result, i), typeof(CvPoint)),
				          (CvPoint)cvtools.ConvertPtrToStructure(cvlib.CvGetSeqElem(ref result, i - 2), typeof(CvPoint)),
				          (CvPoint)cvtools.ConvertPtrToStructure(cvlib.CvGetSeqElem(ref result, i - 1), typeof(CvPoint))));
				          s = s > t ? s : t;
				        }
				      }

				      // if cosines of all angles are small
				      // (all angles are ~90 degree) then write quandrange
				      // vertices to resultant sequence 
							if (s < 0.3)
							{
								int xmax, xmin, ymax, ymin;

								// check for quandrangularity
								CvPoint p1 = (CvPoint)cvtools.ConvertPtrToStructure(cvlib.CvGetSeqElem(ref result, 0), typeof(CvPoint));
								CvPoint p2 = (CvPoint)cvtools.ConvertPtrToStructure(cvlib.CvGetSeqElem(ref result, 1), typeof(CvPoint));
								CvPoint p3 = (CvPoint)cvtools.ConvertPtrToStructure(cvlib.CvGetSeqElem(ref result, 2), typeof(CvPoint));
								CvPoint p4 = (CvPoint)cvtools.ConvertPtrToStructure(cvlib.CvGetSeqElem(ref result, 3), typeof(CvPoint));
								if (p1.x > p2.x) { xmax = p1.x; } else xmax = p2.x;
								if (p3.x > xmax) xmax = p3.x;
								if (p4.x > xmax) xmax = p4.x;
								if (p1.x < p2.x) { xmin = p1.x; } else xmin = p2.x;
								if (p3.x < xmin) xmin = p3.x;
								if (p4.x < xmin) xmin = p4.x;
								if (p1.y > p2.y) { ymax = p1.y; } else ymax = p2.y;
								if (p3.y > ymax) ymax = p3.y;
								if (p4.y > ymax) ymax = p4.y;
								if (p1.y < p2.y) { ymin = p1.y; } else ymin = p2.y;
								if (p3.y < ymin) ymin = p3.y;
								if (p4.y < ymin) ymin = p4.y;

								double fac = (double)(xmax - xmin) / (double)(ymax - ymin);
								if (fac > 0.9 && fac < 1.1)
								{
									for (i = 0; i < 4; i++)
										cvlib.CvSeqPush(ref squares, cvlib.CvGetSeqElem(ref result, i));
								}
							}
				    }

						contours = (CvSeq)cvtools.ConvertPtrToStructure(p, typeof(CvSeq));
						p = contours.h_next;
					}
				  cvtools.ReleaseHandel(h);
				}
			}

			// release all the temporary images
			cvlib.CvReleaseImage(ref gray);
			cvlib.CvReleaseImage(ref pyr);
			cvlib.CvReleaseImage(ref tgray);
			cvlib.CvReleaseImage(ref timg);

			return squares;
		}

		private void drawSquares(IplImage img, CvSeq squares)
		{
			CvSeqReader reader = new CvSeqReader();
			IplImage cpy = cvlib.CvCloneImage(ref img );
			int i;
    
			// initialize reader of the sequence
			cvlib.CvStartReadSeq( ref squares, ref reader, 0 );
    
			// read 4 sequence elements at a time (all vertices of a square)
			for( i = 0; i < squares.total; i += 4 )
			{
				CvPoint[] pt = new CvPoint[4];
				CvPoint[] rect = pt;
        int count = 4;
        
        // read 4 vertices
				cvlib.CV_READ_SEQ_ELEM(ref pt[0], ref reader);
				cvlib.CV_READ_SEQ_ELEM(ref pt[1], ref reader);
				cvlib.CV_READ_SEQ_ELEM(ref pt[2], ref reader);
				cvlib.CV_READ_SEQ_ELEM(ref pt[3], ref reader);
        
        // draw the square as a closed polyline
        cvlib.CvPolyLine(ref cpy, ref rect, ref count, 1, 1, cvlib.CV_RGB(0,255,0), 1, cvlib.CV_AA, 0 );
			}
    
			// show the resultant image
			cvlib.CvShowImage( wndname, ref cpy );
			cvlib.CvSaveImage("res.png", ref cpy);
			cvlib.CvReleaseImage( ref cpy );
		}

		private void buttonRun_Click(object sender, EventArgs e)
		{
			int i, c;
			// create memory storage that will contain all the dynamic data
			storage = cvlib.CvCreateMemStorage(0);

			for (i = 0; i < names.Length; i++)
			{
				// load i-th image
				img0 = cvlib.CvLoadImage(names[i], 1);
				
				if (img0.ptr == IntPtr.Zero)
				{
					MessageBox.Show("Couldn't load: " + names[i]);
					continue;
				}
				img = cvlib.CvCloneImage(ref img0);

				// create window and a trackbar (slider) with parent "image" and set callback
				// (the slider regulates upper threshold, passed to Canny edge detector) 
				cvlib.CvNamedWindow(wndname, 1);

				// find and draw the squares
				//drawSquares(img, findSquares4(img, storage));
				drawSquares(img, findSquares4(img, storage));

				// wait for key.
				// Also the function cvWaitKey takes care of event processing
				c = cvlib.CvWaitKey(0);
				
				// release both images
				cvlib.CvReleaseImage(ref img);
				cvlib.CvReleaseImage(ref img0);

				// clear memory storage - reset free space position
				cvlib.CvClearMemStorage(ref storage);
				if ((char)c == 27)
					break;
			}

			cvlib.CvDestroyWindow(wndname);
		}
	}
}