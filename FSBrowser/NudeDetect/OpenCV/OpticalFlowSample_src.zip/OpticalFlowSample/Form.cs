//*******************************************************************
// File name: $ Form.cs $
// Author:		$ Heiko Kie�ling, (c) iib-chemnitz.de $
// Email:			info@iib-chemnitz.de
// 
// License:		There is no explicit license attached. The code is
//						provided 'as is'. Feel free to use the code how you like 
//						but without any warranty.
//						If you include the code in your own projects and/or
//						redistribute pls. include this header.
//
// Purpose:		Demonstration of using the cvlib with the lkdemo.
//						In difference to the original demo implementation
//						it uses a graphic window for switching modes insted of
//						keys. Theres no explicit exeption handling implemented.
//						For example, if there are no dll's found, the application
//						will crash. But if an internal OpencV Error occures the
//						OnError Method sould be invoked (i still did not test it). 
//						To capture frames, a timer control
//						has been used (look for Timer_Tick event).
// History:		Rev. 1.0 (beta), hki - initial revision
//*******************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using openCV;
using System.Runtime.InteropServices;

namespace SmallSample
{

	/// <summary>
	/// MainWindow class
	/// </summary>
	public partial class ControlWindow : Form
	{
		/// <summary>
		/// Image definitions
		/// </summary>
		private IplImage image; 
		private IplImage grey;
		private IplImage prev_grey; 
		private IplImage pyramid; 
		private IplImage prev_pyramid;
		private IplImage swap_temp;

		/// <summary>
		/// member used by the lk demo
		/// </summary>
		private int win_size;
		private int MAX_COUNT;
		private CvPoint2D32f[][] points;
		private CvPoint2D32f[] swap_points;
		private byte[] status;
		private int count;
		private int need_to_init;
		private int night_mode;
		private int flags;
		private int add_remove_pt;
		private CvPoint pt;
		private CvCapture capture;

		/// <summary>
		/// Delegate for Mouse events
		/// </summary>
		private cvlib.OnMouseCallback onMouse;

		/// <summary>
		/// Delegate for error event
		/// </summary>
		private cvlib.OnErrorCallback onError;

		/// <summary>
		/// Initializes a new instance of the <see cref="Form1"/> class.
		/// </summary>
		public ControlWindow()
		{
			// windows form desinger generated code
			InitializeComponent();

			// member init
			points = new CvPoint2D32f[2][];
			win_size = 10;
			MAX_COUNT = 500;

			count = 0;
			need_to_init = 0;
			night_mode = 0;
			flags = 0;
			add_remove_pt = 0;

			// instantiate callbacks
			onMouse = new cvlib.OnMouseCallback(OnMouse);
			onError = new cvlib.OnErrorCallback(OnError);

			// set our Erro mode to Parent (call error handler, but dont quit)
			cvlib.CvSetErrMode(cvlib.CV_ErrModeParent);

			// set error event handler callback method
			cvlib.CvRedirectError(onError);

			// create output window
			cvlib.CvNamedWindow("LkDemo", cvlib.CV_WINDOW_AUTOSIZE);

			// set mouse event handler callback method  
			cvlib.CvSetMouseCallback("LkDemo", onMouse, IntPtr.Zero);
		}

		/// <summary>
		/// Invoked if the for closed
		/// i do a clean up here
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void ControlWindow_Closed(object sender, FormClosedEventArgs e)
		{
			// release unmanaged resources
			if (image.ptr != IntPtr.Zero) cvlib.CvReleaseImage(ref image);
			if (grey.ptr != IntPtr.Zero) cvlib.CvReleaseImage(ref grey);
			if (prev_grey.ptr != IntPtr.Zero) cvlib.CvReleaseImage(ref prev_grey);
			if (pyramid.ptr != IntPtr.Zero) cvlib.CvReleaseImage(ref pyramid);
			if (prev_pyramid.ptr != IntPtr.Zero) cvlib.CvReleaseImage(ref prev_pyramid);
			if (capture.ptr != IntPtr.Zero) cvlib.CvReleaseCapture(ref capture);
		}	

		/// <summary>
		/// Handles the Click event of the exit button.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void Exit_Click(object sender, EventArgs e)
		{
			// close this form (Form1_FormClosed will be invoked)
			this.Close();
		}

		/// <summary>
		/// Starts the camera capture
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void StartCapture_Click(object sender, EventArgs e)
		{
			// only if we havnt already a valid capture device
			if (capture.ptr == IntPtr.Zero)
			{
				// create (in this case the first device)
				capture = cvlib.CvCreateCameraCapture(0);

				// check again
				if (capture.ptr == IntPtr.Zero)
				{
					MessageBox.Show("Could not intialize camera capture.");
					return;
				}
				else
				{
					// start the timer to capture images
					timer1.Interval = 200;
					timer1.Start();
				}
			}
		}

		/// <summary>
		/// Stop capturing
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void StopCapture_Click(object sender, EventArgs e)
		{
			// stop timer
			timer1.Stop();

			// optional release capture device
			if (capture.ptr != IntPtr.Zero) cvlib.CvReleaseCapture(ref capture);
		}

		/// <summary>
		/// The timer event (capture one single frame)
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void Timer_Tick(object sender, EventArgs e)
		{
			IplImage frame;
			int i, k;

			// capture a frame
			frame = cvlib.CvQueryFrame(ref capture);

			// check if the frame valid
			if (frame.ptr == IntPtr.Zero)
			{
				// optional stop capturing
				timer1.Stop();
				MessageBox.Show("Invalid Frame. Capturing has been stopped.");
				return;
			}

			// check if this is the first run
			if (image.ptr == IntPtr.Zero)
			{
				/* allocate all the buffers */
				image = cvlib.CvCreateImage(cvlib.CvGetSize(ref frame), 8, 3);
				image.origin = frame.origin;
				grey = cvlib.CvCreateImage(cvlib.CvGetSize(ref frame), 8, 1);
				prev_grey = cvlib.CvCreateImage(cvlib.CvGetSize(ref frame), 8, 1);
				pyramid = cvlib.CvCreateImage(cvlib.CvGetSize(ref frame), 8, 1);
				prev_pyramid = cvlib.CvCreateImage(cvlib.CvGetSize(ref frame), 8, 1);
				points[0] = new CvPoint2D32f[MAX_COUNT];
				points[1] = new CvPoint2D32f[MAX_COUNT];
				status = new byte[MAX_COUNT];
				flags = 0;
			}

			cvlib.CvCopy(ref frame, ref image);
			cvlib.CvCvtColor(ref image, ref grey, cvlib.CV_BGR2GRAY);

			if (night_mode > 0) cvlib.CvSetZero(ref image);

			if (need_to_init > 0)
			{
				/* automatic initialization */
				IplImage eig = cvlib.CvCreateImage(cvlib.CvGetSize(ref grey), 32, 1);
				IplImage temp = cvlib.CvCreateImage(cvlib.CvGetSize(ref grey), 32, 1);
				double quality = 0.01;
				double min_distance = 10;

				count = MAX_COUNT;
				
				// this is because i dont know a way to pass arrays dircly
				GCHandle h;
				IntPtr pts = cvtools.Convert1DArrToPtr(points[1], out h);
				
				cvlib.CvGoodFeaturesToTrack(ref grey, ref eig, ref temp, pts, ref count,
					quality, min_distance, IntPtr.Zero, 3, 0, 0.04);
				
				cvlib.CvFindCornerSubPix(ref grey, pts, count,
					new CvSize(win_size, win_size), new CvSize(-1, -1),
					new CvTermCriteria(cvlib.CV_TERMCRIT_ITER | cvlib.CV_TERMCRIT_EPS, 20, 0.03));

				// release the handel
				cvtools.ReleaseHandel(h);

				cvlib.CvReleaseImage(ref eig);
				cvlib.CvReleaseImage(ref temp);

				add_remove_pt = 0;
			}
			else if (count > 0)
			{
				// this is because i dont know a way to pass arrays of structures dircly
				// it seems the conversion in every call slows the processing down
				// so you should do the conversion only once
				GCHandle h1, h2;

				float[] track_error = new float[1000];

				// For the hint to use IntPtr i want to thanks
				// Dobson Levente (codeproject) and
				// Peter Gassner (codeproject)
				cvlib.CvCalcOpticalFlowPyrLK
				(
					ref prev_grey,
					ref grey,
					ref prev_pyramid,
					ref pyramid,
					cvtools.Convert1DArrToPtr(points[0], out h1),
					cvtools.Convert1DArrToPtr(points[1], out h2),
					count,
					new CvSize(win_size, win_size),
					3,
					status,
					track_error,
					new CvTermCriteria(cvlib.CV_TERMCRIT_ITER | cvlib.CV_TERMCRIT_EPS, 20, 0.03),
					flags
				);

				flags |= cvlib.CV_LKFLOW_PYR_A_READY;
				for (i = k = 0; i < count; i++)
				{
					if (add_remove_pt > 0)
					{
						double dx = pt.x - points[1][i].x;
						double dy = pt.y - points[1][i].y;

						if (dx * dx + dy * dy <= 25)
						{
							add_remove_pt = 0;
							continue;
						}
					}

					if (status[i] == 0)
						continue;

					points[1][k++] = points[1][i];
					cvlib.CvCircle(ref image, cvlib.CvPointFrom32f(points[1][i]), 3, cvlib.CV_RGB(0, 255, 0), -1, 8, 0);
				}
				count = k;

				// release handels
				cvtools.ReleaseHandel(h1);
				cvtools.ReleaseHandel(h2);
			}

			if ((add_remove_pt > 0) && (count < MAX_COUNT))
			{
				// this is because i dont know a way to pass arrays dircly
				GCHandle h;

				points[1][count++] = cvlib.CvPointTo32f(pt);
				CvPoint2D32f[] tmp = new CvPoint2D32f[1] { points[1][count - 1] };

				cvlib.CvFindCornerSubPix(ref grey, cvtools.Convert1DArrToPtr(tmp, out h), 1,
						new CvSize(win_size, win_size), new CvSize(-1, -1),
						new CvTermCriteria(cvlib.CV_TERMCRIT_ITER | cvlib.CV_TERMCRIT_EPS, 20, 0.03));
				
				add_remove_pt = 0;
				
				// release handle
				cvtools.ReleaseHandel(h);
			}

			CV_SWAP(ref prev_grey, ref grey, ref swap_temp);
			CV_SWAP(ref prev_pyramid, ref pyramid, ref swap_temp);
			CV_SWAP(ref points[0], ref points[1], ref swap_points);
			need_to_init = 0;
			cvlib.CvShowImage("LkDemo", ref image);
		}

		/// <summary>
		/// Auto Initialize
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void AutoInitTracking_Click(object sender, EventArgs e)
		{
			need_to_init = 1;
		}

		/// <summary>
		/// Remove all tracking points
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void DeleteAllPoints_Click(object sender, EventArgs e)
		{
			count = 0;
		}

		/// <summary>
		/// Switch to night Mode
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void Switch_Click(object sender, EventArgs e)
		{
			night_mode ^= 1;
		}

		/// <summary>
		/// A future extension for the cvlib
		/// </summary>
		/// <param name="a">Image 1 to swap with image 2</param>
		/// <param name="b">Image 2 to swap with image 1</param>
		/// <param name="t">Temp Image</param>
		private void CV_SWAP(ref IplImage a, ref IplImage b, ref IplImage t)
		{
			t = a;
			a = b;
			b = t;
		}

		/// <summary>
		/// A future extension for the cvlib
		/// </summary>
		/// <param name="a">Array a to swap with array b</param>
		/// <param name="b">Array b to swap with array a</param>
		/// <param name="t">Temp array</param>
		private void CV_SWAP(ref CvPoint2D32f[] a, ref CvPoint2D32f[] b, ref CvPoint2D32f[] t)
		{
			t = a;
			a = b;
			b = t;
		}

		/// <summary>
		/// Mouse event.
		/// </summary>
		/// <param name="evnt">The evnt code (eg mouse down)</param>
		/// <param name="x">x-coordinate of mouse.</param>
		/// <param name="y">y-coordinate of mouse.</param>
		/// <param name="flags">Some flags (eg. mouse down)</param>
		/// <param name="param">Optional Parameter</param>
		private void OnMouse(int evnt, int x, int y, int flags, IntPtr param)
		{
			if (image.ptr == IntPtr.Zero)
				return;

			if (image.origin > 0)
				y = image.height - y;

			if (evnt == cvlib.CV_EVENT_LBUTTONDOWN)
			{
				pt = new CvPoint(x, y);
				add_remove_pt = 1;
			}
		}

		/// <summary>
		/// In case of an error.
		/// </summary>
		/// <param name="status">Error status: 0 if no error, > 0 encoded error message</param>
		/// <param name="func_name">The func_name where the error occured.</param>
		/// <param name="err_msg">The error text.</param>
		/// <param name="file_name">The file name where the error occured.</param>
		/// <param name="line">The line in the file where the error occured.</param>
		/// <returns></returns>
		private int OnError(int status, string func_name,
										string err_msg, string file_name, int line)
		{
			MessageBox.Show("Status: " + cvlib.CvErrorStr(status) + 
				"\nIn Function: " + func_name + 
				"\nMessage: " + err_msg + 
				"\nIn File: " + file_name + 
				"\nOn Line: " + line.ToString(), "CV-Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return 0;
		}
	}
}