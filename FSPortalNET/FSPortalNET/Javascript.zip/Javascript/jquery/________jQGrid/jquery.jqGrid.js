/* 
* jqGrid  3.6.5 - jQuery Grid 
* Copyright (c) 2008, Tony Tomov, tony@trirand.com 
* Dual licensed under the MIT and GPL licenses 
* http://www.opensource.org/licenses/mit-license.php 
* http://www.gnu.org/licenses/gpl-2.0.html 
* Date:2010-05-05 
* Modules: grid.base.js; grid.custom.js; grid.common.js; grid.formedit.js; jquery.searchFilter.js; 
*/
(function(b) {
    b.jgrid = b.jgrid || {};
    b.extend(b.jgrid, {
        htmlDecode: function(f) {
            if (f == "&nbsp;" || f == "&#160;" || f.length == 1 && f.charCodeAt(0) == 160)return"";
            return!f ? f : String(f).replace(/&amp;/g, "&").replace(/&gt;/g, ">").replace(/&lt;/g, "<").replace(/&quot;/g, '"');
        },
        htmlEncode: function(f) { return!f ? f : String(f).replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/\"/g, "&quot;"); },
        format: function(f) {
            var k = b.makeArray(arguments).slice(1);
            if (f === undefined)f = "";
            return f.replace(/\{(\d+)\}/g, function(i,
                h) { return k[h]; });
        },
        getCellIndex: function(f) {
            f = b(f);
            f = (!f.is("td") && !f.is("th") ? f.closest("td, th") : f)[0];
            if (b.browser.msie)return b.inArray(f, f.parentNode.cells);
            return f.cellIndex;
        },
        stripHtml: function(f) {
            f += "";
            var k = /<("[^"]*"|'[^']*'|[^'">])*>/gi;
            if (f)return(f = f.replace(k, "")) && f !== "&nbsp;" && f !== "&#160;" ? f.replace(/\"/g, "'") : "";
            else return f;
        },
        stringToDoc: function(f) {
            var k;
            if (typeof f !== "string")return f;
            try {
                k = (new DOMParser).parseFromString(f, "text/xml");
            } catch (i) {
                k = new ActiveXObject("Microsoft.XMLDOM");
                k.async = false;
                k.loadXML(f);
            }
            return k && k.documentElement && k.documentElement.tagName != "parsererror" ? k : null;
        },
        parse: function(f) {
            f = f;
            if (f.substr(0, 9) == "while(1);")f = f.substr(9);
            if (f.substr(0, 2) == "/*")f = f.substr(2, f.length - 4);
            f || (f = "{}");
            return b.jgrid.useJSON === true && typeof JSON === "object" && typeof JSON.parse === "function" ? JSON.parse(f) : eval("(" + f + ")");
        },
        jqID: function(f) {
            f += "";
            return f.replace(/([\.\:\[\]])/g, "\\$1");
        },
        ajaxOptions: {},
        extend: function(f) {
            b.extend(b.fn.jqGrid, f);
            this.no_legacy_api || b.fn.extend(f);
        }
    });
    b.fn.jqGrid = function(f) {
        if (typeof f == "string") {
            var k = b.fn.jqGrid[f];
            if (!k)throw"jqGrid - No such method: " + f;
            var i = b.makeArray(arguments).slice(1);
            return k.apply(this, i);
        }
        return this.each(function() {
            if (!this.grid) {
                var h = b.extend(true, {
                        url: "",
                        height: 150,
                        page: 1,
                        rowNum: 20,
                        records: 0,
                        pager: "",
                        pgbuttons: true,
                        pginput: true,
                        colModel: [],
                        rowList: [],
                        colNames: [],
                        sortorder: "asc",
                        sortname: "",
                        datatype: "xml",
                        mtype: "GET",
                        altRows: false,
                        selarrrow: [],
                        savedRow: [],
                        shrinkToFit: true,
                        xmlReader: {},
                        jsonReader: {},
                        subGrid: false,
                        subGridModel: [],
                        reccount: 0,
                        lastpage: 0,
                        lastsort: 0,
                        selrow: null,
                        beforeSelectRow: null,
                        onSelectRow: null,
                        onSortCol: null,
                        ondblClickRow: null,
                        onRightClickRow: null,
                        onPaging: null,
                        onSelectAll: null,
                        loadComplete: null,
                        gridComplete: null,
                        loadError: null,
                        loadBeforeSend: null,
                        afterInsertRow: null,
                        beforeRequest: null,
                        onHeaderClick: null,
                        viewrecords: false,
                        loadonce: false,
                        multiselect: false,
                        multikey: false,
                        editurl: null,
                        search: false,
                        caption: "",
                        hidegrid: true,
                        hiddengrid: false,
                        postData: {},
                        userData: {},
                        treeGrid: false,
                        treeGridModel: "nested",
                        treeReader: {},
                        treeANode: -1,
                        ExpandColumn: null,
                        tree_root_level: 0,
                        prmNames: { page: "page", rows: "rows", sort: "sidx", order: "sord", search: "_search", nd: "nd", id: "id", oper: "oper", editoper: "edit", addoper: "add", deloper: "del", subgridid: "id", npage: null },
                        forceFit: false,
                        gridstate: "visible",
                        cellEdit: false,
                        cellsubmit: "remote",
                        nv: 0,
                        loadui: "enable",
                        toolbar: [false, ""],
                        scroll: false,
                        multiboxonly: false,
                        deselectAfterSort: true,
                        scrollrows: false,
                        autowidth: false,
                        scrollOffset: 18,
                        cellLayout: 5,
                        subGridWidth: 20,
                        multiselectWidth: 20,
                        gridview: false,
                        rownumWidth: 25,
                        rownumbers: false,
                        pagerpos: "center",
                        recordpos: "right",
                        footerrow: false,
                        userDataOnFooter: false,
                        hoverrows: true,
                        altclass: "ui-priority-secondary",
                        viewsortcols: [false, "vertical", true],
                        resizeclass: "",
                        autoencode: false,
                        remapColumns: [],
                        ajaxGridOptions: {},
                        direction: "ltr",
                        toppager: false,
                        headertitles: false,
                        scrollTimeout: 200
                    }, b.jgrid.defaults, f || {}),
                    g = {
                        headers: [],
                        cols: [],
                        footers: [],
                        dragStart: function(c, d, e) {
                            this.resizing = { idx: c, startX: d.clientX, sOL: e[0] };
                            this.hDiv.style.cursor = "col-resize";
                            this.curGbox = b("#rs_m" + h.id, "#gbox_" + h.id);
                            this.curGbox.css({ display: "block", left: e[0], top: e[1], height: e[2] });
                            b.isFunction(h.resizeStart) && h.resizeStart.call(this, d, c);
                            document.onselectstart = function() { return false; };
                        },
                        dragMove: function(c) {
                            if (this.resizing) {
                                var d = c.clientX - this.resizing.startX;
                                c = this.headers[this.resizing.idx];
                                var e = h.direction === "ltr" ? c.width + d : c.width - d, l;
                                if (e > 33) {
                                    this.curGbox.css({ left: this.resizing.sOL + d });
                                    if (h.forceFit === true) {
                                        l = this.headers[this.resizing.idx + h.nv];
                                        d = h.direction ===
                                            "ltr" ? l.width - d : l.width + d;
                                        if (d > 33) {
                                            c.newWidth = e;
                                            l.newWidth = d;
                                        }
                                    } else {
                                        this.newWidth = h.direction === "ltr" ? h.tblwidth + d : h.tblwidth - d;
                                        c.newWidth = e;
                                    }
                                }
                            }
                        },
                        dragEnd: function() {
                            this.hDiv.style.cursor = "default";
                            if (this.resizing) {
                                var c = this.resizing.idx, d = this.headers[c].newWidth || this.headers[c].width;
                                d = parseInt(d, 10);
                                this.resizing = false;
                                b("#rs_m" + h.id).css("display", "none");
                                h.colModel[c].width = d;
                                this.headers[c].width = d;
                                this.headers[c].el.style.width = d + "px";
                                if (this.cols.length > 0)this.cols[c].style.width = d + "px";
                                if (this.footers.length > 0)this.footers[c].style.width = d + "px";
                                if (h.forceFit === true) {
                                    d = this.headers[c + h.nv].newWidth || this.headers[c + h.nv].width;
                                    this.headers[c + h.nv].width = d;
                                    this.headers[c + h.nv].el.style.width = d + "px";
                                    if (this.cols.length > 0)this.cols[c + h.nv].style.width = d + "px";
                                    if (this.footers.length > 0)this.footers[c + h.nv].style.width = d + "px";
                                    h.colModel[c + h.nv].width = d;
                                } else {
                                    h.tblwidth = this.newWidth || h.tblwidth;
                                    b("table:first", this.bDiv).css("width", h.tblwidth + "px");
                                    b("table:first", this.hDiv).css("width",
                                        h.tblwidth + "px");
                                    this.hDiv.scrollLeft = this.bDiv.scrollLeft;
                                    if (h.footerrow) {
                                        b("table:first", this.sDiv).css("width", h.tblwidth + "px");
                                        this.sDiv.scrollLeft = this.bDiv.scrollLeft;
                                    }
                                }
                                b.isFunction(h.resizeStop) && h.resizeStop.call(this, d, c);
                            }
                            this.curGbox = null;
                            document.onselectstart = function() { return true; };
                        },
                        populateVisible: function() {
                            g.timer && clearTimeout(g.timer);
                            g.timer = null;
                            var c = b(g.bDiv).height();
                            if (c) {
                                var d = b("table:first", g.bDiv), e = b("> tbody > tr:visible:first", d).outerHeight() || g.prevRowHeight;
                                if (e) {
                                    g.prevRowHeight =
                                        e;
                                    var l = h.rowNum, n = g.scrollTop = g.bDiv.scrollTop, o = Math.round(d.position().top) - n, p = o + d.height();
                                    e = e * l;
                                    var w, y, s;
                                    if (o <= 0 && (h.lastpage === undefined || parseInt((p + n + e - 1) / e, 10) <= h.lastpage)) {
                                        y = parseInt((c - p + e - 1) / e, 10);
                                        if (p >= 0 || y < 2 || h.scroll === true) {
                                            w = Math.round((p + n) / e) + 1;
                                            o = -1;
                                        } else o = 1;
                                    }
                                    if (o > 0) {
                                        w = parseInt(n / e, 10) + 1;
                                        y = parseInt((n + c) / e, 10) + 2 - w;
                                        s = true;
                                    }
                                    if (y)
                                        if (!(h.lastpage && w > h.lastpage))
                                            if (g.hDiv.loading)g.timer = setTimeout(g.populateVisible, h.scrollTimeout);
                                            else {
                                                h.page = w;
                                                if (s) {
                                                    g.selectionPreserver(d[0]);
                                                    g.emptyRows(g.bDiv,
                                                        false);
                                                }
                                                g.populate(y);
                                            }
                                }
                            }
                        },
                        scrollGrid: function() {
                            if (h.scroll) {
                                var c = g.bDiv.scrollTop;
                                if (c != g.scrollTop) {
                                    g.scrollTop = c;
                                    g.timer && clearTimeout(g.timer);
                                    g.timer = setTimeout(g.populateVisible, 200);
                                }
                            }
                            g.hDiv.scrollLeft = g.bDiv.scrollLeft;
                            if (h.footerrow)g.sDiv.scrollLeft = g.bDiv.scrollLeft;
                        },
                        selectionPreserver: function(c) {
                            var d = c.p, e = d.selrow, l = d.selarrrow ? b.makeArray(d.selarrrow) : null, n = c.grid.bDiv.scrollLeft, o = d.gridComplete;
                            d.gridComplete = function() {
                                d.selrow = null;
                                d.selarrrow = [];
                                if (d.multiselect && l && l.length >
                                    0)for (var p = 0; p < l.length; p++)l[p] != e && b(c).jqGrid("setSelection", l[p], false);
                                e && b(c).jqGrid("setSelection", e, false);
                                c.grid.bDiv.scrollLeft = n;
                                d.gridComplete = o;
                                d.gridComplete && o();
                            };
                        }
                    };
                this.p = h;
                var j, m, a;
                if (this.p.colNames.length === 0)for (j = 0; j < this.p.colModel.length; j++)this.p.colNames[j] = this.p.colModel[j].label || this.p.colModel[j].name;
                if (this.p.colNames.length !== this.p.colModel.length)alert(b.jgrid.errors.model);
                else {
                    var q = b("<div class='ui-jqgrid-view'></div>"),
                        t,
                        x = b.browser.msie ? true : false,
                        C = b.browser.safari ?
                            true : false;
                    a = this;
                    a.p.direction = b.trim(a.p.direction.toLowerCase());
                    if (b.inArray(a.p.direction, ["ltr", "rtl"]) == -1)a.p.direction = "ltr";
                    m = a.p.direction;
                    b(q).insertBefore(this);
                    b(this).appendTo(q).removeClass("scroll");
                    var K = b("<div class='ui-jqgrid ui-widget ui-widget-content ui-corner-all'></div>");
                    b(K).insertBefore(q).attr({ id: "gbox_" + this.id, dir: m });
                    b(q).appendTo(K).attr("id", "gview_" + this.id);
                    t = x && b.browser.version <= 6 ? '<iframe style="display:block;position:absolute;z-index:-1;filter:Alpha(Opacity=\'0\');" src="javascript:false;"></iframe>' :
                        "";
                    b("<div class='ui-widget-overlay jqgrid-overlay' id='lui_" + this.id + "'></div>").append(t).insertBefore(q);
                    b("<div class='loading ui-state-default ui-state-active' id='load_" + this.id + "'>" + this.p.loadtext + "</div>").insertBefore(q);
                    b(this).attr({ cellSpacing: "0", cellPadding: "0", border: "0", role: "grid", "aria-multiselectable": !!this.p.multiselect, "aria-labelledby": "gbox_" + this.id });
                    var J = function(c, d) {
                            c = parseInt(c, 10);
                            return isNaN(c) ? d ? d : 0 : c;
                        },
                        F = function(c, d, e) {
                            var l = a.p.colModel[c],
                                n = l.align,
                                o = 'style="',
                                p = l.classes,
                                w = l.name;
                            if (n)o += "text-align:" + n + ";";
                            if (l.hidden === true)o += "display:none;";
                            if (d === 0)o += "width: " + g.headers[c].width + "px;";
                            o += '"' + (p !== undefined ? ' class="' + p + '"' : "") + (l.title && e ? ' title="' + b.jgrid.stripHtml(e) + '"' : "");
                            o += ' aria-describedby="' + a.p.id + "_" + w + '"';
                            return o;
                        },
                        Q = function(c) { return c === undefined || c === null || c === "" ? "&#160;" : a.p.autoencode ? b.jgrid.htmlEncode(c) : c + ""; },
                        M = function(c, d, e, l, n) {
                            e = a.p.colModel[e];
                            if (typeof e.formatter !== "undefined") {
                                c = { rowId: c, colModel: e, gid: a.p.id };
                                d = b.isFunction(e.formatter) ?
                                    e.formatter.call(a, d, c, l, n) : b.fmatter ? b.fn.fmatter(e.formatter, d, c, l, n) : Q(d);
                            } else d = Q(d);
                            return d;
                        },
                        R = function(c, d, e, l, n) {
                            c = M(c, d, e, n, "add");
                            return'<td role="gridcell" ' + F(e, l, c) + ">" + c + "</td>";
                        },
                        u = function(c, d, e) {
                            c = '<input role="checkbox" type="checkbox" id="jqg_' + c + '" class="cbox" name="jqg_' + c + '"/>';
                            d = F(d, e, "");
                            return'<td role="gridcell" aria-describedby="' + a.p.id + '_cb" ' + d + ">" + c + "</td>";
                        },
                        la = function(c, d, e, l) {
                            e = (parseInt(e, 10) - 1) * parseInt(l, 10) + 1 + d;
                            c = F(c, d, "");
                            return'<td role="gridcell" aria-describedby="' +
                                a.p.id + '_rn" class="ui-state-default jqgrid-rownum" ' + c + ">" + e + "</td>";
                        },
                        ca = function(c) {
                            var d, e = [], l = 0, n;
                            for (n = 0; n < a.p.colModel.length; n++) {
                                d = a.p.colModel[n];
                                if (d.name !== "cb" && d.name !== "subgrid" && d.name !== "rn") {
                                    e[l] = c == "xml" ? d.xmlmap || d.name : d.jsonmap || d.name;
                                    l++;
                                }
                            }
                            return e;
                        },
                        fa = function(c) {
                            var d = a.p.remapColumns;
                            if (!d || !d.length)d = b.map(a.p.colModel, function(e, l) { return l; });
                            if (c)d = b.map(d, function(e) { return e < c ? null : e - c; });
                            return d;
                        },
                        aa = function(c, d) {
                            a.p.deepempty ? b("tbody:first tr", c).remove() : b("tbody:first",
                                c).empty();
                            if (d && a.p.scroll) {
                                b(">div:first", c).css({ height: "auto" }).children("div:first").css({ height: 0, display: "none" });
                                c.scrollTop = 0;
                            }
                        },
                        U = function(c, d) {
                            var e, l, n, o;
                            if (typeof d === "function")return d(c);
                            e = c[d];
                            if (e === undefined) {
                                if (typeof d === "string")n = d.split(".");
                                try {
                                    if (o = n.length)
                                        for (e = c; e && o--;) {
                                            l = n.shift();
                                            e = e[l];
                                        }
                                } catch (p) {
                                }
                            }
                            return e;
                        },
                        ia = function(c, d, e, l, n) {
                            var o = new Date;
                            a.p.reccount = 0;
                            if (b.isXMLDoc(c)) {
                                if (a.p.treeANode === -1 && !a.p.scroll) {
                                    aa(d, false);
                                    e = 0;
                                } else e = e > 0 ? e : 0;
                                var p,
                                    w = 0,
                                    y,
                                    s,
                                    r = 0,
                                    v = 0,
                                    z = 0,
                                    D,
                                    N,
                                    L = [],
                                    P,
                                    G = {},
                                    da = a.rows.length,
                                    E,
                                    W,
                                    B = [],
                                    S = 0,
                                    ga = a.p.altRows === true ? " " + a.p.altclass : "";
                                a.p.xmlReader.repeatitems || (L = ca("xml"));
                                D = a.p.keyIndex === false ? a.p.xmlReader.id : a.p.keyIndex;
                                if (L.length > 0 && !isNaN(D)) {
                                    if (a.p.remapColumns && a.p.remapColumns.length)D = b.inArray(D, a.p.remapColumns);
                                    D = L[D];
                                }
                                N = (D + "").indexOf("[") === -1 ? L.length ? function(X, V) { return b(D, X).text() || V; } : function(X, V) { return b(a.p.xmlReader.cell, X).eq(D).text() || V; } : function(X, V) { return X.getAttribute(D.replace(/[\[\]]/g, "")) || V; };
                                a.p.userData =
                                {};
                                b(a.p.xmlReader.page, c).each(function() { a.p.page = this.textContent || this.text || 0; });
                                b(a.p.xmlReader.total, c).each(function() {
                                    a.p.lastpage = this.textContent || this.text;
                                    if (a.p.lastpage === undefined)a.p.lastpage = 1;
                                });
                                b(a.p.xmlReader.records, c).each(function() { a.p.records = this.textContent || this.text || 0; });
                                b(a.p.xmlReader.userdata, c).each(function() { a.p.userData[this.getAttribute("name")] = this.textContent || this.text; });
                                c = b(a.p.xmlReader.root + " " + a.p.xmlReader.row, c);
                                var ha = c.length, O = 0;
                                if (c && ha) {
                                    var ma = parseInt(a.p.rowNum,
                                            10),
                                        wa = a.p.scroll ? (parseInt(a.p.page, 10) - 1) * ma + 1 : 1;
                                    if (n)ma *= n + 1;
                                    for (n = b.isFunction(a.p.afterInsertRow); O < ha;) {
                                        E = c[O];
                                        W = N(E, wa + O);
                                        p = e === 0 ? 0 : e + 1;
                                        p = (p + O) % 2 == 1 ? ga : "";
                                        B[S++] = '<tr id="' + W + '" role="row" class ="ui-widget-content jqgrow ui-row-' + a.p.direction + "" + p + '">';
                                        if (a.p.rownumbers === true) {
                                            B[S++] = la(0, O, a.p.page, a.p.rowNum);
                                            z = 1;
                                        }
                                        if (a.p.multiselect === true) {
                                            B[S++] = u(W, z, O);
                                            r = 1;
                                        }
                                        if (a.p.subGrid === true) {
                                            B[S++] = b(a).jqGrid("addSubGridCell", r + z, O + e);
                                            v = 1;
                                        }
                                        if (a.p.xmlReader.repeatitems) {
                                            P || (P = fa(r + v + z));
                                            var za = b(a.p.xmlReader.cell,
                                                E);
                                            b.each(P, function(X) {
                                                var V = za[this];
                                                if (!V)return false;
                                                y = V.textContent || V.text;
                                                G[a.p.colModel[X + r + v + z].name] = y;
                                                B[S++] = R(W, y, X + r + v + z, O + e, E);
                                            });
                                        } else
                                            for (p = 0; p < L.length; p++) {
                                                y = b(L[p], E).text();
                                                G[a.p.colModel[p + r + v + z].name] = y;
                                                B[S++] = R(W, y, p + r + v + z, O + e, E);
                                            }
                                        B[S++] = "</tr>";
                                        if (a.p.gridview === false) {
                                            if (a.p.treeGrid === true) {
                                                p = a.p.treeANode >= -1 ? a.p.treeANode : 0;
                                                s = b(B.join(""))[0];
                                                try {
                                                    b(a).jqGrid("setTreeNode", G, s);
                                                } catch (Fa) {
                                                }
                                                da === 0 ? b("tbody:first", d).append(s) : b(a.rows[O + p + e]).after(s);
                                            } else b("tbody:first", d).append(B.join(""));
                                            if (a.p.subGrid === true)
                                                try {
                                                    b(a).jqGrid("addSubGrid", a.rows[a.rows.length - 1], r + z);
                                                } catch (Ga) {
                                                }
                                            n && a.p.afterInsertRow.call(a, W, G, E);
                                            B = [];
                                            S = 0;
                                        }
                                        G = {};
                                        w++;
                                        O++;
                                        if (w == ma)break;
                                    }
                                }
                                a.p.gridview === true && b("tbody:first", d).append(B.join(""));
                                a.p.totaltime = new Date - o;
                                if (w > 0) {
                                    a.grid.cols = a.rows[0].cells;
                                    if (a.p.records === 0)a.p.records = ha;
                                }
                                B = null;
                                if (!a.p.treeGrid && !a.p.scroll)a.grid.bDiv.scrollTop = 0;
                                a.p.reccount = w;
                                a.p.treeANode = -1;
                                a.p.userDataOnFooter && b(a).jqGrid("footerData", "set", a.p.userData, true);
                                l || na(false, true);
                            }
                        },
                        ra = function(c, d, e, l, n) {
                            var o = new Date;
                            a.p.reccount = 0;
                            if (c) {
                                if (a.p.treeANode === -1 && !a.p.scroll) {
                                    aa(d, false);
                                    e = 0;
                                } else e = e > 0 ? e : 0;
                                var p = 0, w, y, s, r = [], v, z = 0, D = 0, N = 0, L, P, G, da = {}, E, W = a.rows.length, B;
                                s = [];
                                E = 0;
                                var S = a.p.altRows === true ? " " + a.p.altclass : "";
                                a.p.page = U(c, a.p.jsonReader.page) || 0;
                                G = U(c, a.p.jsonReader.total);
                                a.p.lastpage = G === undefined ? 1 : G;
                                a.p.records = U(c, a.p.jsonReader.records) || 0;
                                a.p.userData = U(c, a.p.jsonReader.userdata) || {};
                                a.p.jsonReader.repeatitems || (v = r = ca("json"));
                                G = a.p.keyIndex === false ? a.p.jsonReader.id :
                                    a.p.keyIndex;
                                if (r.length > 0 && !isNaN(G)) {
                                    if (a.p.remapColumns && a.p.remapColumns.length)G = b.inArray(G, a.p.remapColumns);
                                    G = r[G];
                                }
                                if (P = U(c, a.p.jsonReader.root)) {
                                    L = P.length;
                                    c = 0;
                                    var ga = parseInt(a.p.rowNum, 10), ha = a.p.scroll ? (parseInt(a.p.page, 10) - 1) * ga + 1 : 1;
                                    if (n)ga *= n + 1;
                                    for (var O = b.isFunction(a.p.afterInsertRow); c < L;) {
                                        n = P[c];
                                        B = U(n, G);
                                        if (B === undefined) {
                                            B = ha + c;
                                            if (r.length === 0)if (a.p.jsonReader.cell)B = n[a.p.jsonReader.cell][G] || B;
                                        }
                                        w = e === 0 ? 0 : e + 1;
                                        w = (w + c) % 2 == 1 ? S : "";
                                        s[E++] = '<tr id="' + B + '" role="row" class= "ui-widget-content jqgrow ui-row-' +
                                            a.p.direction + "" + w + '">';
                                        if (a.p.rownumbers === true) {
                                            s[E++] = la(0, c, a.p.page, a.p.rowNum);
                                            N = 1;
                                        }
                                        if (a.p.multiselect) {
                                            s[E++] = u(B, N, c);
                                            z = 1;
                                        }
                                        if (a.p.subGrid) {
                                            s[E++] = b(a).jqGrid("addSubGridCell", z + N, c + e);
                                            D = 1;
                                        }
                                        if (a.p.jsonReader.repeatitems) {
                                            if (a.p.jsonReader.cell)n = U(n, a.p.jsonReader.cell);
                                            v || (v = fa(z + D + N));
                                        }
                                        for (y = 0; y < v.length; y++) {
                                            w = U(n, v[y]);
                                            s[E++] = R(B, w, y + z + D + N, c + e, n);
                                            da[a.p.colModel[y + z + D + N].name] = w;
                                        }
                                        s[E++] = "</tr>";
                                        if (a.p.gridview === false) {
                                            if (a.p.treeGrid === true) {
                                                E = a.p.treeANode >= -1 ? a.p.treeANode : 0;
                                                s = b(s.join(""))[0];
                                                try {
                                                    b(a).jqGrid("setTreeNode", da, s);
                                                } catch (ma) {
                                                }
                                                W === 0 ? b("tbody:first", d).append(s) : b(a.rows[c + E + e]).after(s);
                                            } else b("tbody:first", d).append(s.join(""));
                                            if (a.p.subGrid === true)
                                                try {
                                                    b(a).jqGrid("addSubGrid", a.rows[a.rows.length - 1], z + N);
                                                } catch (wa) {
                                                }
                                            O && a.p.afterInsertRow.call(a, B, da, n);
                                            s = [];
                                            E = 0;
                                        }
                                        da = {};
                                        p++;
                                        c++;
                                        if (p == ga)break;
                                    }
                                    a.p.gridview === true && b("tbody:first", d).append(s.join(""));
                                    a.p.totaltime = new Date - o;
                                    if (p > 0) {
                                        a.grid.cols = a.rows[0].cells;
                                        if (a.p.records === 0)a.p.records = L;
                                    }
                                }
                                if (!a.p.treeGrid && !a.p.scroll)
                                    a.grid.bDiv.scrollTop =
                                        0;
                                a.p.reccount = p;
                                a.p.treeANode = -1;
                                a.p.userDataOnFooter && b(a).jqGrid("footerData", "set", a.p.userData, true);
                                l || na(false, true);
                            }
                        },
                        na = function(c, d) {
                            var e, l, n, o, p, w, y, s = "";
                            n = parseInt(a.p.page, 10) - 1;
                            if (n < 0)n = 0;
                            n *= parseInt(a.p.rowNum, 10);
                            p = n + a.p.reccount;
                            if (a.p.scroll) {
                                e = b("tbody:first > tr", a.grid.bDiv);
                                n = p - e.length;
                                if (l = e.outerHeight()) {
                                    e = n * l;
                                    l = parseInt(a.p.records, 10) * l;
                                    b(">div:first", a.grid.bDiv).css({ height: l }).children("div:first").css({ height: e, display: e ? "" : "none" });
                                }
                            }
                            s = a.p.pager ? a.p.pager : "";
                            s += a.p.toppager ?
                                s ? "," + a.p.toppager : a.p.toppager : "";
                            if (s) {
                                y = b.jgrid.formatter.integer || {};
                                if (a.p.loadonce) {
                                    e = l = 1;
                                    a.p.lastpage = a.page = 1;
                                    b(".selbox", s).attr("disabled", true);
                                } else {
                                    e = J(a.p.page);
                                    l = J(a.p.lastpage);
                                    b(".selbox", s).attr("disabled", false);
                                }
                                if (a.p.pginput === true) {
                                    b(".ui-pg-input", s).val(a.p.page);
                                    b("#sp_1", s).html(b.fmatter ? b.fmatter.util.NumberFormat(a.p.lastpage, y) : a.p.lastpage);
                                }
                                if (a.p.viewrecords)
                                    if (a.p.reccount === 0)b(".ui-paging-info", s).html(a.p.emptyrecords);
                                    else {
                                        o = n + 1;
                                        w = a.p.records;
                                        if (b.fmatter) {
                                            o = b.fmatter.util.NumberFormat(o,
                                                y);
                                            p = b.fmatter.util.NumberFormat(p, y);
                                            w = b.fmatter.util.NumberFormat(w, y);
                                        }
                                        b(".ui-paging-info", s).html(b.jgrid.format(a.p.recordtext, o, p, w));
                                    }
                                if (a.p.pgbuttons === true) {
                                    if (e <= 0)e = l = 0;
                                    if (e == 1 || e === 0) {
                                        b("#first, #prev", a.p.pager).addClass("ui-state-disabled").removeClass("ui-state-hover");
                                        a.p.toppager && b("#first_t, #prev_t", a.p.toppager).addClass("ui-state-disabled").removeClass("ui-state-hover");
                                    } else {
                                        b("#first, #prev", a.p.pager).removeClass("ui-state-disabled");
                                        a.p.toppager && b("#first_t, #prev_t", a.p.toppager).removeClass("ui-state-disabled");
                                    }
                                    if (e ==
                                        l || e === 0) {
                                        b("#next, #last", a.p.pager).addClass("ui-state-disabled").removeClass("ui-state-hover");
                                        a.p.toppager && b("#next_t, #last_t", a.p.toppager).addClass("ui-state-disabled").removeClass("ui-state-hover");
                                    } else {
                                        b("#next, #last", a.p.pager).removeClass("ui-state-disabled");
                                        a.p.toppager && b("#next_t, #last_t", a.p.toppager).removeClass("ui-state-disabled");
                                    }
                                }
                            }
                            c === true && a.p.rownumbers === true && b("td.jqgrid-rownum", a.rows).each(function(r) { b(this).html(n + 1 + r); });
                            d && a.p.jqgdnd && b(a).jqGrid("gridDnD", "updateDnD");
                            b.isFunction(a.p.gridComplete) && a.p.gridComplete.call(a);
                        },
                        Y = function(c) {
                            if (!a.grid.hDiv.loading) {
                                var d = a.p.scroll && c === false, e = {}, l, n = a.p.prmNames;
                                if (a.p.page <= 0)a.p.page = 1;
                                if (n.search !== null)e[n.search] = a.p.search;
                                if (n.nd !== null)e[n.nd] = (new Date).getTime();
                                if (n.rows !== null)e[n.rows] = a.p.rowNum;
                                if (n.page !== null)e[n.page] = a.p.page;
                                if (n.sort !== null)e[n.sort] = a.p.sortname;
                                if (n.order !== null)e[n.order] = a.p.sortorder;
                                var o = a.p.loadComplete, p = b.isFunction(o);
                                p || (o = null);
                                var w = 0;
                                c = c || 1;
                                if (c > 1)
                                    if (n.npage !==
                                        null) {
                                        e[n.npage] = c;
                                        w = c - 1;
                                        c = 1;
                                    } else
                                        o = function(s) {
                                            p && a.p.loadComplete.call(a, s);
                                            a.grid.hDiv.loading = false;
                                            a.p.page++;
                                            Y(c - 1);
                                        };
                                else n.npage !== null && delete a.p.postData[n.npage];
                                b.extend(a.p.postData, e);
                                var y = !a.p.scroll ? 0 : a.rows.length - 1;
                                if (b.isFunction(a.p.datatype))a.p.datatype.call(a, a.p.postData, "load_" + a.p.id);
                                else {
                                    b.isFunction(a.p.beforeRequest) && a.p.beforeRequest.call(a);
                                    l = a.p.datatype.toLowerCase();
                                    switch (l) {
                                    case "json":
                                    case "jsonp":
                                    case "xml":
                                    case "script":
                                        b.ajax(b.extend({
                                            url: a.p.url,
                                            type: a.p.mtype,
                                            dataType: l,
                                            data: b.isFunction(a.p.serializeGridData) ? a.p.serializeGridData.call(a, a.p.postData) : a.p.postData,
                                            success: function(s) {
                                                l === "xml" ? ia(s, a.grid.bDiv, y, c > 1, w) : ra(s, a.grid.bDiv, y, c > 1, w);
                                                o && o.call(a, s);
                                                d && a.grid.populateVisible();
                                                if (a.p.loadonce || a.p.treeGrid)a.p.datatype = "local";
                                                ja();
                                            },
                                            error: function(s, r, v) {
                                                b.isFunction(a.p.loadError) && a.p.loadError.call(a, s, r, v);
                                                ja();
                                            },
                                            beforeSend: function(s) {
                                                oa();
                                                b.isFunction(a.p.loadBeforeSend) && a.p.loadBeforeSend.call(a, s);
                                            }
                                        }, b.jgrid.ajaxOptions, a.p.ajaxGridOptions));
                                        break;
                                    case "xmlstring":
                                        oa();
                                        e = b.jgrid.stringToDoc(a.p.datastr);
                                        p && a.p.loadComplete.call(a, e);
                                        ia(e, a.grid.bDiv);
                                        a.p.datatype = "local";
                                        a.p.datastr = null;
                                        ja();
                                        break;
                                    case "jsonstring":
                                        oa();
                                        e = typeof a.p.datastr == "string" ? b.jgrid.parse(a.p.datastr) : a.p.datastr;
                                        p && a.p.loadComplete.call(a, e);
                                        ra(e, a.grid.bDiv);
                                        a.p.datatype = "local";
                                        a.p.datastr = null;
                                        ja();
                                        break;
                                    case "local":
                                    case "clientside":
                                        oa();
                                        a.p.datatype = "local";
                                        p && a.p.loadComplete.call(a, "");
                                        Aa();
                                        na(true, true);
                                        ja();
                                        break;
                                    }
                                }
                            }
                        },
                        oa = function() {
                            a.grid.hDiv.loading =
                                true;
                            if (!a.p.hiddengrid)
                                switch (a.p.loadui) {
                                case "disable":
                                    break;
                                case "enable":
                                    b("#load_" + a.p.id).show();
                                    break;
                                case "block":
                                    b("#lui_" + a.p.id).show();
                                    b("#load_" + a.p.id).show();
                                    break;
                                }
                        },
                        ja = function() {
                            a.grid.hDiv.loading = false;
                            switch (a.p.loadui) {
                            case "disable":
                                break;
                            case "enable":
                                b("#load_" + a.p.id).hide();
                                break;
                            case "block":
                                b("#lui_" + a.p.id).hide();
                                b("#load_" + a.p.id).hide();
                                break;
                            }
                        },
                        Aa = function() {
                            var c = /[\$,%]/g, d = [], e = 0, l, n, o, p = a.p.sortorder == "asc" ? 1 : -1, w = false, y;
                            b.each(a.p.colModel, function(r) {
                                if (this.index ==
                                    a.p.sortname || this.name == a.p.sortname) {
                                    if (a.p.lastsort == r)w = true;
                                    e = r;
                                    l = this.sorttype;
                                    return false;
                                }
                            });
                            o = l == "float" || l == "number" || l == "currency" ? function(r) {
                                r = parseFloat(r.replace(c, ""));
                                return isNaN(r) ? 0 : r;
                            } : l == "int" || l == "integer" ? function(r) { return J(r.replace(c, ""), 0); } : l == "date" || l == "datetime" ? function(r) { return Ba(a.p.colModel[e].datefmt || "Y-m-d", r).getTime(); } : b.isFunction(l) ? l : function(r) { return b.trim(r.toUpperCase()); };
                            y = a.p.colModel[e];
                            b.each(a.rows, function(r, v) {
                                try {
                                    n = b.unformat(b(v).children("td").eq(e),
                                    { rowId: v.id, colModel: y }, e, true);
                                } catch (z) {
                                    n = b(v).children("td").eq(e).text();
                                }
                                v.sortKey = o(n);
                                d[r] = this;
                            });
                            if (a.p.treeGrid)b(a).jqGrid("SortTree", p);
                            else {
                                w ? d.reverse() : d.sort(function(r, v) {
                                    if (r.sortKey < v.sortKey)return-p;
                                    if (r.sortKey > v.sortKey)return p;
                                    return 0;
                                });
                                if (d[0]) {
                                    b("td", d[0]).each(function(r) { b(this).css("width", g.headers[r].width + "px"); });
                                    a.grid.cols = d[0].cells;
                                }
                                var s = "";
                                if (a.p.altRows)s = a.p.altclass;
                                b.each(d, function(r, v) {
                                    if (s)r % 2 == 1 ? b(v).addClass(s) : b(v).removeClass(s);
                                    b("tbody", a.grid.bDiv).append(v);
                                    v.sortKey = null;
                                });
                            }
                            a.grid.bDiv.scrollTop = 0;
                        },
                        Ba = function(c, d) {
                            var e = { m: 1, d: 1, y: 1970, h: 0, i: 0, s: 0 }, l, n, o;
                            if (d = b.trim(d)) {
                                d = d.split(/[\\\/:_;.\t\T\s-]/);
                                c = c.split(/[\\\/:_;.\t\T\s-]/);
                                var p = b.jgrid.formatter.date.monthNames,
                                    w = b.jgrid.formatter.date.AmPm,
                                    y = function(s, r) {
                                        if (s === 0) {
                                            if (r == 12)r = 0;
                                        } else if (r != 12)r += 12;
                                        return r;
                                    };
                                l = 0;
                                for (n = c.length; l < n; l++) {
                                    if (c[l] == "M") {
                                        o = b.inArray(d[l], p);
                                        if (o !== -1 && o < 12)d[l] = o + 1;
                                    }
                                    if (c[l] == "F") {
                                        o = b.inArray(d[l], p);
                                        if (o !== -1 && o > 11)d[l] = o + 1 - 12;
                                    }
                                    if (c[l] == "a") {
                                        o = b.inArray(d[l], w);
                                        if (o !==
                                            -1 && o < 2 && d[l] == w[o]) {
                                            d[l] = o;
                                            e.h = y(d[l], e.h);
                                        }
                                    }
                                    if (c[l] == "A") {
                                        o = b.inArray(d[l], w);
                                        if (o !== -1 && o > 1 && d[l] == w[o]) {
                                            d[l] = o - 2;
                                            e.h = y(d[l], e.h);
                                        }
                                    }
                                    e[c[l].toLowerCase()] = parseInt(d[l], 10);
                                }
                                e.m = parseInt(e.m, 10) - 1;
                                c = e.y;
                                if (c >= 70 && c <= 99)e.y = 1900 + e.y;
                                else if (c >= 0 && c <= 69)e.y = 2E3 + e.y;
                            }
                            return new Date(e.y, e.m, e.d, e.h, e.i, e.s, 0);
                        };
                    t = function(c, d) {
                        var e = "",
                            l = "<table cellspacing='0' cellpadding='0' border='0' style='table-layout:auto;' class='ui-pg-table'><tbody><tr>",
                            n = "",
                            o,
                            p,
                            w,
                            y,
                            s = function(r) {
                                var v;
                                if (b.isFunction(a.p.onPaging))
                                    v =
                                        a.p.onPaging.call(a, r);
                                a.p.selrow = null;
                                if (a.p.multiselect) {
                                    a.p.selarrrow = [];
                                    b("#cb_" + b.jgrid.jqID(a.p.id), a.grid.hDiv).attr("checked", false);
                                }
                                a.p.savedRow = [];
                                if (v == "stop")return false;
                                return true;
                            };
                        c = c.substr(1);
                        o = "pg_" + c;
                        p = c + "_left";
                        w = c + "_center";
                        y = c + "_right";
                        b("#" + c).append("<div id='" + o + "' class='ui-pager-control' role='group'><table cellspacing='0' cellpadding='0' border='0' class='ui-pg-table' style='width:100%;table-layout:fixed;' role='row'><tbody><tr><td id='" + p + "' align='left'></td><td id='" +
                            w + "' align='center' style='white-space:pre;'></td><td id='" + y + "' align='right'></td></tr></tbody></table></div>").attr("dir", "ltr");
                        if (a.p.rowList.length > 0) {
                            n = "<td dir='" + m + "'>";
                            n += "<select class='ui-pg-selbox' role='listbox'>";
                            for (p = 0; p < a.p.rowList.length; p++)n += "<option role='option' value='" + a.p.rowList[p] + "'" + (a.p.rowNum == a.p.rowList[p] ? " selected" : "") + ">" + a.p.rowList[p] + "</option>";
                            n += "</select></td>";
                        }
                        if (m == "rtl")l += n;
                        if (a.p.pginput === true)
                            e = "<td dir='" + m + "'>" + b.jgrid.format(a.p.pgtext || "", "<input class='ui-pg-input' type='text' size='2' maxlength='7' value='0' role='textbox'/>",
                                "<span id='sp_1'></span>") + "</td>";
                        if (a.p.pgbuttons === true) {
                            p = ["first" + d, "prev" + d, "next" + d, "last" + d];
                            m == "rtl" && p.reverse();
                            l += "<td id='" + p[0] + "' class='ui-pg-button ui-corner-all'><span class='ui-icon ui-icon-seek-first'></span></td>";
                            l += "<td id='" + p[1] + "' class='ui-pg-button ui-corner-all'><span class='ui-icon ui-icon-seek-prev'></span></td>";
                            l += e != "" ? "<td class='ui-pg-button ui-state-disabled' style='width:4px;'><span class='ui-separator'></span></td>" + e + "<td class='ui-pg-button ui-state-disabled' style='width:4px;'><span class='ui-separator'></span></td>" :
                                "";
                            l += "<td id='" + p[2] + "' class='ui-pg-button ui-corner-all'><span class='ui-icon ui-icon-seek-next'></span></td>";
                            l += "<td id='" + p[3] + "' class='ui-pg-button ui-corner-all'><span class='ui-icon ui-icon-seek-end'></span></td>";
                        } else if (e != "")l += e;
                        if (m == "ltr")l += n;
                        l += "</tr></tbody></table>";
                        a.p.viewrecords === true && b("td#" + c + "_" + a.p.recordpos, "#" + o).append("<div dir='" + m + "' style='text-align:" + a.p.recordpos + "' class='ui-paging-info'></div>");
                        b("td#" + c + "_" + a.p.pagerpos, "#" + o).append(l);
                        n = b(".ui-jqgrid").css("font-size") ||
                            "11px";
                        b("body").append("<div id='testpg' class='ui-jqgrid ui-widget ui-widget-content' style='font-size:" + n + ";visibility:hidden;' ></div>");
                        l = b(l).clone().appendTo("#testpg").width();
                        b("#testpg").remove();
                        if (l > 0) {
                            if (e != "")l += 50;
                            b("td#" + c + "_" + a.p.pagerpos, "#" + o).width(l);
                        }
                        a.p._nvtd = [];
                        a.p._nvtd[0] = l ? Math.floor((a.p.width - l) / 2) : Math.floor(a.p.width / 3);
                        a.p._nvtd[1] = 0;
                        l = null;
                        b(".ui-pg-selbox", "#" + o).bind("change", function() {
                            a.p.page = Math.round(a.p.rowNum * (a.p.page - 1) / this.value - 0.5) + 1;
                            a.p.rowNum = this.value;
                            if (d)b(".ui-pg-selbox", a.p.pager).val(this.value);
                            else a.p.toppager && b(".ui-pg-selbox", a.p.toppager).val(this.value);
                            if (!s("records"))return false;
                            Y();
                            return false;
                        });
                        if (a.p.pgbuttons === true) {
                            b(".ui-pg-button", "#" + o).hover(function() {
                                if (b(this).hasClass("ui-state-disabled"))this.style.cursor = "default";
                                else {
                                    b(this).addClass("ui-state-hover");
                                    this.style.cursor = "pointer";
                                }
                            }, function() {
                                if (!b(this).hasClass("ui-state-disabled")) {
                                    b(this).removeClass("ui-state-hover");
                                    this.style.cursor = "default";
                                }
                            });
                            b("#first" +
                                d + ", #prev" + d + ", #next" + d + ", #last" + d, "#" + c).click(function() {
                                var r = J(a.p.page, 1), v = J(a.p.lastpage, 1), z = false, D = true, N = true, L = true, P = true;
                                if (v === 0 || v === 1)P = L = N = D = false;
                                else if (v > 1 && r >= 1)
                                    if (r === 1)N = D = false;
                                    else {
                                        if (!(r > 1 && r < v))if (r === v)P = L = false;
                                    }
                                else if (v > 1 && r === 0) {
                                    P = L = false;
                                    r = v - 1;
                                }
                                if (this.id === "first" + d && D) {
                                    a.p.page = 1;
                                    z = true;
                                }
                                if (this.id === "prev" + d && N) {
                                    a.p.page = r - 1;
                                    z = true;
                                }
                                if (this.id === "next" + d && L) {
                                    a.p.page = r + 1;
                                    z = true;
                                }
                                if (this.id === "last" + d && P) {
                                    a.p.page = v;
                                    z = true;
                                }
                                if (z) {
                                    if (!s(this.id))return false;
                                    Y();
                                }
                                return false;
                            });
                        }
                        a.p.pginput ===
                            true && b("input.ui-pg-input", "#" + o).keypress(function(r) {
                                if ((r.charCode ? r.charCode : r.keyCode ? r.keyCode : 0) == 13) {
                                    a.p.page = b(this).val() > 0 ? b(this).val() : a.p.page;
                                    if (!s("user"))return false;
                                    Y();
                                    return false;
                                }
                                return this;
                            });
                    };
                    var xa = function(c, d, e, l) {
                            if (a.p.colModel[d].sortable)
                                if (!(a.p.savedRow.length > 0)) {
                                    if (!e) {
                                        if (a.p.lastsort == d)
                                            if (a.p.sortorder == "asc")a.p.sortorder = "desc";
                                            else {
                                                if (a.p.sortorder == "desc")a.p.sortorder = "asc";
                                            }
                                        else a.p.sortorder = a.p.colModel[d].firstsortorder || "asc";
                                        a.p.page = 1;
                                    }
                                    if (l)
                                        if (a.p.lastsort ==
                                            d && a.p.sortorder == l && !e)return;
                                        else a.p.sortorder = l;
                                    e = b("thead:first", a.grid.hDiv).get(0);
                                    b("tr th:eq(" + a.p.lastsort + ") span.ui-grid-ico-sort", e).addClass("ui-state-disabled");
                                    b("tr th:eq(" + a.p.lastsort + ")", e).attr("aria-selected", "false");
                                    b("tr th:eq(" + d + ") span.ui-icon-" + a.p.sortorder, e).removeClass("ui-state-disabled");
                                    b("tr th:eq(" + d + ")", e).attr("aria-selected", "true");
                                    if (!a.p.viewsortcols[0])
                                        if (a.p.lastsort != d) {
                                            b("tr th:eq(" + a.p.lastsort + ") span.s-ico", e).hide();
                                            b("tr th:eq(" + d + ") span.s-ico",
                                                e).show();
                                        }
                                    c = c.substring(5);
                                    a.p.sortname = a.p.colModel[d].index || c;
                                    e = a.p.sortorder;
                                    if (b.isFunction(a.p.onSortCol))
                                        if (a.p.onSortCol.call(a, c, d, e) == "stop") {
                                            a.p.lastsort = d;
                                            return;
                                        }
                                    if (a.p.datatype == "local")a.p.deselectAfterSort && b(a).jqGrid("resetSelection");
                                    else {
                                        a.p.selrow = null;
                                        a.p.multiselect && b("#cb_" + b.jgrid.jqID(a.p.id), a.grid.hDiv).attr("checked", false);
                                        a.p.selarrrow = [];
                                        a.p.savedRow = [];
                                        a.p.scroll && aa(a.grid.bDiv, true);
                                    }
                                    a.p.subGrid && a.p.datatype == "local" && b("td.sgexpanded", "#" + a.p.id).each(function() { b(this).trigger("click"); });
                                    Y();
                                    a.p.lastsort = d;
                                    if (a.p.sortname != c && d)a.p.lastsort = d;
                                }
                        },
                        Ca = function(c) {
                            var d = c, e;
                            for (e = c + 1; e < a.p.colModel.length; e++)
                                if (a.p.colModel[e].hidden !== true) {
                                    d = e;
                                    break;
                                }
                            return d - c;
                        },
                        Da = function(c) {
                            var d, e = {}, l = C ? 0 : a.p.cellLayout;
                            for (d = e[0] = e[1] = e[2] = 0; d <= c; d++)if (a.p.colModel[d].hidden === false)e[0] += a.p.colModel[d].width + l;
                            if (a.p.direction == "rtl")e[0] = a.p.width - e[0];
                            e[0] -= a.grid.bDiv.scrollLeft;
                            if (b(a.grid.cDiv).is(":visible"))
                                e[1] += b(a.grid.cDiv).height() + parseInt(b(a.grid.cDiv).css("padding-top"), 10) +
                                    parseInt(b(a.grid.cDiv).css("padding-bottom"), 10);
                            if (a.p.toolbar[0] === true && (a.p.toolbar[1] == "top" || a.p.toolbar[1] == "both"))e[1] += b(a.grid.uDiv).height() + parseInt(b(a.grid.uDiv).css("border-top-width"), 10) + parseInt(b(a.grid.uDiv).css("border-bottom-width"), 10);
                            if (a.p.toppager)e[1] += b(a.grid.topDiv).height() + parseInt(b(a.grid.topDiv).css("border-bottom-width"), 10);
                            e[2] += b(a.grid.bDiv).height() + b(a.grid.hDiv).height();
                            return e;
                        };
                    this.p.id = this.id;
                    if (b.inArray(a.p.multikey, ["shiftKey", "altKey", "ctrlKey"]) ==
                        -1)a.p.multikey = false;
                    a.p.keyIndex = false;
                    for (j = 0; j < a.p.colModel.length; j++)
                        if (a.p.colModel[j].key === true) {
                            a.p.keyIndex = j;
                            break;
                        }
                    a.p.sortorder = a.p.sortorder.toLowerCase();
                    if (this.p.treeGrid === true)
                        try {
                            b(this).jqGrid("setTreeGrid");
                        } catch (Ha) {
                        }
                    if (this.p.subGrid)
                        try {
                            b(a).jqGrid("setSubGrid");
                        } catch (Ia) {
                        }
                    if (this.p.multiselect) {
                        this.p.colNames.unshift("<input role='checkbox' id='cb_" + this.p.id + "' class='cbox' type='checkbox'/>");
                        this.p.colModel.unshift({
                            name: "cb",
                            width: C ? a.p.multiselectWidth + a.p.cellLayout :
                                a.p.multiselectWidth,
                            sortable: false,
                            resizable: false,
                            hidedlg: true,
                            search: false,
                            align: "center",
                            fixed: true
                        });
                    }
                    if (this.p.rownumbers) {
                        this.p.colNames.unshift("");
                        this.p.colModel.unshift({ name: "rn", width: a.p.rownumWidth, sortable: false, resizable: false, hidedlg: true, search: false, align: "center", fixed: true });
                    }
                    a.p.xmlReader = b.extend(true, {
                        root: "rows",
                        row: "row",
                        page: "rows>page",
                        total: "rows>total",
                        records: "rows>records",
                        repeatitems: true,
                        cell: "cell",
                        id: "[id]",
                        userdata: "userdata",
                        subgrid: {
                            root: "rows",
                            row: "row",
                            repeatitems: true,
                            cell: "cell"
                        }
                    }, a.p.xmlReader);
                    a.p.jsonReader = b.extend(true, { root: "rows", page: "page", total: "total", records: "records", repeatitems: true, cell: "cell", id: "id", userdata: "userdata", subgrid: { root: "rows", repeatitems: true, cell: "cell" } }, a.p.jsonReader);
                    if (a.p.scroll) {
                        a.p.pgbuttons = false;
                        a.p.pginput = false;
                        a.p.rowList = [];
                    }
                    var H = "<thead><tr class='ui-jqgrid-labels' role='rowheader'>", ya, ba, sa, ka, pa, I, A, ea;
                    ba = ea = "";
                    if (a.p.shrinkToFit === true && a.p.forceFit === true)
                        for (j = a.p.colModel.length - 1; j >= 0; j--)
                            if (!a.p.colModel[j].hidden) {
                                a.p.colModel[j].resizable =
                                    false;
                                break;
                            }
                    if (a.p.viewsortcols[1] == "horizontal") {
                        ea = " ui-i-asc";
                        ba = " ui-i-desc";
                    }
                    ya = x ? "class='ui-th-div-ie'" : "";
                    ea = "<span class='s-ico' style='display:none'><span sort='asc' class='ui-grid-ico-sort ui-icon-asc" + ea + " ui-state-disabled ui-icon ui-icon-triangle-1-n ui-sort-" + m + "'></span>";
                    ea += "<span sort='desc' class='ui-grid-ico-sort ui-icon-desc" + ba + " ui-state-disabled ui-icon ui-icon-triangle-1-s ui-sort-" + m + "'></span></span>";
                    for (j = 0; j < this.p.colNames.length; j++) {
                        ba = a.p.headertitles ? ' title="' + b.jgrid.stripHtml(a.p.colNames[j]) +
                            '"' : "";
                        H += "<th id='" + a.p.id + "_" + a.p.colModel[j].name + "' role='columnheader' class='ui-state-default ui-th-column ui-th-" + m + "'" + ba + ">";
                        ba = a.p.colModel[j].index || a.p.colModel[j].name;
                        H += "<div id='jqgh_" + a.p.colModel[j].name + "' " + ya + ">" + a.p.colNames[j];
                        a.p.colModel[j].width = a.p.colModel[j].width ? parseInt(a.p.colModel[j].width, 10) : 150;
                        if (typeof a.p.colModel[j].title !== "boolean")a.p.colModel[j].title = true;
                        if (ba == a.p.sortname)a.p.lastsort = j;
                        H += ea + "</div></th>";
                    }
                    H += "</tr></thead>";
                    b(this).append(H);
                    b("thead tr:first th",
                        this).hover(function() { b(this).addClass("ui-state-hover"); }, function() { b(this).removeClass("ui-state-hover"); });
                    if (this.p.multiselect) {
                        var ta = [], qa;
                        b("#cb_" + b.jgrid.jqID(a.p.id), this).bind("click", function() {
                            if (this.checked) {
                                b("[id^=jqg_]", a.rows).attr("checked", true);
                                b(a.rows).each(function(c) {
                                    if (!b(this).hasClass("subgrid")) {
                                        b(this).addClass("ui-state-highlight").attr("aria-selected", "true");
                                        a.p.selarrrow[c] = a.p.selrow = this.id;
                                    }
                                });
                                qa = true;
                                ta = [];
                            } else {
                                b("[id^=jqg_]", a.rows).attr("checked", false);
                                b(a.rows).each(function(c) {
                                    if (!b(this).hasClass("subgrid")) {
                                        b(this).removeClass("ui-state-highlight").attr("aria-selected",
                                            "false");
                                        ta[c] = this.id;
                                    }
                                });
                                a.p.selarrrow = [];
                                a.p.selrow = null;
                                qa = false;
                            }
                            if (b.isFunction(a.p.onSelectAll))a.p.onSelectAll.call(a, qa ? a.p.selarrrow : ta, qa);
                        });
                    }
                    if (a.p.autowidth === true) {
                        H = b(K).innerWidth();
                        a.p.width = H > 0 ? H : "nw";
                    }
                    (function() {
                        var c = 0, d = a.p.cellLayout, e = 0, l, n = a.p.scrollOffset, o, p = false, w, y = 0, s = 0, r = 0, v;
                        if (C)d = 0;
                        b.each(a.p.colModel, function() {
                            if (typeof this.hidden === "undefined")this.hidden = false;
                            if (this.hidden === false) {
                                c += J(this.width, 0);
                                if (this.fixed) {
                                    y += this.width;
                                    s += this.width + d;
                                } else e++;
                                r++;
                            }
                        });
                        if (isNaN(a.p.width))a.p.width = g.width = c;
                        else g.width = a.p.width;
                        a.p.tblwidth = c;
                        if (a.p.shrinkToFit === false && a.p.forceFit === true)a.p.forceFit = false;
                        if (a.p.shrinkToFit === true && e > 0) {
                            w = g.width - d * e - s;
                            if (!isNaN(a.p.height)) {
                                w -= n;
                                p = true;
                            }
                            c = 0;
                            b.each(a.p.colModel, function(z) {
                                if (this.hidden === false && !this.fixed) {
                                    this.width = o = Math.round(w * this.width / (a.p.tblwidth - y));
                                    c += o;
                                    l = z;
                                }
                            });
                            v = 0;
                            if (p) {
                                if (g.width - s - (c + d * e) !== n)v = g.width - s - (c + d * e) - n;
                            } else if (!p && Math.abs(g.width - s - (c + d * e)) !== 1)v = g.width - s - (c + d * e);
                            a.p.colModel[l].width +=
                                v;
                            a.p.tblwidth = c + v + y + r * d;
                            if (a.p.tblwidth > a.p.width) {
                                a.p.colModel[l].width -= a.p.tblwidth - parseInt(a.p.width, 10);
                                a.p.tblwidth = a.p.width;
                            }
                        }
                    })();
                    b(K).css("width", g.width + "px").append("<div class='ui-jqgrid-resize-mark' id='rs_m" + a.p.id + "'>&#160;</div>");
                    b(q).css("width", g.width + "px");
                    H = b("thead:first", a).get(0);
                    var ua = "<table role='grid' style='width:" + a.p.tblwidth + "px' class='ui-jqgrid-ftable' cellspacing='0' cellpadding='0' border='0'><tbody><tr role='row' class='ui-widget-content footrow footrow-" +
                        m + "'>";
                    q = b("tr:first", H);
                    a.p.disableClick = false;
                    b("th", q).each(function(c) {
                        sa = a.p.colModel[c].width;
                        if (typeof a.p.colModel[c].resizable === "undefined")a.p.colModel[c].resizable = true;
                        if (a.p.colModel[c].resizable) {
                            ka = document.createElement("span");
                            b(ka).html("&#160;").addClass("ui-jqgrid-resize ui-jqgrid-resize-" + m);
                            b.browser.opera || b(ka).css("cursor", "col-resize");
                            b(this).addClass(a.p.resizeclass);
                        } else ka = "";
                        b(this).css("width", sa + "px").prepend(ka);
                        a.p.colModel[c].hidden && b(this).css("display", "none");
                        g.headers[c] = { width: sa, el: this };
                        pa = a.p.colModel[c].sortable;
                        if (typeof pa !== "boolean")pa = a.p.colModel[c].sortable = true;
                        var d = a.p.colModel[c].name;
                        d == "cb" || d == "subgrid" || d == "rn" || a.p.viewsortcols[2] && b("div", this).addClass("ui-jqgrid-sortable");
                        if (pa)
                            if (a.p.viewsortcols[0]) {
                                b("div span.s-ico", this).show();
                                c == a.p.lastsort && b("div span.ui-icon-" + a.p.sortorder, this).removeClass("ui-state-disabled");
                            } else if (c == a.p.lastsort) {
                                b("div span.s-ico", this).show();
                                b("div span.ui-icon-" + a.p.sortorder, this).removeClass("ui-state-disabled");
                            }
                        ua +=
                            "<td role='gridcell' " + F(c, 0, "") + ">&#160;</td>";
                    }).mousedown(function(c) {
                        if (b(c.target).closest("th > span.ui-jqgrid-resize").length == 1) {
                            var d = b.jgrid.getCellIndex(this);
                            if (a.p.forceFit === true)a.p.nv = Ca(d);
                            g.dragStart(d, c, Da(d));
                            return false;
                        }
                    }).click(function(c) {
                        if (a.p.disableClick)return a.p.disableClick = false;
                        var d = "th>div.ui-jqgrid-sortable", e, l;
                        a.p.viewsortcols[2] || (d = "th>div>span>span.ui-grid-ico-sort");
                        c = b(c.target).closest(d);
                        if (c.length == 1) {
                            d = b.jgrid.getCellIndex(this);
                            if (!a.p.viewsortcols[2]) {
                                e =
                                    true;
                                l = c.attr("sort");
                            }
                            xa(b("div", this)[0].id, d, e, l);
                            return false;
                        }
                    });
                    if (a.p.sortable && b.fn.sortable)
                        try {
                            b(a).jqGrid("sortableColumns", q);
                        } catch (Ja) {
                        }
                    ua += "</tr></tbody></table>";
                    this.appendChild(document.createElement("tbody"));
                    b(this).addClass("ui-jqgrid-btable");
                    q = b("<table class='ui-jqgrid-htable' style='width:" + a.p.tblwidth + "px' role='grid' aria-labelledby='gbox_" + this.id + "' cellspacing='0' cellpadding='0' border='0'></table>").append(H);
                    var T = a.p.caption && a.p.hiddengrid === true ? true : false;
                    H = b("<div class='ui-jqgrid-hbox" +
                    (m == "rtl" ? "-rtl" : "") + "'></div>");
                    g.hDiv = document.createElement("div");
                    b(g.hDiv).css({ width: g.width + "px" }).addClass("ui-state-default ui-jqgrid-hdiv").append(H);
                    b(H).append(q);
                    T && b(g.hDiv).hide();
                    if (a.p.pager) {
                        if (typeof a.p.pager == "string") {
                            if (a.p.pager.substr(0, 1) != "#")a.p.pager = "#" + a.p.pager;
                        } else a.p.pager = "#" + b(a.p.pager).attr("id");
                        b(a.p.pager).css({ width: g.width + "px" }).appendTo(K).addClass("ui-state-default ui-jqgrid-pager ui-corner-bottom");
                        T && b(a.p.pager).hide();
                        t(a.p.pager, "");
                    }
                    a.p.cellEdit ===
                        false && a.p.hoverrows === true && b(a).bind("mouseover", function(c) {
                            A = b(c.target).closest("tr.jqgrow");
                            b(A).attr("class") !== "subgrid" && b(A).addClass("ui-state-hover");
                            return false;
                        }).bind("mouseout", function(c) {
                            A = b(c.target).closest("tr.jqgrow");
                            b(A).removeClass("ui-state-hover");
                            return false;
                        });
                    var Z, $;
                    b(a).before(g.hDiv).click(function(c) {
                        I = c.target;
                        var d = b(I).hasClass("cbox");
                        A = b(I, a.rows).closest("tr.jqgrow");
                        if (b(A).length === 0)return this;
                        var e = true;
                        if (b.isFunction(a.p.beforeSelectRow))
                            e = a.p.beforeSelectRow.call(a,
                                A[0].id, c);
                        if (I.tagName == "A" || (I.tagName == "INPUT" || I.tagName == "TEXTAREA" || I.tagName == "OPTION" || I.tagName == "SELECT") && !d)return this;
                        if (e === true) {
                            if (a.p.cellEdit === true)
                                if (a.p.multiselect && d)b(a).jqGrid("setSelection", A[0].id, true);
                                else {
                                    Z = A[0].rowIndex;
                                    $ = b.jgrid.getCellIndex(I);
                                    try {
                                        b(a).jqGrid("editCell", Z, $, true);
                                    } catch (l) {
                                    }
                                }
                            else if (a.p.multikey)
                                if (c[a.p.multikey])b(a).jqGrid("setSelection", A[0].id, true);
                                else {
                                    if (a.p.multiselect && d) {
                                        d = b("[id^=jqg_]", A).attr("checked");
                                        b("[id^=jqg_]", A).attr("checked",
                                            !d);
                                    }
                                }
                            else {
                                if (a.p.multiselect && a.p.multiboxonly)
                                    if (!d) {
                                        b(a.p.selarrrow).each(function(n, o) {
                                            n = a.rows.namedItem(o);
                                            b(n).removeClass("ui-state-highlight");
                                            b("#jqg_" + b.jgrid.jqID(o), n).attr("checked", false);
                                        });
                                        a.p.selarrrow = [];
                                        b("#cb_" + b.jgrid.jqID(a.p.id), a.grid.hDiv).attr("checked", false);
                                    }
                                b(a).jqGrid("setSelection", A[0].id, true);
                            }
                            if (b.isFunction(a.p.onCellSelect)) {
                                Z = A[0].id;
                                $ = b.jgrid.getCellIndex(I);
                                a.p.onCellSelect.call(a, Z, $, b(I).html(), c);
                            }
                            c.stopPropagation();
                        } else return this;
                    }).bind("reloadGrid", function(c,
                        d) {
                        if (a.p.treeGrid === true)a.p.datatype = a.p.treedatatype;
                        d && d.current && a.grid.selectionPreserver(a);
                        if (a.p.datatype == "local")b(a).jqGrid("resetSelection");
                        else if (!a.p.treeGrid) {
                            a.p.selrow = null;
                            if (a.p.multiselect) {
                                a.p.selarrrow = [];
                                b("#cb_" + b.jgrid.jqID(a.p.id), a.grid.hDiv).attr("checked", false);
                            }
                            a.p.savedRow = [];
                            a.p.scroll && aa(a.grid.bDiv, true);
                        }
                        if (d && d.page) {
                            c = d.page;
                            if (c > a.p.lastpage)c = a.p.lastpage;
                            if (c < 1)c = 1;
                            a.p.page = c;
                            a.grid.bDiv.scrollTop = a.grid.prevRowHeight ? (c - 1) * a.grid.prevRowHeight * a.p.rowNum :
                                0;
                        }
                        if (a.grid.prevRowHeight && a.p.scroll) {
                            delete a.p.lastpage;
                            a.grid.populateVisible();
                        } else a.grid.populate();
                        return false;
                    });
                    b.isFunction(this.p.ondblClickRow) && b(this).dblclick(function(c) {
                        I = c.target;
                        A = b(I, a.rows).closest("tr.jqgrow");
                        if (b(A).length === 0)return false;
                        Z = A[0].rowIndex;
                        $ = b.jgrid.getCellIndex(I);
                        a.p.ondblClickRow.call(a, b(A).attr("id"), Z, $, c);
                        return false;
                    });
                    b.isFunction(this.p.onRightClickRow) && b(this).bind("contextmenu", function(c) {
                        I = c.target;
                        A = b(I, a.rows).closest("tr.jqgrow");
                        if (b(A).length ===
                            0)return false;
                        a.p.multiselect || b(a).jqGrid("setSelection", A[0].id, true);
                        Z = A[0].rowIndex;
                        $ = b.jgrid.getCellIndex(I);
                        a.p.onRightClickRow.call(a, b(A).attr("id"), Z, $, c);
                        return false;
                    });
                    g.bDiv = document.createElement("div");
                    b(g.bDiv).append(b('<div style="position:relative;' + (x && b.browser.version < 8 ? "height:0.01%;" : "") + '"></div>').append("<div></div>").append(this)).addClass("ui-jqgrid-bdiv").css({ height: a.p.height + (isNaN(a.p.height) ? "" : "px"), width: g.width + "px" }).scroll(g.scrollGrid);
                    b("table:first", g.bDiv).css({
                        width: a.p.tblwidth +
                            "px"
                    });
                    if (x) {
                        b("tbody", this).size() == 2 && b("tbody:first", this).remove();
                        a.p.multikey && b(g.bDiv).bind("selectstart", function() { return false; });
                    } else a.p.multikey && b(g.bDiv).bind("mousedown", function() { return false; });
                    T && b(g.bDiv).hide();
                    g.cDiv = document.createElement("div");
                    var va = a.p.hidegrid === true ? b("<a role='link' href='javascript:void(0)'/>").addClass("ui-jqgrid-titlebar-close HeaderButton").hover(function() { va.addClass("ui-state-hover"); }, function() { va.removeClass("ui-state-hover"); }).append("<span class='ui-icon ui-icon-circle-triangle-n'></span>").css(m ==
                        "rtl" ? "left" : "right", "0px") : "";
                    b(g.cDiv).append(va).append("<span class='ui-jqgrid-title" + (m == "rtl" ? "-rtl" : "") + "'>" + a.p.caption + "</span>").addClass("ui-jqgrid-titlebar ui-widget-header ui-corner-top ui-helper-clearfix");
                    b(g.cDiv).insertBefore(g.hDiv);
                    if (a.p.toolbar[0]) {
                        g.uDiv = document.createElement("div");
                        if (a.p.toolbar[1] == "top")b(g.uDiv).insertBefore(g.hDiv);
                        else a.p.toolbar[1] == "bottom" && b(g.uDiv).insertAfter(g.hDiv);
                        if (a.p.toolbar[1] == "both") {
                            g.ubDiv = document.createElement("div");
                            b(g.uDiv).insertBefore(g.hDiv).addClass("ui-userdata ui-state-default").attr("id",
                                "t_" + this.id);
                            b(g.ubDiv).insertAfter(g.hDiv).addClass("ui-userdata ui-state-default").attr("id", "tb_" + this.id);
                            T && b(g.ubDiv).hide();
                        } else b(g.uDiv).width(g.width).addClass("ui-userdata ui-state-default").attr("id", "t_" + this.id);
                        T && b(g.uDiv).hide();
                    }
                    if (a.p.toppager) {
                        a.p.toppager = a.p.id + "_toppager";
                        g.topDiv = b("<div id='" + a.p.toppager + "'></div>")[0];
                        a.p.toppager = "#" + a.p.toppager;
                        b(g.topDiv).insertBefore(g.hDiv).addClass("ui-state-default ui-jqgrid-toppager").width(g.width);
                        t(a.p.toppager, "_t");
                    }
                    if (a.p.footerrow) {
                        g.sDiv =
                            b("<div class='ui-jqgrid-sdiv'></div>")[0];
                        H = b("<div class='ui-jqgrid-hbox" + (m == "rtl" ? "-rtl" : "") + "'></div>");
                        b(g.sDiv).append(H).insertAfter(g.hDiv).width(g.width);
                        b(H).append(ua);
                        g.footers = b(".ui-jqgrid-ftable", g.sDiv)[0].rows[0].cells;
                        if (a.p.rownumbers)g.footers[0].className = "ui-state-default jqgrid-rownum";
                        T && b(g.sDiv).hide();
                    }
                    if (a.p.caption) {
                        var Ea = a.p.datatype;
                        if (a.p.hidegrid === true) {
                            b(".ui-jqgrid-titlebar-close", g.cDiv).click(function(c) {
                                var d = b.isFunction(a.p.onHeaderClick);
                                if (a.p.gridstate ==
                                    "visible") {
                                    b(".ui-jqgrid-bdiv, .ui-jqgrid-hdiv", "#gview_" + a.p.id).slideUp("fast");
                                    a.p.pager && b(a.p.pager).slideUp("fast");
                                    a.p.toppager && b(a.p.toppager).slideUp("fast");
                                    if (a.p.toolbar[0] === true) {
                                        a.p.toolbar[1] == "both" && b(g.ubDiv).slideUp("fast");
                                        b(g.uDiv).slideUp("fast");
                                    }
                                    a.p.footerrow && b(".ui-jqgrid-sdiv", "#gbox_" + a.p.id).slideUp("fast");
                                    b("span", this).removeClass("ui-icon-circle-triangle-n").addClass("ui-icon-circle-triangle-s");
                                    a.p.gridstate = "hidden";
                                    b("#gbox_" + a.p.id).hasClass("ui-resizable") &&
                                        b(".ui-resizable-handle", "#gbox_" + a.p.id).hide();
                                    if (d)T || a.p.onHeaderClick.call(a, a.p.gridstate, c);
                                } else if (a.p.gridstate == "hidden") {
                                    b(".ui-jqgrid-hdiv, .ui-jqgrid-bdiv", "#gview_" + a.p.id).slideDown("fast");
                                    a.p.pager && b(a.p.pager).slideDown("fast");
                                    a.p.toppager && b(a.p.toppager).slideDown("fast");
                                    if (a.p.toolbar[0] === true) {
                                        a.p.toolbar[1] == "both" && b(g.ubDiv).slideDown("fast");
                                        b(g.uDiv).slideDown("fast");
                                    }
                                    a.p.footerrow && b(".ui-jqgrid-sdiv", "#gbox_" + a.p.id).slideDown("fast");
                                    b("span", this).removeClass("ui-icon-circle-triangle-s").addClass("ui-icon-circle-triangle-n");
                                    if (T) {
                                        a.p.datatype = Ea;
                                        Y();
                                        T = false;
                                    }
                                    a.p.gridstate = "visible";
                                    b("#gbox_" + a.p.id).hasClass("ui-resizable") && b(".ui-resizable-handle", "#gbox_" + a.p.id).show();
                                    d && a.p.onHeaderClick.call(a, a.p.gridstate, c);
                                }
                                return false;
                            });
                            if (T) {
                                a.p.datatype = "local";
                                b(".ui-jqgrid-titlebar-close", g.cDiv).trigger("click");
                            }
                        }
                    } else b(g.cDiv).hide();
                    b(g.hDiv).after(g.bDiv).mousemove(function(c) {
                        if (g.resizing) {
                            g.dragMove(c);
                            return false;
                        }
                    });
                    b(".ui-jqgrid-labels", g.hDiv).bind("selectstart", function() { return false; });
                    b(document).mouseup(function() {
                        if (g.resizing) {
                            g.dragEnd();
                            return false;
                        }
                        return true;
                    });
                    this.updateColumns = function() {
                        var c = this.rows[0], d = this;
                        if (c) {
                            b("td", c).each(function(e) { b(this).css("width", d.grid.headers[e].width + "px"); });
                            this.grid.cols = c.cells;
                        }
                        return this;
                    };
                    a.formatCol = F;
                    a.sortData = xa;
                    a.updatepager = na;
                    a.formatter = function(c, d, e, l, n) { return M(c, d, e, l, n); };
                    b.extend(g, { populate: Y, emptyRows: aa });
                    this.grid = g;
                    a.addXmlData = function(c) { ia(c, a.grid.bDiv); };
                    a.addJSONData = function(c) { ra(c, a.grid.bDiv); };
                    Y();
                    a.p.hiddengrid = false;
                    b(window).unload(function() { a = null; });
                }
            }
        });
    };
    b.jgrid.extend({
        getGridParam: function(f) {
            var k = this[0];
            if (k.grid)return f ? typeof k.p[f] != "undefined" ? k.p[f] : null : k.p;
        },
        setGridParam: function(f) { return this.each(function() { this.grid && typeof f === "object" && b.extend(true, this.p, f); }); },
        getDataIDs: function() {
            var f = [], k = 0, i;
            this.each(function() {
                if ((i = this.rows.length) && i > 0)
                    for (; k < i;) {
                        f[k] = this.rows[k].id;
                        k++;
                    }
            });
            return f;
        },
        setSelection: function(f, k) {
            return this.each(function() {
                function i(a) {
                    var q = b(h.grid.bDiv)[0].clientHeight,
                        t = b(h.grid.bDiv)[0].scrollTop,
                        x = h.rows[a].offsetTop;
                    a = h.rows[a].clientHeight;
                    if (x + a >= q + t)b(h.grid.bDiv)[0].scrollTop = x - (q + t) + a + t;
                    else if (x < q + t)if (x < t)b(h.grid.bDiv)[0].scrollTop = x;
                }

                var h = this, g, j, m;
                if (f !== undefined) {
                    k = k === false ? false : true;
                    if (j = h.rows.namedItem(f + "")) {
                        if (h.p.scrollrows === true) {
                            g = h.rows.namedItem(f).rowIndex;
                            g >= 0 && i(g);
                        }
                        if (h.p.multiselect) {
                            h.p.selrow = j.id;
                            m = b.inArray(h.p.selrow, h.p.selarrrow);
                            if (m === -1) {
                                j.className !== "ui-subgrid" && b(j).addClass("ui-state-highlight").attr("aria-selected", "true");
                                g = true;
                                b("#jqg_" + b.jgrid.jqID(h.p.selrow),
                                    h.rows[j.rowIndex]).attr("checked", g);
                                h.p.selarrrow.push(h.p.selrow);
                                h.p.onSelectRow && k && h.p.onSelectRow.call(h, h.p.selrow, g);
                            } else {
                                j.className !== "ui-subgrid" && b(j).removeClass("ui-state-highlight").attr("aria-selected", "false");
                                g = false;
                                b("#jqg_" + b.jgrid.jqID(h.p.selrow), h.rows[j.rowIndex]).attr("checked", g);
                                h.p.selarrrow.splice(m, 1);
                                h.p.onSelectRow && k && h.p.onSelectRow.call(h, h.p.selrow, g);
                                j = h.p.selarrrow[0];
                                h.p.selrow = j === undefined ? null : j;
                            }
                        } else if (j.className !== "ui-subgrid") {
                            h.p.selrow && b(h.rows.namedItem(h.p.selrow)).removeClass("ui-state-highlight").attr("aria-selected",
                                "false");
                            h.p.selrow = j.id;
                            b(j).addClass("ui-state-highlight").attr("aria-selected", "true");
                            h.p.onSelectRow && k && h.p.onSelectRow.call(h, h.p.selrow, true);
                        }
                    }
                }
            });
        },
        resetSelection: function() {
            return this.each(function() {
                var f = this, k;
                if (f.p.multiselect) {
                    b(f.p.selarrrow).each(function(i, h) {
                        k = f.rows.namedItem(h);
                        b(k).removeClass("ui-state-highlight").attr("aria-selected", "false");
                        b("#jqg_" + b.jgrid.jqID(h), k).attr("checked", false);
                    });
                    b("#cb_" + b.jgrid.jqID(f.p.id), f.grid.hDiv).attr("checked", false);
                    f.p.selarrrow =
                    [];
                } else if (f.p.selrow) {
                    b("tr#" + b.jgrid.jqID(f.p.selrow), f.grid.bDiv).removeClass("ui-state-highlight").attr("aria-selected", "false");
                    f.p.selrow = null;
                }
                f.p.savedRow = [];
            });
        },
        getRowData: function(f) {
            var k = {}, i, h = false, g, j = 0;
            this.each(function() {
                var m = this, a, q;
                if (typeof f == "undefined") {
                    h = true;
                    i = [];
                    g = m.rows.length;
                } else {
                    q = m.rows.namedItem(f);
                    if (!q)return k;
                    g = 1;
                }
                for (; j < g;) {
                    if (h)q = m.rows[j];
                    b("td", q).each(function(t) {
                        a = m.p.colModel[t].name;
                        if (a !== "cb" && a !== "subgrid")
                            if (m.p.treeGrid === true && a == m.p.ExpandColumn)
                                k[a] =
                                    b.jgrid.htmlDecode(b("span:first", this).html());
                            else
                                try {
                                    k[a] = b.unformat(this, { rowId: q.id, colModel: m.p.colModel[t] }, t);
                                } catch (x) {
                                    k[a] = b.jgrid.htmlDecode(b(this).html());
                                }
                    });
                    j++;
                    if (h) {
                        i.push(k);
                        k = {};
                    }
                }
            });
            return i ? i : k;
        },
        delRowData: function(f) {
            var k = false, i, h, g;
            this.each(function() {
                var j = this;
                if (i = j.rows.namedItem(f)) {
                    g = i.rowIndex;
                    b(i).remove();
                    j.p.records--;
                    j.p.reccount--;
                    j.updatepager(true, false);
                    k = true;
                    if (j.p.multiselect) {
                        h = b.inArray(f, j.p.selarrrow);
                        h != -1 && j.p.selarrrow.splice(h, 1);
                    }
                    if (f == j.p.selrow)
                        j.p.selrow =
                            null;
                } else return false;
                g === 0 && k && j.updateColumns();
                if (j.p.altRows === true && k) {
                    var m = j.p.altclass;
                    b(j.rows).each(function(a) { a % 2 == 1 ? b(this).addClass(m) : b(this).removeClass(m); });
                }
            });
            return k;
        },
        setRowData: function(f, k, i) {
            var h, g = false, j;
            this.each(function() {
                var m = this, a, q, t = typeof i;
                if (!m.grid)return false;
                q = m.rows.namedItem(f);
                if (!q)return false;
                k && b(this.p.colModel).each(function(x) {
                    h = this.name;
                    if (k[h] !== undefined) {
                        a = m.formatter(f, k[h], x, k, "edit");
                        j = this.title ? { title: b.jgrid.stripHtml(a) } : {};
                        m.p.treeGrid ===
                            true && h == m.p.ExpandColumn ? b("td:eq(" + x + ") > span:first", q).html(a).attr(j) : b("td:eq(" + x + ")", q).html(a).attr(j);
                        g = true;
                    }
                });
                if (t === "string")b(q).addClass(i);
                else t === "object" && b(q).css(i);
            });
            return g;
        },
        addRowData: function(f, k, i, h) {
            i || (i = "last");
            var g = false, j, m, a, q, t, x, C, K, J = "", F, Q, M, R;
            if (k) {
                if (b.isArray(k)) {
                    F = true;
                    i = "last";
                    Q = f;
                } else {
                    k = [k];
                    F = false;
                }
                this.each(function() {
                    var u = this, la = k.length;
                    t = u.p.rownumbers === true ? 1 : 0;
                    a = u.p.multiselect === true ? 1 : 0;
                    q = u.p.subGrid === true ? 1 : 0;
                    if (!F)
                        if (typeof f != "undefined")
                            f +=
                                "";
                        else {
                            f = u.p.records + 1 + "";
                            if (u.p.keyIndex !== false) {
                                Q = u.p.colModel[u.p.keyIndex + a + q + t].name;
                                if (typeof k[0][Q] != "undefined")f = k[0][Q];
                            }
                        }
                    M = u.p.altclass;
                    for (var ca = 0, fa = "", aa = b.isFunction(u.p.afterInsertRow) ? true : false; ca < la;) {
                        R = k[ca];
                        m = "";
                        if (F) {
                            try {
                                f = R[Q];
                            } catch (U) {
                                f = u.p.records + 1;
                            }
                            fa = u.p.altRows === true ? (u.rows.length - 1) % 2 === 0 ? M : "" : "";
                        }
                        if (t) {
                            J = u.formatCol(t, 1, "");
                            m += '<td role="gridcell" aria-describedby="' + u.p.id + '_rn" class="ui-state-default jqgrid-rownum" ' + J + ">0</td>";
                        }
                        if (a) {
                            K = '<input role="checkbox" type="checkbox" id="jqg_' +
                                f + '" class="cbox"/>';
                            J = u.formatCol(t, 1, "");
                            m += '<td role="gridcell" aria-describedby="' + u.p.id + '_cb" ' + J + ">" + K + "</td>";
                        }
                        if (q)m += b(u).jqGrid("addSubGridCell", a + t, 1);
                        for (C = a + q + t; C < this.p.colModel.length; C++) {
                            j = this.p.colModel[C].name;
                            K = u.formatter(f, R[j], C, R, "add");
                            J = u.formatCol(C, 1, K);
                            m += '<td role="gridcell" aria-describedby="' + u.p.id + "_" + j + '" ' + J + ">" + K + "</td>";
                        }
                        m = '<tr id="' + f + '" role="row" class="ui-widget-content jqgrow ui-row-' + u.p.direction + " " + fa + '">' + m + "</tr>";
                        if (u.p.subGrid === true) {
                            m = b(m)[0];
                            b(u).jqGrid("addSubGrid",
                                m, a + t);
                        }
                        if (u.rows.length === 0)b("table:first", u.grid.bDiv).append(m);
                        else
                            switch (i) {
                            case "last":
                                b(u.rows[u.rows.length - 1]).after(m);
                                break;
                            case "first":
                                b(u.rows[0]).before(m);
                                break;
                            case "after":
                                if (x = u.rows.namedItem(h))b(u.rows[x.rowIndex + 1]).hasClass("ui-subgrid") ? b(u.rows[x.rowIndex + 1]).after(m) : b(x).after(m);
                                break;
                            case "before":
                                if (x = u.rows.namedItem(h)) {
                                    b(x).before(m);
                                    x = x.rowIndex;
                                }
                                break;
                            }
                        u.p.records++;
                        u.p.reccount++;
                        if (!u.grid.cols || !u.grid.cols.length)u.grid.cols = u.rows[0].cells;
                        if (i === "first" || i ===
                            "before" && x <= 1 || u.rows.length === 1)u.updateColumns();
                        aa && u.p.afterInsertRow.call(u, f, R, R);
                        ca++;
                    }
                    if (u.p.altRows === true && !F)
                        if (i == "last")(u.rows.length - 1) % 2 == 1 && b(u.rows[u.rows.length - 1]).addClass(M);
                        else b(u.rows).each(function(ia) { ia % 2 == 1 ? b(this).addClass(M) : b(this).removeClass(M); });
                    u.updatepager(true, true);
                    g = true;
                });
            }
            return g;
        },
        footerData: function(f, k, i) {
            function h(q) {
                for (var t in q)if (q.hasOwnProperty(t))return false;
                return true;
            }

            var g, j = false, m = {}, a;
            if (typeof f == "undefined")f = "get";
            if (typeof i != "boolean")
                i =
                    true;
            f = f.toLowerCase();
            this.each(function() {
                var q = this, t;
                if (!q.grid || !q.p.footerrow)return false;
                if (f == "set")if (h(k))return false;
                j = true;
                b(this.p.colModel).each(function(x) {
                    g = this.name;
                    if (f == "set") {
                        if (k[g] !== undefined) {
                            t = i ? q.formatter("", k[g], x, k, "edit") : k[g];
                            a = this.title ? { title: b.jgrid.stripHtml(t) } : {};
                            b("tr.footrow td:eq(" + x + ")", q.grid.sDiv).html(t).attr(a);
                            j = true;
                        }
                    } else if (f == "get")m[g] = b("tr.footrow td:eq(" + x + ")", q.grid.sDiv).html();
                });
            });
            return f == "get" ? m : j;
        },
        ShowHideCol: function(f, k) {
            return this.each(function() {
                var i =
                        this,
                    h = false;
                if (i.grid) {
                    if (typeof f === "string")f = [f];
                    k = k != "none" ? "" : "none";
                    var g = k == "" ? true : false;
                    b(this.p.colModel).each(function(j) {
                        if (b.inArray(this.name, f) !== -1 && this.hidden === g) {
                            b("tr", i.grid.hDiv).each(function() { b("th:eq(" + j + ")", this).css("display", k); });
                            b(i.rows).each(function(m) { b("td:eq(" + j + ")", i.rows[m]).css("display", k); });
                            i.p.footerrow && b("td:eq(" + j + ")", i.grid.sDiv).css("display", k);
                            if (k == "none")i.p.tblwidth -= this.width;
                            else i.p.tblwidth += this.width;
                            this.hidden = !g;
                            h = true;
                        }
                    });
                    if (h === true) {
                        b("table:first",
                            i.grid.hDiv).width(i.p.tblwidth);
                        b("table:first", i.grid.bDiv).width(i.p.tblwidth);
                        i.grid.hDiv.scrollLeft = i.grid.bDiv.scrollLeft;
                        if (i.p.footerrow) {
                            b("table:first", i.grid.sDiv).width(i.p.tblwidth);
                            i.grid.sDiv.scrollLeft = i.grid.bDiv.scrollLeft;
                        }
                    }
                }
            });
        },
        hideCol: function(f) { return this.each(function() { b(this).jqGrid("ShowHideCol", f, "none"); }); },
        showCol: function(f) { return this.each(function() { b(this).jqGrid("ShowHideCol", f, ""); }); },
        remapColumns: function(f, k, i) {
            function h(m) {
                var a;
                a = m.length ? b.makeArray(m) : b.extend({},
                    m);
                b.each(f, function(q) { m[q] = a[this]; });
            }

            function g(m, a) {
                b(">tr" + (a || ""), m).each(function() {
                    var q = this, t = b.makeArray(q.cells);
                    b.each(f, function() {
                        var x = t[this];
                        x && q.appendChild(x);
                    });
                });
            }

            var j = this.get(0);
            h(j.p.colModel);
            h(j.p.colNames);
            h(j.grid.headers);
            g(b("thead:first", j.grid.hDiv), i && ":not(.ui-jqgrid-labels)");
            k && g(b("tbody:first", j.grid.bDiv), ".jqgrow");
            j.p.footerrow && g(b("tbody:first", j.grid.sDiv));
            if (j.p.remapColumns)
                if (j.p.remapColumns.length)h(j.p.remapColumns);
                else j.p.remapColumns = b.makeArray(f);
            j.p.lastsort = b.inArray(j.p.lastsort, f);
            if (j.p.treeGrid)j.p.expColInd = b.inArray(j.p.expColInd, f);
        },
        setGridWidth: function(f, k) {
            return this.each(function() {
                var i = this, h, g = 0, j = i.p.cellLayout, m, a = 0, q = false, t = i.p.scrollOffset, x, C = 0, K = 0, J = 0, F;
                if (i.grid) {
                    if (typeof k != "boolean")k = i.p.shrinkToFit;
                    if (!isNaN(f)) {
                        f = parseInt(f, 10);
                        i.grid.width = i.p.width = f;
                        b("#gbox_" + i.p.id).css("width", f + "px");
                        b("#gview_" + i.p.id).css("width", f + "px");
                        b(i.grid.bDiv).css("width", f + "px");
                        b(i.grid.hDiv).css("width", f + "px");
                        i.p.pager &&
                            b(i.p.pager).css("width", f + "px");
                        i.p.toppager && b(i.p.toppager).css("width", f + "px");
                        if (i.p.toolbar[0] === true) {
                            b(i.grid.uDiv).css("width", f + "px");
                            i.p.toolbar[1] == "both" && b(i.grid.ubDiv).css("width", f + "px");
                        }
                        i.p.footerrow && b(i.grid.sDiv).css("width", f + "px");
                        if (k === false && i.p.forceFit === true)i.p.forceFit = false;
                        if (k === true) {
                            if (b.browser.safari)j = 0;
                            b.each(i.p.colModel, function() {
                                if (this.hidden === false) {
                                    g += parseInt(this.width, 10);
                                    if (this.fixed) {
                                        K += this.width;
                                        C += this.width + j;
                                    } else a++;
                                    J++;
                                }
                            });
                            if (a !== 0) {
                                i.p.tblwidth =
                                    g;
                                x = f - j * a - C;
                                if (!isNaN(i.p.height))
                                    if (b(i.grid.bDiv)[0].clientHeight < b(i.grid.bDiv)[0].scrollHeight) {
                                        q = true;
                                        x -= t;
                                    }
                                g = 0;
                                var Q = i.grid.cols.length > 0;
                                b.each(i.p.colModel, function(M) {
                                    if (this.hidden === false && !this.fixed) {
                                        h = Math.round(x * this.width / (i.p.tblwidth - K));
                                        if (!(h < 0)) {
                                            this.width = h;
                                            g += h;
                                            i.grid.headers[M].width = h;
                                            i.grid.headers[M].el.style.width = h + "px";
                                            if (i.p.footerrow)i.grid.footers[M].style.width = h + "px";
                                            if (Q)i.grid.cols[M].style.width = h + "px";
                                            m = M;
                                        }
                                    }
                                });
                                F = 0;
                                if (q) {
                                    if (f - C - (g + j * a) !== t)F = f - C - (g + j * a) - t;
                                } else if (Math.abs(f -
                                    C - (g + j * a)) !== 1)F = f - C - (g + j * a);
                                i.p.colModel[m].width += F;
                                i.p.tblwidth = g + F + K + j * J;
                                if (i.p.tblwidth > f) {
                                    q = i.p.tblwidth - parseInt(f, 10);
                                    i.p.tblwidth = f;
                                    h = i.p.colModel[m].width -= q;
                                } else h = i.p.colModel[m].width;
                                i.grid.headers[m].width = h;
                                i.grid.headers[m].el.style.width = h + "px";
                                if (Q)i.grid.cols[m].style.width = h + "px";
                                b("table:first", i.grid.bDiv).css("width", i.p.tblwidth + "px");
                                b("table:first", i.grid.hDiv).css("width", i.p.tblwidth + "px");
                                i.grid.hDiv.scrollLeft = i.grid.bDiv.scrollLeft;
                                if (i.p.footerrow) {
                                    i.grid.footers[m].style.width =
                                        h + "px";
                                    b("table:first", i.grid.sDiv).css("width", i.p.tblwidth + "px");
                                }
                            }
                        }
                    }
                }
            });
        },
        setGridHeight: function(f) {
            return this.each(function() {
                var k = this;
                if (k.grid) {
                    b(k.grid.bDiv).css({ height: f + (isNaN(f) ? "" : "px") });
                    k.p.height = f;
                    k.p.scroll && k.grid.populateVisible();
                }
            });
        },
        setCaption: function(f) {
            return this.each(function() {
                this.p.caption = f;
                b("span.ui-jqgrid-title", this.grid.cDiv).html(f);
                b(this.grid.cDiv).show();
            });
        },
        setLabel: function(f, k, i, h) {
            return this.each(function() {
                var g = this, j = -1;
                if (g.grid) {
                    if (isNaN(f))
                        b(g.p.colModel).each(function(q) {
                            if (this.name ==
                                f) {
                                j = q;
                                return false;
                            }
                        });
                    else j = parseInt(f, 10);
                    if (j >= 0) {
                        var m = b("tr.ui-jqgrid-labels th:eq(" + j + ")", g.grid.hDiv);
                        if (k) {
                            var a = b(".s-ico", m);
                            b("[id^=jqgh_]", m).empty().html(k).append(a);
                            g.p.colNames[j] = k;
                        }
                        if (i)typeof i === "string" ? b(m).addClass(i) : b(m).css(i);
                        typeof h === "object" && b(m).attr(h);
                    }
                }
            });
        },
        setCell: function(f, k, i, h, g, j) {
            return this.each(function() {
                var m = this, a = -1, q, t;
                if (m.grid) {
                    if (isNaN(k))
                        b(m.p.colModel).each(function(C) {
                            if (this.name == k) {
                                a = C;
                                return false;
                            }
                        });
                    else a = parseInt(k, 10);
                    if (a >= 0)
                        if (q = m.rows.namedItem(f)) {
                            var x =
                                b("td:eq(" + a + ")", q);
                            if (i !== "" || j === true) {
                                q = m.formatter(f, i, a, q, "edit");
                                t = m.p.colModel[a].title ? { title: b.jgrid.stripHtml(q) } : {};
                                m.p.treeGrid && b(".tree-wrap", b(x)).length > 0 ? b("span", b(x)).html(q).attr(t) : b(x).html(q).attr(t);
                            }
                            if (typeof h === "string")b(x).addClass(h);
                            else h && b(x).css(h);
                            typeof g === "object" && b(x).attr(g);
                        }
                }
            });
        },
        getCell: function(f, k) {
            var i = false;
            this.each(function() {
                var h = this, g = -1;
                if (h.grid) {
                    if (isNaN(k))
                        b(h.p.colModel).each(function(a) {
                            if (this.name === k) {
                                g = a;
                                return false;
                            }
                        });
                    else
                        g = parseInt(k,
                            10);
                    if (g >= 0) {
                        var j = h.rows.namedItem(f);
                        if (j)
                            try {
                                i = b.unformat(b("td:eq(" + g + ")", j), { rowId: j.id, colModel: h.p.colModel[g] }, g);
                            } catch (m) {
                                i = b.jgrid.htmlDecode(b("td:eq(" + g + ")", j).html());
                            }
                    }
                }
            });
            return i;
        },
        getCol: function(f, k, i) {
            var h = [], g, j = 0;
            k = typeof k != "boolean" ? false : k;
            if (typeof i == "undefined")i = false;
            this.each(function() {
                var m = this, a = -1;
                if (m.grid) {
                    if (isNaN(f))
                        b(m.p.colModel).each(function(C) {
                            if (this.name === f) {
                                a = C;
                                return false;
                            }
                        });
                    else a = parseInt(f, 10);
                    if (a >= 0) {
                        var q = m.rows.length, t = 0;
                        if (q && q > 0) {
                            for (; t < q;) {
                                try {
                                    g =
                                        b.unformat(b(m.rows[t].cells[a]), { rowId: m.rows[t].id, colModel: m.p.colModel[a] }, a);
                                } catch (x) {
                                    g = b.jgrid.htmlDecode(m.rows[t].cells[a].innerHTML);
                                }
                                if (i)j += parseFloat(g);
                                else if (k)h.push({ id: m.rows[t].id, value: g });
                                else h[t] = g;
                                t++;
                            }
                            if (i)
                                switch (i.toLowerCase()) {
                                case "sum":
                                    h = j;
                                    break;
                                case "avg":
                                    h = j / q;
                                    break;
                                case "count":
                                    h = q;
                                    break;
                                }
                        }
                    }
                }
            });
            return h;
        },
        clearGridData: function(f) {
            return this.each(function() {
                var k = this;
                if (k.grid) {
                    if (typeof f != "boolean")f = false;
                    b("tbody:first tr", k.grid.bDiv).remove();
                    k.p.footerrow && f &&
                        b(".ui-jqgrid-ftable td", k.grid.sDiv).html("&#160;");
                    k.p.selrow = null;
                    k.p.selarrrow = [];
                    k.p.savedRow = [];
                    k.p.records = 0;
                    k.p.page = "0";
                    k.p.lastpage = "0";
                    k.p.reccount = 0;
                    k.updatepager(true, false);
                }
            });
        },
        getInd: function(f, k) {
            var i = false, h;
            this.each(function() { if (h = this.rows.namedItem(f))i = k === true ? h : h.rowIndex; });
            return i;
        }
    });
})(jQuery);
(function(a) {
    a.jgrid.extend({
        getColProp: function(g) {
            var d = {}, b = this[0];
            if (b.grid) {
                b = b.p.colModel;
                for (var n = 0; n < b.length; n++)
                    if (b[n].name == g) {
                        d = b[n];
                        break;
                    }
                return d;
            }
        },
        setColProp: function(g, d) {
            return this.each(function() {
                if (this.grid)
                    if (d)
                        for (var b = this.p.colModel, n = 0; n < b.length; n++)
                            if (b[n].name == g) {
                                a.extend(this.p.colModel[n], d);
                                break;
                            }
            });
        },
        sortGrid: function(g, d, b) {
            return this.each(function() {
                var n = this, s = -1;
                if (n.grid) {
                    if (!g)g = n.p.sortname;
                    for (var q = 0; q < n.p.colModel.length; q++)
                        if (n.p.colModel[q].index ==
                            g || n.p.colModel[q].name == g) {
                            s = q;
                            break;
                        }
                    if (s != -1) {
                        q = n.p.colModel[s].sortable;
                        if (typeof q !== "boolean")q = true;
                        if (typeof d !== "boolean")d = false;
                        q && n.sortData("jqgh_" + g, s, d, b);
                    }
                }
            });
        },
        GridDestroy: function() {
            return this.each(function() {
                if (this.grid) {
                    this.p.pager && a(this.p.pager).remove();
                    var g = this.id;
                    try {
                        a("#gbox_" + g).remove();
                    } catch (d) {
                    }
                }
            });
        },
        GridUnload: function() {
            return this.each(function() {
                if (this.grid) {
                    var g = { id: a(this).attr("id"), cl: a(this).attr("class") };
                    this.p.pager && a(this.p.pager).empty().removeClass("ui-state-default ui-jqgrid-pager corner-bottom");
                    var d = document.createElement("table");
                    a(d).attr({ id: g.id });
                    d.className = g.cl;
                    g = this.id;
                    a(d).removeClass("ui-jqgrid-btable");
                    if (a(this.p.pager).parents("#gbox_" + g).length === 1) {
                        a(d).insertBefore("#gbox_" + g).show();
                        a(this.p.pager).insertBefore("#gbox_" + g);
                    } else a(d).insertBefore("#gbox_" + g).show();
                    a("#gbox_" + g).remove();
                }
            });
        },
        setGridState: function(g) {
            return this.each(function() {
                if (this.grid) {
                    var d = this;
                    if (g == "hidden") {
                        a(".ui-jqgrid-bdiv, .ui-jqgrid-hdiv", "#gview_" + d.p.id).slideUp("fast");
                        d.p.pager && a(d.p.pager).slideUp("fast");
                        d.p.toppager && a(d.p.toppager).slideUp("fast");
                        if (d.p.toolbar[0] === true) {
                            d.p.toolbar[1] == "both" && a(d.grid.ubDiv).slideUp("fast");
                            a(d.grid.uDiv).slideUp("fast");
                        }
                        d.p.footerrow && a(".ui-jqgrid-sdiv", "#gbox_" + d.p.id).slideUp("fast");
                        a(".ui-jqgrid-titlebar-close span", d.grid.cDiv).removeClass("ui-icon-circle-triangle-n").addClass("ui-icon-circle-triangle-s");
                        d.p.gridstate = "hidden";
                    } else if (g == "visible") {
                        a(".ui-jqgrid-hdiv, .ui-jqgrid-bdiv", "#gview_" + d.p.id).slideDown("fast");
                        d.p.pager && a(d.p.pager).slideDown("fast");
                        d.p.toppager && a(d.p.toppager).slideDown("fast");
                        if (d.p.toolbar[0] === true) {
                            d.p.toolbar[1] == "both" && a(d.grid.ubDiv).slideDown("fast");
                            a(d.grid.uDiv).slideDown("fast");
                        }
                        d.p.footerrow && a(".ui-jqgrid-sdiv", "#gbox_" + d.p.id).slideDown("fast");
                        a(".ui-jqgrid-titlebar-close span", d.grid.cDiv).removeClass("ui-icon-circle-triangle-s").addClass("ui-icon-circle-triangle-n");
                        d.p.gridstate = "visible";
                    }
                }
            });
        },
        updateGridRows: function(g, d, b) {
            var n, s = false, q;
            this.each(function() {
                var h = this, l, o, c, f;
                if (!h.grid)return false;
                d || (d = "id");
                g && g.length > 0 && a(g).each(function() {
                    c = this;
                    if (o = h.rows.namedItem(c[d])) {
                        f = c[d];
                        if (b === true)
                            if (h.p.jsonReader.repeatitems === true) {
                                if (h.p.jsonReader.cell)c = c[h.p.jsonReader.cell];
                                for (var e = 0; e < c.length; e++) {
                                    l = h.formatter(f, c[e], e, c, "edit");
                                    q = h.p.colModel[e].title ? { title: a.jgrid.stripHtml(l) } : {};
                                    h.p.treeGrid === true && n == h.p.ExpandColumn ? a("td:eq(" + e + ") > span:first", o).html(l).attr(q) : a("td:eq(" + e + ")", o).html(l).attr(q);
                                }
                                return s = true;
                            }
                        a(h.p.colModel).each(function(m) {
                            n = b === true ? this.jsonmap ||
                                this.name : this.name;
                            if (c[n] !== undefined) {
                                l = h.formatter(f, c[n], m, c, "edit");
                                q = this.title ? { title: a.jgrid.stripHtml(l) } : {};
                                h.p.treeGrid === true && n == h.p.ExpandColumn ? a("td:eq(" + m + ") > span:first", o).html(l).attr(q) : a("td:eq(" + m + ")", o).html(l).attr(q);
                                s = true;
                            }
                        });
                    }
                });
            });
            return s;
        },
        filterGrid: function(g, d) {
            d = a.extend({
                gridModel: false,
                gridNames: false,
                gridToolbar: false,
                filterModel: [],
                formtype: "horizontal",
                autosearch: true,
                formclass: "filterform",
                tableclass: "filtertable",
                buttonclass: "filterbutton",
                searchButton: "Search",
                clearButton: "Clear",
                enableSearch: false,
                enableClear: false,
                beforeSearch: null,
                afterSearch: null,
                beforeClear: null,
                afterClear: null,
                url: "",
                marksearched: true
            }, d || {});
            return this.each(function() {
                var b = this;
                this.p = d;
                if (this.p.filterModel.length === 0 && this.p.gridModel === false)alert("No filter is set");
                else if (g) {
                    this.p.gridid = g.indexOf("#") != -1 ? g : "#" + g;
                    var n = a(this.p.gridid).jqGrid("getGridParam", "colModel");
                    if (n) {
                        if (this.p.gridModel === true) {
                            var s = a(this.p.gridid)[0], q;
                            a.each(n, function(f) {
                                var e = [];
                                this.search =
                                    this.search === false ? false : true;
                                q = this.editrules && this.editrules.searchhidden === true ? true : this.hidden === true ? false : true;
                                if (this.search === true && q === true) {
                                    e.label = b.p.gridNames === true ? s.p.colNames[f] : "";
                                    e.name = this.name;
                                    e.index = this.index || this.name;
                                    e.stype = this.edittype || "text";
                                    if (e.stype != "select")e.stype = "text";
                                    e.defval = this.defval || "";
                                    e.surl = this.surl || "";
                                    e.sopt = this.editoptions || {};
                                    e.width = this.width;
                                    b.p.filterModel.push(e);
                                }
                            });
                        } else
                            a.each(b.p.filterModel, function() {
                                for (var f = 0; f < n.length; f++)
                                    if (this.name ==
                                        n[f].name) {
                                        this.index = n[f].index || this.name;
                                        break;
                                    }
                                if (!this.index)this.index = this.name;
                            });
                        var h = function() {
                                var f = {}, e = 0, m, i = a(b.p.gridid)[0], k;
                                i.p.searchdata = {};
                                a.isFunction(b.p.beforeSearch) && b.p.beforeSearch();
                                a.each(b.p.filterModel, function() {
                                    k = this.index;
                                    switch (this.stype) {
                                    case "select":
                                        if (m = a("select[name=" + k + "]", b).val()) {
                                            f[k] = m;
                                            b.p.marksearched && a("#jqgh_" + this.name, i.grid.hDiv).addClass("dirty-cell");
                                            e++;
                                        } else {
                                            b.p.marksearched && a("#jqgh_" + this.name, i.grid.hDiv).removeClass("dirty-cell");
                                            try {
                                                delete i.p.postData[this.index];
                                            } catch (r) {
                                            }
                                        }
                                        break;
                                    default:
                                        if (m = a("input[name=" + k + "]", b).val()) {
                                            f[k] = m;
                                            b.p.marksearched && a("#jqgh_" + this.name, i.grid.hDiv).addClass("dirty-cell");
                                            e++;
                                        } else {
                                            b.p.marksearched && a("#jqgh_" + this.name, i.grid.hDiv).removeClass("dirty-cell");
                                            try {
                                                delete i.p.postData[this.index];
                                            } catch (u) {
                                            }
                                        }
                                    }
                                });
                                var p = e > 0 ? true : false;
                                a.extend(i.p.postData, f);
                                var j;
                                if (b.p.url) {
                                    j = a(i).jqGrid("getGridParam", "url");
                                    a(i).jqGrid("setGridParam", { url: b.p.url });
                                }
                                a(i).jqGrid("setGridParam", { search: p }).trigger("reloadGrid", [{ page: 1 }]);
                                j && a(i).jqGrid("setGridParam",
                                { url: j });
                                a.isFunction(b.p.afterSearch) && b.p.afterSearch();
                            },
                            l = function() {
                                var f = {}, e, m = 0, i = a(b.p.gridid)[0], k;
                                a.isFunction(b.p.beforeClear) && b.p.beforeClear();
                                a.each(b.p.filterModel, function() {
                                    k = this.index;
                                    e = this.defval ? this.defval : "";
                                    if (!this.stype)this.stype = "text";
                                    switch (this.stype) {
                                    case "select":
                                        var r;
                                        a("select[name=" + k + "] option", b).each(function(v) {
                                            if (v === 0)this.selected = true;
                                            if (a(this).text() == e) {
                                                this.selected = true;
                                                r = a(this).val();
                                                return false;
                                            }
                                        });
                                        if (r) {
                                            f[k] = r;
                                            b.p.marksearched && a("#jqgh_" + this.name,
                                                i.grid.hDiv).addClass("dirty-cell");
                                            m++;
                                        } else {
                                            b.p.marksearched && a("#jqgh_" + this.name, i.grid.hDiv).removeClass("dirty-cell");
                                            try {
                                                delete i.p.postData[this.index];
                                            } catch (u) {
                                            }
                                        }
                                        break;
                                    case "text":
                                        a("input[name=" + k + "]", b).val(e);
                                        if (e) {
                                            f[k] = e;
                                            b.p.marksearched && a("#jqgh_" + this.name, i.grid.hDiv).addClass("dirty-cell");
                                            m++;
                                        } else {
                                            b.p.marksearched && a("#jqgh_" + this.name, i.grid.hDiv).removeClass("dirty-cell");
                                            try {
                                                delete i.p.postData[this.index];
                                            } catch (t) {
                                            }
                                        }
                                        break;
                                    }
                                });
                                var p = m > 0 ? true : false;
                                a.extend(i.p.postData, f);
                                var j;
                                if (b.p.url) {
                                    j = a(i).jqGrid("getGridParam", "url");
                                    a(i).jqGrid("setGridParam", { url: b.p.url });
                                }
                                a(i).jqGrid("setGridParam", { search: p }).trigger("reloadGrid", [{ page: 1 }]);
                                j && a(i).jqGrid("setGridParam", { url: j });
                                a.isFunction(b.p.afterClear) && b.p.afterClear();
                            },
                            o = a("<form name='SearchForm' style=display:inline;' class='" + this.p.formclass + "'></form>"),
                            c = a("<table class='" + this.p.tableclass + "' cellspacing='0' cellpading='0' border='0'><tbody></tbody></table>");
                        a(o).append(c);
                        (function() {
                            var f = document.createElement("tr"),
                                e,
                                m,
                                i,
                                k;
                            b.p.formtype == "horizontal" && a(c).append(f);
                            a.each(b.p.filterModel, function(p) {
                                i = document.createElement("td");
                                a(i).append("<label for='" + this.name + "'>" + this.label + "</label>");
                                k = document.createElement("td");
                                var j = this;
                                if (!this.stype)this.stype = "text";
                                switch (this.stype) {
                                case "select":
                                    if (this.surl)
                                        a(k).load(this.surl, function() {
                                            j.defval && a("select", this).val(j.defval);
                                            a("select", this).attr({ name: j.index || j.name, id: "sg_" + j.name });
                                            j.sopt && a("select", this).attr(j.sopt);
                                            b.p.gridToolbar === true && j.width &&
                                                a("select", this).width(j.width);
                                            b.p.autosearch === true && a("select", this).change(function() {
                                                h();
                                                return false;
                                            });
                                        });
                                    else if (j.sopt.value) {
                                        var r = j.sopt.value, u = document.createElement("select");
                                        a(u).attr({ name: j.index || j.name, id: "sg_" + j.name }).attr(j.sopt);
                                        var t;
                                        if (typeof r === "string") {
                                            p = r.split(";");
                                            for (var v = 0; v < p.length; v++) {
                                                r = p[v].split(":");
                                                t = document.createElement("option");
                                                t.value = r[0];
                                                t.innerHTML = r[1];
                                                if (r[1] == j.defval)t.selected = "selected";
                                                u.appendChild(t);
                                            }
                                        } else if (typeof r === "object")
                                            for (v in r)
                                                if (r.hasOwnProperty(v)) {
                                                    p++;
                                                    t = document.createElement("option");
                                                    t.value = v;
                                                    t.innerHTML = r[v];
                                                    if (r[v] == j.defval)t.selected = "selected";
                                                    u.appendChild(t);
                                                }
                                        b.p.gridToolbar === true && j.width && a(u).width(j.width);
                                        a(k).append(u);
                                        b.p.autosearch === true && a(u).change(function() {
                                            h();
                                            return false;
                                        });
                                    }
                                    break;
                                case "text":
                                    u = this.defval ? this.defval : "";
                                    a(k).append("<input type='text' name='" + (this.index || this.name) + "' id='sg_" + this.name + "' value='" + u + "'/>");
                                    j.sopt && a("input", k).attr(j.sopt);
                                    if (b.p.gridToolbar === true && j.width)
                                        a.browser.msie ? a("input", k).width(j.width -
                                            4) : a("input", k).width(j.width - 2);
                                    b.p.autosearch === true && a("input", k).keypress(function(w) {
                                        if ((w.charCode ? w.charCode : w.keyCode ? w.keyCode : 0) == 13) {
                                            h();
                                            return false;
                                        }
                                        return this;
                                    });
                                    break;
                                }
                                if (b.p.formtype == "horizontal") {
                                    b.p.gridToolbar === true && b.p.gridNames === false ? a(f).append(k) : a(f).append(i).append(k);
                                    a(f).append(k);
                                } else {
                                    e = document.createElement("tr");
                                    a(e).append(i).append(k);
                                    a(c).append(e);
                                }
                            });
                            k = document.createElement("td");
                            if (b.p.enableSearch === true) {
                                m = "<input type='button' id='sButton' class='" + b.p.buttonclass +
                                    "' value='" + b.p.searchButton + "'/>";
                                a(k).append(m);
                                a("input#sButton", k).click(function() {
                                    h();
                                    return false;
                                });
                            }
                            if (b.p.enableClear === true) {
                                m = "<input type='button' id='cButton' class='" + b.p.buttonclass + "' value='" + b.p.clearButton + "'/>";
                                a(k).append(m);
                                a("input#cButton", k).click(function() {
                                    l();
                                    return false;
                                });
                            }
                            if (b.p.enableClear === true || b.p.enableSearch === true)
                                if (b.p.formtype == "horizontal")a(f).append(k);
                                else {
                                    e = document.createElement("tr");
                                    a(e).append("<td>&#160;</td>").append(k);
                                    a(c).append(e);
                                }
                        })();
                        a(this).append(o);
                        this.triggerSearch = h;
                        this.clearSearch = l;
                    } else alert("Could not get grid colModel");
                } else alert("No target grid is set!");
            });
        },
        filterToolbar: function(g) {
            g = a.extend({ autosearch: true, searchOnEnter: true, beforeSearch: null, afterSearch: null, beforeClear: null, afterClear: null, searchurl: "", stringResult: false, groupOp: "AND" }, g || {});
            return this.each(function() {
                function d(h, l) {
                    var o = a(h);
                    o[0] && jQuery.each(l, function() { this.data !== undefined ? o.bind(this.type, this.data, this.fn) : o.bind(this.type, this.fn); });
                }

                var b = this,
                    n =
                        function() {
                            var h = {}, l = 0, o, c, f = {};
                            a.each(b.p.colModel, function() {
                                c = this.index || this.name;
                                var j = this.searchoptions && this.searchoptions.sopt ? this.searchoptions.sopt[0] : "bw";
                                switch (this.stype) {
                                case "select":
                                    if (o = a("select[name=" + c + "]", b.grid.hDiv).val()) {
                                        h[c] = o;
                                        f[c] = j;
                                        l++;
                                    } else
                                        try {
                                            delete b.p.postData[c];
                                        } catch (r) {
                                        }
                                    break;
                                case "text":
                                    if (o = a("input[name=" + c + "]", b.grid.hDiv).val()) {
                                        h[c] = o;
                                        f[c] = j;
                                        l++;
                                    } else
                                        try {
                                            delete b.p.postData[c];
                                        } catch (u) {
                                        }
                                    break;
                                }
                            });
                            var e = l > 0 ? true : false;
                            if (g.stringResult) {
                                var m = '{"groupOp":"' +
                                        g.groupOp + '","rules":[',
                                    i = 0;
                                a.each(h, function(j, r) {
                                    if (i > 0)m += ",";
                                    m += '{"field":"' + j + '",';
                                    m += '"op":"' + f[j] + '",';
                                    m += '"data":"' + r + '"}';
                                    i++;
                                });
                                m += "]}";
                                a.extend(b.p.postData, { filters: m });
                            } else a.extend(b.p.postData, h);
                            var k;
                            if (b.p.searchurl) {
                                k = b.p.url;
                                a(b).jqGrid("setGridParam", { url: b.p.searchurl });
                            }
                            var p = false;
                            if (a.isFunction(g.beforeSearch))p = g.beforeSearch.call(b);
                            p || a(b).jqGrid("setGridParam", { search: e }).trigger("reloadGrid", [{ page: 1 }]);
                            k && a(b).jqGrid("setGridParam", { url: k });
                            a.isFunction(g.afterSearch) &&
                                g.afterSearch();
                        },
                    s = a("<tr class='ui-search-toolbar' role='rowheader'></tr>"),
                    q;
                a.each(b.p.colModel, function() {
                    var h = this, l, o, c, f;
                    o = a("<th role='columnheader' class='ui-state-default ui-th-column ui-th-" + b.p.direction + "'></th>");
                    l = a("<div style='width:100%;position:relative;height:100%;padding-right:0.3em;'></div>");
                    this.hidden === true && a(o).css("display", "none");
                    this.search = this.search === false ? false : true;
                    if (typeof this.stype == "undefined")this.stype = "text";
                    c = a.extend({}, this.searchoptions || {});
                    if (this.search)
                        switch (this.stype) {
                        case "select":
                            if (f =
                                this.surl || c.dataUrl)
                                a.ajax(a.extend({
                                    url: f,
                                    dataType: "html",
                                    complete: function(p) {
                                        if (c.buildSelect !== undefined)(p = c.buildSelect(p)) && a(l).append(p);
                                        else a(l).append(p.responseText);
                                        c.defaultValue && a("select", l).val(c.defaultValue);
                                        a("select", l).attr({ name: h.index || h.name, id: "gs_" + h.name });
                                        c.attr && a("select", l).attr(c.attr);
                                        a("select", l).css({ width: "100%" });
                                        c.dataInit !== undefined && c.dataInit(a("select", l)[0]);
                                        c.dataEvents !== undefined && d(a("select", l)[0], c.dataEvents);
                                        g.autosearch === true && a("select",
                                            l).change(function() {
                                            n();
                                            return false;
                                        });
                                        p = null;
                                    }
                                }, a.jgrid.ajaxOptions, b.p.ajaxSelectOptions || {}));
                            else {
                                var e;
                                if (h.searchoptions && h.searchoptions.value)e = h.searchoptions.value;
                                else if (h.editoptions && h.editoptions.value)e = h.editoptions.value;
                                if (e) {
                                    f = document.createElement("select");
                                    f.style.width = "100%";
                                    a(f).attr({ name: h.index || h.name, id: "gs_" + h.name });
                                    var m, i;
                                    if (typeof e === "string") {
                                        e = e.split(";");
                                        for (var k = 0; k < e.length; k++) {
                                            m = e[k].split(":");
                                            i = document.createElement("option");
                                            i.value = m[0];
                                            i.innerHTML =
                                                m[1];
                                            f.appendChild(i);
                                        }
                                    } else if (typeof e === "object")
                                        for (m in e)
                                            if (e.hasOwnProperty(m)) {
                                                i = document.createElement("option");
                                                i.value = m;
                                                i.innerHTML = e[m];
                                                f.appendChild(i);
                                            }
                                    c.defaultValue && a(f).val(c.defaultValue);
                                    c.attr && a(f).attr(c.attr);
                                    c.dataInit !== undefined && c.dataInit(f);
                                    c.dataEvents !== undefined && d(f, c.dataEvents);
                                    a(l).append(f);
                                    g.autosearch === true && a(f).change(function() {
                                        n();
                                        return false;
                                    });
                                }
                            }
                            break;
                        case "text":
                            f = c.defaultValue ? c.defaultValue : "";
                            a(l).append("<input type='text' style='width:95%;padding:0px;' name='" +
                            (h.index || h.name) + "' id='gs_" + h.name + "' value='" + f + "'/>");
                            c.attr && a("input", l).attr(c.attr);
                            c.dataInit !== undefined && c.dataInit(a("input", l)[0]);
                            c.dataEvents !== undefined && d(a("input", l)[0], c.dataEvents);
                            if (g.autosearch === true)
                                g.searchOnEnter ? a("input", l).keypress(function(p) {
                                    if ((p.charCode ? p.charCode : p.keyCode ? p.keyCode : 0) == 13) {
                                        n();
                                        return false;
                                    }
                                    return this;
                                }) : a("input", l).keydown(function(p) {
                                    switch (p.which) {
                                    case 9:
                                    case 16:
                                    case 37:
                                    case 38:
                                    case 39:
                                    case 40:
                                    case 27:
                                        break;
                                    default:
                                        q && clearTimeout(q);
                                        q = setTimeout(function() { n(); },
                                            500);
                                    }
                                });
                            break;
                        }
                    a(o).append(l);
                    a(s).append(o);
                });
                a("table thead", b.grid.hDiv).append(s);
                this.triggerToolbar = n;
                this.clearToolbar = function(h) {
                    var l = {}, o, c = 0, f;
                    h = typeof h != "boolean" ? true : h;
                    a.each(b.p.colModel, function() {
                        o = this.searchoptions && this.searchoptions.defaultValue ? this.searchoptions.defaultValue : "";
                        f = this.index || this.name;
                        switch (this.stype) {
                        case "select":
                            var j;
                            a("select[name=" + f + "] option", b.grid.hDiv).each(function(t) {
                                if (t === 0)this.selected = true;
                                if (a(this).text() == o) {
                                    this.selected = true;
                                    j = a(this).val();
                                    return false;
                                }
                            });
                            if (j) {
                                l[f] = j;
                                c++;
                            } else
                                try {
                                    delete b.p.postData[f];
                                } catch (r) {
                                }
                            break;
                        case "text":
                            a("input[name=" + f + "]", b.grid.hDiv).val(o);
                            if (o) {
                                l[f] = o;
                                c++;
                            } else
                                try {
                                    delete b.p.postData[f];
                                } catch (u) {
                                }
                            break;
                        }
                    });
                    var e = c > 0 ? true : false;
                    if (g.stringResult) {
                        var m = '{"groupOp":"' + g.groupOp + '","rules":[', i = 0;
                        a.each(l, function(j, r) {
                            if (i > 0)m += ",";
                            m += '{"field":"' + j + '",';
                            m += '"op":"eq",';
                            m += '"data":"' + r + '"}';
                            i++;
                        });
                        m += "]}";
                        a.extend(b.p.postData, { filters: m });
                    } else a.extend(b.p.postData, l);
                    var k;
                    if (b.p.searchurl) {
                        k = b.p.url;
                        a(b).jqGrid("setGridParam", { url: b.p.searchurl });
                    }
                    var p = false;
                    if (a.isFunction(g.beforeClear))p = g.beforeClear.call(b);
                    p || h && a(b).jqGrid("setGridParam", { search: e }).trigger("reloadGrid", [{ page: 1 }]);
                    k && a(b).jqGrid("setGridParam", { url: k });
                    a.isFunction(g.afterClear) && g.afterClear();
                };
                this.toggleToolbar = function() {
                    var h = a("tr.ui-search-toolbar", b.grid.hDiv);
                    h.css("display") == "none" ? h.show() : h.hide();
                };
            });
        }
    });
})(jQuery);
var showModal = function(a) { a.w.show(); },
    closeModal = function(a) {
        a.w.hide().attr("aria-hidden", "true");
        a.o && a.o.remove();
    },
    hideModal = function(a, b) {
        b = jQuery.extend({ jqm: true, gb: "" }, b || {});
        if (b.onClose) {
            var c = b.onClose(a);
            if (typeof c == "boolean" && !c)return;
        }
        if (jQuery.fn.jqm && b.jqm === true)jQuery(a).attr("aria-hidden", "true").jqmHide();
        else {
            if (b.gb != "")
                try {
                    jQuery(".jqgrid-overlay:first", b.gb).hide();
                } catch (e) {
                }
            jQuery(a).hide().attr("aria-hidden", "true");
        }
    };

function findPos(a) {
    var b = 0, c = 0;
    if (a.offsetParent) {
        do {
            b += a.offsetLeft;
            c += a.offsetTop;
        } while (a = a.offsetParent);
    }
    return[b, c];
}

var createModal = function(a, b, c, e, f, h) {
        var d = document.createElement("div"), g;
        g = jQuery(c.gbox).attr("dir") == "rtl" ? true : false;
        d.className = "ui-widget ui-widget-content ui-corner-all ui-jqdialog";
        d.id = a.themodal;
        var i = document.createElement("div");
        i.className = "ui-jqdialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix";
        i.id = a.modalhead;
        jQuery(i).append("<span class='ui-jqdialog-title'>" + c.caption + "</span>");
        var j = jQuery("<a href='javascript:void(0)' class='ui-jqdialog-titlebar-close ui-corner-all'></a>").hover(function() { j.addClass("ui-state-hover"); },
            function() { j.removeClass("ui-state-hover"); }).append("<span class='ui-icon ui-icon-closethick'></span>");
        jQuery(i).append(j);
        if (g) {
            d.dir = "rtl";
            jQuery(".ui-jqdialog-title", i).css("float", "right");
            jQuery(".ui-jqdialog-titlebar-close", i).css("left", "0.3em");
        } else {
            d.dir = "ltr";
            jQuery(".ui-jqdialog-title", i).css("float", "left");
            jQuery(".ui-jqdialog-titlebar-close", i).css("right", "0.3em");
        }
        var l = document.createElement("div");
        jQuery(l).addClass("ui-jqdialog-content ui-widget-content").attr("id", a.modalcontent);
        jQuery(l).append(b);
        d.appendChild(l);
        jQuery(d).prepend(i);
        h === true ? jQuery("body").append(d) : jQuery(d).insertBefore(e);
        if (typeof c.jqModal === "undefined")c.jqModal = true;
        b = {};
        if (jQuery.fn.jqm && c.jqModal === true) {
            if (c.left === 0 && c.top === 0) {
                e = [];
                e = findPos(f);
                c.left = e[0] + 4;
                c.top = e[1] + 4;
            }
            b.top = c.top + "px";
            b.left = c.left;
        } else if (c.left !== 0 || c.top !== 0) {
            b.left = c.left;
            b.top = c.top + "px";
        }
        jQuery("a.ui-jqdialog-titlebar-close", i).click(function() {
            var n = jQuery("#" + a.themodal).data("onClose") || c.onClose,
                k = jQuery("#" + a.themodal).data("gbox") ||
                    c.gbox;
            hideModal("#" + a.themodal, { gb: k, jqm: c.jqModal, onClose: n });
            return false;
        });
        if (c.width === 0 || !c.width)c.width = 300;
        if (c.height === 0 || !c.height)c.height = 200;
        if (!c.zIndex)c.zIndex = 950;
        f = 0;
        if (g && b.left && !h) {
            f = jQuery(c.gbox).width() - (!isNaN(c.width) ? parseInt(c.width, 10) : 0) - 8;
            b.left = parseInt(b.left, 10) + parseInt(f, 10);
        }
        if (b.left)b.left += "px";
        jQuery(d).css(jQuery.extend({ width: isNaN(c.width) ? "auto" : c.width + "px", height: isNaN(c.height) ? "auto" : c.height + "px", zIndex: c.zIndex, overflow: "hidden" }, b)).attr({
            tabIndex: "-1",
            role: "dialog",
            "aria-labelledby": a.modalhead,
            "aria-hidden": "true"
        });
        if (typeof c.drag == "undefined")c.drag = true;
        if (typeof c.resize == "undefined")c.resize = true;
        if (c.drag) {
            jQuery(i).css("cursor", "move");
            if (jQuery.fn.jqDrag)jQuery(d).jqDrag(i);
            else
                try {
                    jQuery(d).draggable({ handle: jQuery("#" + i.id) });
                } catch (q) {
                }
        }
        if (c.resize)
            if (jQuery.fn.jqResize) {
                jQuery(d).append("<div class='jqResize ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se ui-icon-grip-diagonal-se'></div>");
                jQuery("#" + a.themodal).jqResize(".jqResize",
                    a.scrollelm ? "#" + a.scrollelm : false);
            } else
                try {
                    jQuery(d).resizable({ handles: "se, sw", alsoResize: a.scrollelm ? "#" + a.scrollelm : false });
                } catch (o) {
                }
        c.closeOnEscape === true && jQuery(d).keydown(function(n) {
            if (n.which == 27) {
                n = jQuery("#" + a.themodal).data("onClose") || c.onClose;
                hideModal(this, { gb: c.gbox, jqm: c.jqModal, onClose: n });
            }
        });
    },
    viewModal = function(a, b) {
        b = jQuery.extend({ toTop: true, overlay: 10, modal: false, onShow: showModal, onHide: closeModal, gbox: "", jqm: true, jqM: true }, b || {});
        if (jQuery.fn.jqm && b.jqm === true)
            b.jqM ? jQuery(a).attr("aria-hidden",
                "false").jqm(b).jqmShow() : jQuery(a).attr("aria-hidden", "false").jqmShow();
        else {
            if (b.gbox != "") {
                jQuery(".jqgrid-overlay:first", b.gbox).show();
                jQuery(a).data("gbox", b.gbox);
            }
            jQuery(a).show().attr("aria-hidden", "false");
            try {
                jQuery(":input:visible", a)[0].focus();
            } catch (c) {
            }
        }
    };

function info_dialog(a, b, c, e) {
    var f = { width: 290, height: "auto", dataheight: "auto", drag: true, resize: false, caption: "<b>" + a + "</b>", left: 250, top: 170, zIndex: 1E3, jqModal: true, modal: false, closeOnEscape: true, align: "center", buttonalign: "center", buttons: [] };
    jQuery.extend(f, e || {});
    var h = f.jqModal;
    if (jQuery.fn.jqm && !h)h = false;
    a = "";
    if (f.buttons.length > 0)
        for (e = 0; e < f.buttons.length; e++) {
            if (typeof f.buttons[e].id == "undefined")f.buttons[e].id = "info_button_" + e;
            a += "<a href='javascript:void(0)' id='" + f.buttons[e].id + "' class='fm-button ui-state-default ui-corner-all'>" +
                f.buttons[e].text + "</a>";
        }
    e = isNaN(f.dataheight) ? f.dataheight : f.dataheight + "px";
    var d = "<div id='info_id'>";
    d += "<div id='infocnt' style='margin:0px;padding-bottom:1em;width:100%;overflow:auto;position:relative;height:" + e + ";" + ("text-align:" + f.align + ";") + "'>" + b + "</div>";
    d += c ? "<div class='ui-widget-content ui-helper-clearfix' style='text-align:" + f.buttonalign + ";padding-bottom:0.8em;padding-top:0.5em;background-image: none;border-width: 1px 0 0 0;'><a href='javascript:void(0)' id='closedialog' class='fm-button ui-state-default ui-corner-all'>" +
        c + "</a>" + a + "</div>" : a != "" ? "<div class='ui-widget-content ui-helper-clearfix' style='text-align:" + f.buttonalign + ";padding-bottom:0.8em;padding-top:0.5em;background-image: none;border-width: 1px 0 0 0;'>" + a + "</div>" : "";
    d += "</div>";
    try {
        jQuery("#info_dialog").attr("aria-hidden") == "false" && hideModal("#info_dialog", { jqm: h });
        jQuery("#info_dialog").remove();
    } catch (g) {
    }
    createModal({ themodal: "info_dialog", modalhead: "info_head", modalcontent: "info_content", scrollelm: "infocnt" }, d, f, "", "", true);
    a && jQuery.each(f.buttons,
        function(j) {
            jQuery("#" + this.id, "#info_id").bind("click", function() {
                f.buttons[j].onClick.call(jQuery("#info_dialog"));
                return false;
            });
        });
    jQuery("#closedialog", "#info_id").click(function(j) {
        hideModal("#info_dialog", { jqm: h });
        return false;
    });
    jQuery(".fm-button", "#info_dialog").hover(function() { jQuery(this).addClass("ui-state-hover"); }, function() { jQuery(this).removeClass("ui-state-hover"); });
    viewModal("#info_dialog", {
        onHide: function(j) {
            j.w.hide().remove();
            j.o && j.o.remove();
        },
        modal: f.modal,
        jqm: h
    });
    try {
        $("#info_dialog").focus();
    } catch (i) {
    }
}

function createEl(a, b, c, e, f) {
    function h(k, m) {
        if (jQuery.isFunction(m.dataInit)) {
            k.id = m.id;
            m.dataInit(k);
            delete m.id;
            delete m.dataInit;
        }
        if (m.dataEvents) {
            jQuery.each(m.dataEvents, function() { this.data !== undefined ? jQuery(k).bind(this.type, this.data, this.fn) : jQuery(k).bind(this.type, this.fn); });
            delete m.dataEvents;
        }
        return m;
    }

    var d = "";
    b.defaultValue && delete b.defaultValue;
    switch (a) {
    case "textarea":
        d = document.createElement("textarea");
        if (e)b.cols || jQuery(d).css({ width: "98%" });
        else if (!b.cols)b.cols = 20;
        if (!b.rows)
            b.rows =
                2;
        if (c == "&nbsp;" || c == "&#160;" || c.length == 1 && c.charCodeAt(0) == 160)c = "";
        d.value = c;
        b = h(d, b);
        jQuery(d).attr(b).attr({ role: "textbox", multiline: "true" });
        break;
    case "checkbox":
        d = document.createElement("input");
        d.type = "checkbox";
        if (b.value) {
            var g = b.value.split(":");
            if (c === g[0]) {
                d.checked = true;
                d.defaultChecked = true;
            }
            d.value = g[0];
            jQuery(d).attr("offval", g[1]);
            try {
                delete b.value;
            } catch (i) {
            }
        } else {
            g = c.toLowerCase();
            if (g.search(/(false|0|no|off|undefined)/i) < 0 && g !== "") {
                d.checked = true;
                d.defaultChecked = true;
                d.value =
                    c;
            } else d.value = "on";
            jQuery(d).attr("offval", "off");
        }
        b = h(d, b);
        jQuery(d).attr(b).attr("role", "checkbox");
        break;
    case "select":
        d = document.createElement("select");
        d.setAttribute("role", "select");
        var j, l = [];
        if (b.multiple === true) {
            j = true;
            d.multiple = "multiple";
            $(d).attr("aria-multiselectable", "true");
        } else j = false;
        if (typeof b.dataUrl != "undefined")
            jQuery.ajax(jQuery.extend({
                url: b.dataUrl,
                type: "GET",
                complete: function(k, m) {
                    try {
                        delete b.dataUrl;
                        delete b.value;
                    } catch (r) {
                    }
                    if (typeof b.buildSelect != "undefined") {
                        k = b.buildSelect(k);
                        k = jQuery(k).html();
                        delete b.buildSelect;
                    } else k = jQuery(k.responseText).html();
                    if (k) {
                        jQuery(d).append(k);
                        b = h(d, b);
                        if (typeof b.size === "undefined")b.size = j ? 3 : 1;
                        if (j) {
                            l = c.split(",");
                            l = jQuery.map(l, function(p) { return jQuery.trim(p); });
                        } else l[0] = jQuery.trim(c);
                        jQuery(d).attr(b);
                        setTimeout(function() {
                            jQuery("option", d).each(function(p) {
                                if (p === 0)this.selected = "";
                                $(this).attr("role", "option");
                                if (jQuery.inArray(jQuery.trim(jQuery(this).text()), l) > -1 || jQuery.inArray(jQuery.trim(jQuery(this).val()), l) > -1) {
                                    this.selected =
                                        "selected";
                                    if (!j)return false;
                                }
                            });
                        }, 0);
                    }
                }
            }, f || {}));
        else if (b.value) {
            if (j) {
                l = c.split(",");
                l = jQuery.map(l, function(k) { return jQuery.trim(k); });
                if (typeof b.size === "undefined")b.size = 3;
            } else b.size = 1;
            if (typeof b.value === "function")b.value = b.value();
            if (typeof b.value === "string") {
                e = b.value.split(";");
                for (g = 0; g < e.length; g++) {
                    f = e[g].split(":");
                    if (f.length > 2)f[1] = jQuery.map(f, function(k, m) { if (m > 0)return k; }).join(":");
                    a = document.createElement("option");
                    a.setAttribute("role", "option");
                    a.value = f[0];
                    a.innerHTML = f[1];
                    if (!j && (jQuery.trim(f[0]) == jQuery.trim(c) || jQuery.trim(f[1]) == jQuery.trim(c)))a.selected = "selected";
                    if (j && (jQuery.inArray(jQuery.trim(f[1]), l) > -1 || jQuery.inArray(jQuery.trim(f[0]), l) > -1))a.selected = "selected";
                    d.appendChild(a);
                }
            } else if (typeof b.value === "object") {
                e = b.value;
                for (g in e)
                    if (e.hasOwnProperty(g)) {
                        a = document.createElement("option");
                        a.setAttribute("role", "option");
                        a.value = g;
                        a.innerHTML = e[g];
                        if (!j && (jQuery.trim(g) == jQuery.trim(c) || jQuery.trim(e[g]) == jQuery.trim(c)))a.selected = "selected";
                        if (j &&
                        (jQuery.inArray(jQuery.trim(e[g]), l) > -1 || jQuery.inArray(jQuery.trim(g), l) > -1))a.selected = "selected";
                        d.appendChild(a);
                    }
            }
            b = h(d, b);
            try {
                delete b.value;
            } catch (q) {
            }
            jQuery(d).attr(b);
        }
        break;
    case "text":
    case "password":
    case "button":
        g = a == "button" ? "button" : "textbox";
        d = document.createElement("input");
        d.type = a;
        d.value = c;
        b = h(d, b);
        if (a != "button")
            if (e)b.size || jQuery(d).css({ width: "98%" });
            else if (!b.size)b.size = 20;
        jQuery(d).attr(b).attr("role", g);
        break;
    case "image":
    case "file":
        d = document.createElement("input");
        d.type =
            a;
        b = h(d, b);
        jQuery(d).attr(b);
        break;
    case "custom":
        d = document.createElement("span");
        try {
            if (jQuery.isFunction(b.custom_element)) {
                var o = b.custom_element.call(this, c, b);
                if (o) {
                    o = jQuery(o).addClass("customelement").attr({ id: b.id, name: b.name });
                    jQuery(d).empty().append(o);
                } else throw"e2";
            } else throw"e1";
        } catch (n) {
            n == "e1" && info_dialog(jQuery.jgrid.errors.errcap, "function 'custom_element' " + jQuery.jgrid.edit.msg.nodefined, jQuery.jgrid.edit.bClose);
            n == "e2" ? info_dialog(jQuery.jgrid.errors.errcap, "function 'custom_element' " +
                jQuery.jgrid.edit.msg.novalue, jQuery.jgrid.edit.bClose) : info_dialog(jQuery.jgrid.errors.errcap, n.message, jQuery.jgrid.edit.bClose);
        }
        break;
    }
    return d;
}

function daysInFebruary(a) { return a % 4 === 0 && (a % 100 !== 0 || a % 400 === 0) ? 29 : 28; }

function DaysArray(a) {
    for (var b = 1; b <= a; b++) {
        this[b] = 31;
        if (b == 4 || b == 6 || b == 9 || b == 11)this[b] = 30;
        if (b == 2)this[b] = 29;
    }
    return this;
}

function checkDate(a, b) {
    var c = {}, e;
    a = a.toLowerCase();
    e = a.indexOf("/") != -1 ? "/" : a.indexOf("-") != -1 ? "-" : a.indexOf(".") != -1 ? "." : "/";
    a = a.split(e);
    b = b.split(e);
    if (b.length != 3)return false;
    e = -1;
    for (var f, h = -1, d = -1, g = 0; g < a.length; g++) {
        f = isNaN(b[g]) ? 0 : parseInt(b[g], 10);
        c[a[g]] = f;
        f = a[g];
        if (f.indexOf("y") != -1)e = g;
        if (f.indexOf("m") != -1)d = g;
        if (f.indexOf("d") != -1)h = g;
    }
    f = a[e] == "y" || a[e] == "yyyy" ? 4 : a[e] == "yy" ? 2 : -1;
    g = DaysArray(12);
    var i;
    if (e === -1)return false;
    else {
        i = c[a[e]].toString();
        if (f == 2 && i.length == 1)f = 1;
        if (i.length !=
            f || c[a[e]] === 0 && b[e] != "00")return false;
    }
    if (d === -1)return false;
    else {
        i = c[a[d]].toString();
        if (i.length < 1 || c[a[d]] < 1 || c[a[d]] > 12)return false;
    }
    if (h === -1)return false;
    else {
        i = c[a[h]].toString();
        if (i.length < 1 || c[a[h]] < 1 || c[a[h]] > 31 || c[a[d]] == 2 && c[a[h]] > daysInFebruary(c[a[e]]) || c[a[h]] > g[c[a[d]]])return false;
    }
    return true;
}

function isEmpty(a) { return a.match(/^s+$/) || a == "" ? true : false; }

function checkTime(a) {
    var b = /^(\d{1,2}):(\d{2})([ap]m)?$/;
    if (!isEmpty(a))
        if (a = a.match(b)) {
            if (a[3]) {
                if (a[1] < 1 || a[1] > 12)return false;
            } else if (a[1] > 23)return false;
            if (a[2] > 59)return false;
        } else return false;
    return true;
}

function checkValues(a, b, c) {
    var e, f, h;
    if (typeof b == "string") {
        f = 0;
        for (len = c.p.colModel.length; f < len; f++)
            if (c.p.colModel[f].name == b) {
                e = c.p.colModel[f].editrules;
                b = f;
                try {
                    h = c.p.colModel[f].formoptions.label;
                } catch (d) {
                }
                break;
            }
    } else if (b >= 0)e = c.p.colModel[b].editrules;
    if (e) {
        h || (h = c.p.colNames[b]);
        if (e.required === true)if (a.match(/^s+$/) || a == "")return[false, h + ": " + jQuery.jgrid.edit.msg.required, ""];
        f = e.required === false ? false : true;
        if (e.number === true)
            if (!(f === false && isEmpty(a)))
                if (isNaN(a))
                    return[
                        false, h + ": " +
                        jQuery.jgrid.edit.msg.number, ""
                    ];
        if (typeof e.minValue != "undefined" && !isNaN(e.minValue))if (parseFloat(a) < parseFloat(e.minValue))return[false, h + ": " + jQuery.jgrid.edit.msg.minValue + " " + e.minValue, ""];
        if (typeof e.maxValue != "undefined" && !isNaN(e.maxValue))if (parseFloat(a) > parseFloat(e.maxValue))return[false, h + ": " + jQuery.jgrid.edit.msg.maxValue + " " + e.maxValue, ""];
        var g;
        if (e.email === true)
            if (!(f === false && isEmpty(a))) {
                g = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i;
                if (!g.test(a))return[false, h + ": " + jQuery.jgrid.edit.msg.email, ""];
            }
        if (e.integer === true)
            if (!(f === false && isEmpty(a))) {
                if (isNaN(a))return[false, h + ": " + jQuery.jgrid.edit.msg.integer, ""];
                if (a % 1 !== 0 || a.indexOf(".") != -1)return[false, h + ": " + jQuery.jgrid.edit.msg.integer, ""];
            }
        if (e.date === true)
            if (!(f === false && isEmpty(a))) {
                b = c.p.colModel[b].datefmt || "Y-m-d";
                if (!checkDate(b, a))return[false, h + ": " + jQuery.jgrid.edit.msg.date + " - " + b, ""];
            }
        if (e.time === true)
            if (!(f === false && isEmpty(a)))
                if (!checkTime(a))
                    return[
                        false, h +
                        ": " + jQuery.jgrid.edit.msg.date + " - hh:mm (am/pm)", ""
                    ];
        if (e.url === true)
            if (!(f === false && isEmpty(a))) {
                g = /^(((https?)|(ftp)):\/\/([\-\w]+\.)+\w{2,3}(\/[%\-\w]+(\.\w{2,})?)*(([\w\-\.\?\\\/+@&#;`~=%!]*)(\.\w{2,})?)*\/?)/i;
                if (!g.test(a))return[false, h + ": " + jQuery.jgrid.edit.msg.url, ""];
            }
        if (e.custom === true)
            if (!(f === false && isEmpty(a)))
                if (jQuery.isFunction(e.custom_func)) {
                    a = e.custom_func.call(c, a, h);
                    return jQuery.isArray(a) ? a : [false, jQuery.jgrid.edit.msg.customarray, ""];
                } else
                    return[
                        false, jQuery.jgrid.edit.msg.customfcheck,
                        ""
                    ];
    }
    return[true, "", ""];
};

(function(a) {
    var c = null;
    a.jgrid.extend({
        searchGrid: function(d) {
            d = a.extend({ recreateFilter: false, drag: true, sField: "searchField", sValue: "searchString", sOper: "searchOper", sFilter: "filters", loadDefaults: true, beforeShowSearch: null, afterShowSearch: null, onInitializeSearch: null, closeAfterSearch: false, closeAfterReset: false, closeOnEscape: false, multipleSearch: false, cloneSearchRowOnAdd: true, sopt: null, stringResult: undefined, onClose: null, useDataProxy: false, overlay: true }, a.jgrid.search, d || {});
            return this.each(function() {
                function b(o,
                    s) {
                    s = o.p.postData[s.sFilter];
                    if (typeof s == "string")s = a.jgrid.parse(s);
                    if (s) {
                        s.groupOp && o.SearchFilter.setGroupOp(s.groupOp);
                        if (s.rules) {
                            var y, J = 0, k = s.rules.length;
                            for (y = false; J < k; J++) {
                                y = s.rules[J];
                                if (y.field !== undefined && y.op !== undefined && y.data !== undefined)(y = o.SearchFilter.setFilter({ sfref: o.SearchFilter.$.find(".sf:last"), filter: a.extend({}, y) })) && o.SearchFilter.add();
                            }
                        }
                    }
                }

                function q(o) {
                    var s = o !== undefined, y = a("#" + z.p.id), J = {};
                    if (d.multipleSearch === false) {
                        J[d.sField] = o.rules[0].field;
                        J[d.sValue] =
                            o.rules[0].data;
                        J[d.sOper] = o.rules[0].op;
                    } else J[d.sFilter] = o;
                    y[0].p.search = s;
                    a.extend(y[0].p.postData, J);
                    y.trigger("reloadGrid", [{ page: 1 }]);
                    d.closeAfterSearch && t(a("#" + h));
                }

                function D(o) {
                    o = o !== undefined;
                    var s = a("#" + z.p.id), y = [];
                    s[0].p.search = o;
                    if (d.multipleSearch === false)y[d.sField] = y[d.sValue] = y[d.sOper] = "";
                    else y[d.sFilter] = "";
                    a.extend(s[0].p.postData, y);
                    s.trigger("reloadGrid", [{ page: 1 }]);
                    d.closeAfterReset && t(a("#" + h));
                }

                function t(o) {
                    if (d.onClose) {
                        var s = d.onClose(o);
                        if (typeof s == "boolean" && !s)return;
                    }
                    o.hide();
                    d.overlay === true && a(".jqgrid-overlay:first", "#gbox_" + z.p.id).hide();
                }

                function F() {
                    var o = a(".ui-searchFilter").length;
                    if (o > 1) {
                        var s = a("#" + h).css("zIndex");
                        a("#" + h).css({ zIndex: parseInt(s, 10) + o });
                    }
                    a("#" + h).show();
                    d.overlay === true && a(".jqgrid-overlay:first", "#gbox_" + z.p.id).show();
                    try {
                        a(":input:visible", "#" + h)[0].focus();
                    } catch (y) {
                    }
                }

                var z = this;
                if (z.grid)
                    if (a.fn.searchFilter) {
                        var h = "fbox_" + z.p.id;
                        d.recreateFilter === true && a("#" + h).remove();
                        if (a("#" + h).html() != null) {
                            a.isFunction(d.beforeShowSearch) && d.beforeShowSearch(a("#" +
                                h));
                            F();
                            a.isFunction(d.afterShowSearch) && d.afterShowSearch(a("#" + h));
                        } else {
                            var p = [], H = a("#" + z.p.id).jqGrid("getGridParam", "colNames"), f = a("#" + z.p.id).jqGrid("getGridParam", "colModel"), l = ["eq", "ne", "lt", "le", "gt", "ge", "bw", "bn", "in", "ni", "ew", "en", "cn", "nc"], e, j, m, u = [];
                            if (d.sopt !== null)
                                for (e = m = 0; e < d.sopt.length; e++) {
                                    if ((j = a.inArray(d.sopt[e], l)) != -1) {
                                        u[m] = { op: d.sopt[e], text: d.odata[j] };
                                        m++;
                                    }
                                }
                            else for (e = 0; e < l.length; e++)u[e] = { op: l[e], text: d.odata[e] };
                            a.each(f, function(o, s) {
                                var y = typeof s.search === "undefined" ?
                                        true : s.search,
                                    J = s.hidden === true;
                                o = a.extend({}, { text: H[o], itemval: s.index || s.name }, this.searchoptions);
                                s = o.searchhidden === true;
                                if (typeof o.sopt !== "undefined") {
                                    m = 0;
                                    o.ops = [];
                                    if (o.sopt.length > 0)
                                        for (e = 0; e < o.sopt.length; e++)
                                            if ((j = a.inArray(o.sopt[e], l)) != -1) {
                                                o.ops[m] = { op: o.sopt[e], text: d.odata[j] };
                                                m++;
                                            }
                                }
                                if (typeof this.stype === "undefined")this.stype = "text";
                                if (this.stype == "select")
                                    if (o.dataUrl === undefined) {
                                        var k;
                                        if (o.value)k = o.value;
                                        else if (this.editoptions)k = this.editoptions.value;
                                        if (k) {
                                            o.dataValues = [];
                                            if (typeof k ===
                                                "string") {
                                                k = k.split(";");
                                                var i;
                                                for (e = 0; e < k.length; e++) {
                                                    i = k[e].split(":");
                                                    o.dataValues[e] = { value: i[0], text: i[1] };
                                                }
                                            } else if (typeof k === "object") {
                                                e = 0;
                                                for (i in k)
                                                    if (k.hasOwnProperty(i)) {
                                                        o.dataValues[e] = { value: i, text: k[i] };
                                                        e++;
                                                    }
                                            }
                                        }
                                    }
                                if (s && y || y && !J)p.push(o);
                            });
                            if (p.length > 0) {
                                a("<div id='" + h + "' role='dialog' tabindex='-1'></div>").insertBefore("#gview_" + z.p.id);
                                if (d.stringResult === undefined)d.stringResult = d.multipleSearch;
                                z.SearchFilter = a("#" + h).searchFilter(p, {
                                    groupOps: d.groupOps,
                                    operators: u,
                                    onClose: t,
                                    resetText: d.Reset,
                                    searchText: d.Find,
                                    windowTitle: d.caption,
                                    rulesText: d.rulesText,
                                    matchText: d.matchText,
                                    onSearch: q,
                                    onReset: D,
                                    stringResult: d.stringResult,
                                    ajaxSelectOptions: a.extend({}, a.jgrid.ajaxOptions, z.p.ajaxSelectOptions || {}),
                                    clone: d.cloneSearchRowOnAdd
                                });
                                a(".ui-widget-overlay", "#" + h).remove();
                                z.p.direction == "rtl" && a(".ui-closer", "#" + h).css("float", "left");
                                if (d.drag === true) {
                                    a("#" + h + " table thead tr:first td:first").css("cursor", "move");
                                    if (jQuery.fn.jqDrag)a("#" + h).jqDrag(a("#" + h + " table thead tr:first td:first"));
                                    else
                                        try {
                                            a("#" + h).draggable({ handle: a("#" + h + " table thead tr:first td:first") });
                                        } catch (Q) {
                                        }
                                }
                                if (d.multipleSearch === false) {
                                    a(".ui-del, .ui-add, .ui-del, .ui-add-last, .matchText, .rulesText", "#" + h).hide();
                                    a("select[name='groupOp']", "#" + h).hide();
                                }
                                d.multipleSearch === true && d.loadDefaults === true && b(z, d);
                                a.isFunction(d.onInitializeSearch) && d.onInitializeSearch(a("#" + h));
                                a.isFunction(d.beforeShowSearch) && d.beforeShowSearch(a("#" + h));
                                F();
                                a.isFunction(d.afterShowSearch) && d.afterShowSearch(a("#" + h));
                                d.closeOnEscape ===
                                    true && a("#" + h).keydown(function(o) { o.which == 27 && t(a("#" + h)); });
                            }
                        }
                    }
            });
        },
        editGridRow: function(d, b) {
            c = b = a.extend({
                top: 0,
                left: 0,
                width: 300,
                height: "auto",
                dataheight: "auto",
                modal: false,
                drag: true,
                resize: true,
                url: null,
                mtype: "POST",
                clearAfterAdd: true,
                closeAfterEdit: false,
                reloadAfterSubmit: true,
                onInitializeForm: null,
                beforeInitData: null,
                beforeShowForm: null,
                afterShowForm: null,
                beforeSubmit: null,
                afterSubmit: null,
                onclickSubmit: null,
                afterComplete: null,
                onclickPgButtons: null,
                afterclickPgButtons: null,
                editData: {},
                recreateForm: false,
                jqModal: true,
                closeOnEscape: false,
                addedrow: "first",
                topinfo: "",
                bottominfo: "",
                saveicon: [],
                closeicon: [],
                savekey: [false, 13],
                navkeys: [false, 38, 40],
                checkOnSubmit: false,
                checkOnUpdate: false,
                _savedData: {},
                processing: false,
                onClose: null,
                ajaxEditOptions: {},
                serializeEditData: null,
                viewPagerButtons: true
            }, a.jgrid.edit, b || {});
            return this.each(function() {
                function q(g, n) {
                    g === 0 ? a("#pData", "#" + j + "_2").addClass("ui-state-disabled") : a("#pData", "#" + j + "_2").removeClass("ui-state-disabled");
                    g == n ? a("#nData", "#" + j + "_2").addClass("ui-state-disabled") :
                        a("#nData", "#" + j + "_2").removeClass("ui-state-disabled");
                }

                function D() {
                    var g = a(f).jqGrid("getDataIDs"), n = a("#id_g", "#" + j).val();
                    return[a.inArray(n, g), g];
                }

                function t() {
                    var g = true;
                    a("#FormError", "#" + j).hide();
                    if (c.checkOnUpdate) {
                        k = {};
                        i = {};
                        F();
                        w = a.extend({}, k, i);
                        if (O = H(w, c._savedData)) {
                            a("#" + e).data("disabled", true);
                            a(".confirm", "#" + m.themodal).show();
                            g = false;
                        }
                    }
                    return g;
                }

                function F() {
                    a(".FormElement", "#" + j).each(function() {
                        var g = a(".customelement", this);
                        if (g.length) {
                            var n = g[0].name;
                            a.each(f.p.colModel, function() {
                                if (this.name ==
                                    n && this.editoptions && a.isFunction(this.editoptions.custom_value)) {
                                    try {
                                        k[n] = this.editoptions.custom_value(a("#" + n, "#" + j), "get");
                                        if (k[n] === undefined)throw"e1";
                                    } catch (r) {
                                        r == "e1" ? info_dialog(jQuery.jgrid.errors.errcap, "function 'custom_value' " + a.jgrid.edit.msg.novalue, jQuery.jgrid.edit.bClose) : info_dialog(jQuery.jgrid.errors.errcap, r.message, jQuery.jgrid.edit.bClose);
                                    }
                                    return true;
                                }
                            });
                        } else {
                            switch (a(this).get(0).type) {
                            case "checkbox":
                                if (a(this).attr("checked"))k[this.name] = a(this).val();
                                else {
                                    g = a(this).attr("offval");
                                    k[this.name] = g;
                                }
                                break;
                            case "select-one":
                                k[this.name] = a("option:selected", this).val();
                                i[this.name] = a("option:selected", this).text();
                                break;
                            case "select-multiple":
                                k[this.name] = a(this).val();
                                k[this.name] = k[this.name] ? k[this.name].join(",") : "";
                                var v = [];
                                a("option:selected", this).each(function(r, E) { v[r] = a(E).text(); });
                                i[this.name] = v.join(",");
                                break;
                            case "password":
                            case "text":
                            case "textarea":
                            case "button":
                                k[this.name] = a(this).val();
                                break;
                            }
                            if (f.p.autoencode)k[this.name] = a.jgrid.htmlEncode(k[this.name]);
                        }
                    });
                    return true;
                }

                function z(g, n, v, r) {
                    for (var E, A, B, M = 0, x, P, C, T = [], G = false, V = "", R = 1; R <= r; R++)V += "<td class='CaptionTD ui-widget-content'>&#160;</td><td class='DataTD ui-widget-content' style='white-space:pre'>&#160;</td>";
                    if (g != "_empty")G = a(n).jqGrid("getInd", g);
                    a(n.p.colModel).each(function(U) {
                        E = this.name;
                        P = (A = this.editrules && this.editrules.edithidden === true ? false : this.hidden === true ? true : false) ? "style='display:none'" : "";
                        if (E !== "cb" && E !== "subgrid" && this.editable === true && E !== "rn") {
                            if (G === false)x = "";
                            else if (E == n.p.ExpandColumn &&
                                n.p.treeGrid === true)x = a("td:eq(" + U + ")", n.rows[G]).text();
                            else
                                try {
                                    x = a.unformat(a("td:eq(" + U + ")", n.rows[G]), { rowId: g, colModel: this }, U);
                                } catch (ca) {
                                    x = a("td:eq(" + U + ")", n.rows[G]).html();
                                }
                            var W = a.extend({}, this.editoptions || {}, { id: E, name: E }), X = a.extend({}, { elmprefix: "", elmsuffix: "", rowabove: false, rowcontent: "" }, this.formoptions || {}), ba = parseInt(X.rowpos, 10) || M + 1, da = parseInt((parseInt(X.colpos, 10) || 1) * 2, 10);
                            if (g == "_empty" && W.defaultValue)x = a.isFunction(W.defaultValue) ? W.defaultValue() : W.defaultValue;
                            if (!this.edittype)
                                this.edittype =
                                    "text";
                            if (f.p.autoencode)x = a.jgrid.htmlDecode(x);
                            C = createEl(this.edittype, W, x, false, a.extend({}, a.jgrid.ajaxOptions, n.p.ajaxSelectOptions || {}));
                            if (x == "" && this.edittype == "checkbox")x = a(C).attr("offval");
                            if (x == "" && this.edittype == "select")x = a("option:eq(0)", C).text();
                            if (c.checkOnSubmit || c.checkOnUpdate)c._savedData[E] = x;
                            a(C).addClass("FormElement");
                            B = a(v).find("tr[rowpos=" + ba + "]");
                            if (X.rowabove) {
                                W = a("<tr><td class='contentinfo' colspan='" + r * 2 + "'>" + X.rowcontent + "</td></tr>");
                                a(v).append(W);
                                W[0].rp = ba;
                            }
                            if (B.length ===
                                0) {
                                B = a("<tr " + P + " rowpos='" + ba + "'></tr>").addClass("FormData").attr("id", "tr_" + E);
                                a(B).append(V);
                                a(v).append(B);
                                B[0].rp = ba;
                            }
                            a("td:eq(" + (da - 2) + ")", B[0]).html(typeof X.label === "undefined" ? n.p.colNames[U] : X.label);
                            a("td:eq(" + (da - 1) + ")", B[0]).append(X.elmprefix).append(C).append(X.elmsuffix);
                            T[M] = U;
                            M++;
                        }
                    });
                    if (M > 0) {
                        R = a("<tr class='FormData' style='display:none'><td class='CaptionTD'></td><td colspan='" + (r * 2 - 1) + "' class='DataTD'><input class='FormElement' id='id_g' type='text' name='" + n.p.id + "_id' value='" +
                            g + "'/></td></tr>");
                        R[0].rp = M + 999;
                        a(v).append(R);
                        if (c.checkOnSubmit || c.checkOnUpdate)c._savedData[n.p.id + "_id"] = g;
                    }
                    return T;
                }

                function h(g, n, v) {
                    var r, E = 0, A, B, M, x, P;
                    if (c.checkOnSubmit || c.checkOnUpdate) {
                        c._savedData = {};
                        c._savedData[n.p.id + "_id"] = g;
                    }
                    var C = n.p.colModel;
                    if (g == "_empty") {
                        a(C).each(function() {
                            r = this.name;
                            M = a.extend({}, this.editoptions || {});
                            B = a("#" + a.jgrid.jqID(r), "#" + v);
                            if (B[0] != null) {
                                x = "";
                                if (M.defaultValue) {
                                    x = a.isFunction(M.defaultValue) ? M.defaultValue() : M.defaultValue;
                                    if (B[0].type == "checkbox") {
                                        P =
                                            x.toLowerCase();
                                        if (P.search(/(false|0|no|off|undefined)/i) < 0 && P !== "") {
                                            B[0].checked = true;
                                            B[0].defaultChecked = true;
                                            B[0].value = x;
                                        } else B.attr({ checked: "", defaultChecked: "" });
                                    } else B.val(x);
                                } else if (B[0].type == "checkbox") {
                                    B[0].checked = false;
                                    B[0].defaultChecked = false;
                                    x = a(B).attr("offval");
                                } else if (B[0].type.substr(0, 6) == "select")B[0].selectedIndex = 0;
                                else B.val(x);
                                if (c.checkOnSubmit === true || c.checkOnUpdate)c._savedData[r] = x;
                            }
                        });
                        a("#id_g", "#" + v).val(g);
                    } else {
                        var T = a(n).jqGrid("getInd", g, true);
                        if (T) {
                            a("td", T).each(function(G) {
                                r =
                                    C[G].name;
                                if (r !== "cb" && r !== "subgrid" && r !== "rn" && C[G].editable === true) {
                                    if (r == n.p.ExpandColumn && n.p.treeGrid === true)A = a(this).text();
                                    else
                                        try {
                                            A = a.unformat(this, { rowId: g, colModel: C[G] }, G);
                                        } catch (V) {
                                            A = a(this).html();
                                        }
                                    if (f.p.autoencode)A = a.jgrid.htmlDecode(A);
                                    if (c.checkOnSubmit === true || c.checkOnUpdate)c._savedData[r] = A;
                                    r = a.jgrid.jqID(r);
                                    switch (C[G].edittype) {
                                    case "password":
                                    case "text":
                                    case "button":
                                    case "image":
                                        a("#" + r, "#" + v).val(A);
                                        break;
                                    case "textarea":
                                        if (A == "&nbsp;" || A == "&#160;" || A.length == 1 && A.charCodeAt(0) ==
                                            160)A = "";
                                        a("#" + r, "#" + v).val(A);
                                        break;
                                    case "select":
                                        var R = A.split(",");
                                        R = a.map(R, function(ca) { return a.trim(ca); });
                                        a("#" + r + " option", "#" + v).each(function() { this.selected = !C[G].editoptions.multiple && (R[0] == a.trim(a(this).text()) || R[0] == a.trim(a(this).val())) ? true : C[G].editoptions.multiple ? a.inArray(a.trim(a(this).text()), R) > -1 || a.inArray(a.trim(a(this).val()), R) > -1 ? true : false : false; });
                                        break;
                                    case "checkbox":
                                        A += "";
                                        if (C[G].editoptions && C[G].editoptions.value)
                                            if (C[G].editoptions.value.split(":")[0] == A) {
                                                a("#" +
                                                    r, "#" + v).attr("checked", true);
                                                a("#" + r, "#" + v).attr("defaultChecked", true);
                                            } else {
                                                a("#" + r, "#" + v).attr("checked", false);
                                                a("#" + r, "#" + v).attr("defaultChecked", "");
                                            }
                                        else {
                                            A = A.toLowerCase();
                                            if (A.search(/(false|0|no|off|undefined)/i) < 0 && A !== "") {
                                                a("#" + r, "#" + v).attr("checked", true);
                                                a("#" + r, "#" + v).attr("defaultChecked", true);
                                            } else {
                                                a("#" + r, "#" + v).attr("checked", false);
                                                a("#" + r, "#" + v).attr("defaultChecked", "");
                                            }
                                        }
                                        break;
                                    case "custom":
                                        try {
                                            if (C[G].editoptions && a.isFunction(C[G].editoptions.custom_value))
                                                C[G].editoptions.custom_value(a("#" +
                                                    r, "#" + v), "set", A);
                                            else throw"e1";
                                        } catch (U) {
                                            U == "e1" ? info_dialog(jQuery.jgrid.errors.errcap, "function 'custom_value' " + a.jgrid.edit.msg.nodefined, jQuery.jgrid.edit.bClose) : info_dialog(jQuery.jgrid.errors.errcap, U.message, jQuery.jgrid.edit.bClose);
                                        }
                                        break;
                                    }
                                    E++;
                                }
                            });
                            E > 0 && a("#id_g", "#" + j).val(g);
                        }
                    }
                }

                function p() {
                    var g, n = [true, "", ""], v = {}, r = f.p.prmNames, E, A;
                    if (a.isFunction(c.beforeCheckValues)) {
                        var B = c.beforeCheckValues(k, a("#" + e), k[f.p.id + "_id"] == "_empty" ? r.addoper : r.editoper);
                        if (B && typeof B === "object")k = B;
                    }
                    for (var M in k)
                        if (k.hasOwnProperty(M)) {
                            n =
                                checkValues(k[M], M, f);
                            if (n[0] === false)break;
                        }
                    if (n[0]) {
                        if (a.isFunction(c.onclickSubmit))v = c.onclickSubmit(c, k) || {};
                        if (a.isFunction(c.beforeSubmit))n = c.beforeSubmit(k, a("#" + e));
                    }
                    if (n[0] && !c.processing) {
                        c.processing = true;
                        a("#sData", "#" + j + "_2").addClass("ui-state-active");
                        A = r.oper;
                        E = r.id;
                        k[A] = a.trim(k[f.p.id + "_id"]) == "_empty" ? r.addoper : r.editoper;
                        if (k[A] != r.addoper)k[E] = k[f.p.id + "_id"];
                        else if (k[E] === undefined)k[E] = k[f.p.id + "_id"];
                        delete k[f.p.id + "_id"];
                        k = a.extend(k, c.editData, v);
                        v = a.extend({
                                url: c.url ?
                                    c.url : a(f).jqGrid("getGridParam", "editurl"),
                                type: c.mtype,
                                data: a.isFunction(c.serializeEditData) ? c.serializeEditData(k) : k,
                                complete: function(x, P) {
                                    if (P != "success") {
                                        n[0] = false;
                                        n[1] = a.isFunction(c.errorTextFormat) ? c.errorTextFormat(x) : P + " Status: '" + x.statusText + "'. Error code: " + x.status;
                                    } else if (a.isFunction(c.afterSubmit))n = c.afterSubmit(x, k);
                                    if (n[0] === false) {
                                        a("#FormError>td", "#" + j).html(n[1]);
                                        a("#FormError", "#" + j).show();
                                    } else {
                                        a.each(f.p.colModel, function() {
                                            if (i[this.name] && this.formatter && this.formatter ==
                                                "select")
                                                try {
                                                    delete i[this.name];
                                                } catch (G) {
                                                }
                                        });
                                        k = a.extend(k, i);
                                        f.p.autoencode && a.each(k, function(G, V) { k[G] = a.jgrid.htmlDecode(V); });
                                        if (k[A] == r.addoper) {
                                            n[2] || (n[2] = parseInt(f.p.records, 10) + 1);
                                            k[E] = n[2];
                                            if (c.closeAfterAdd) {
                                                if (c.reloadAfterSubmit)a(f).trigger("reloadGrid");
                                                else {
                                                    a(f).jqGrid("addRowData", n[2], k, b.addedrow);
                                                    a(f).jqGrid("setSelection", n[2]);
                                                }
                                                hideModal("#" + m.themodal, { gb: "#gbox_" + l, jqm: b.jqModal, onClose: c.onClose });
                                            } else if (c.clearAfterAdd) {
                                                c.reloadAfterSubmit ? a(f).trigger("reloadGrid") : a(f).jqGrid("addRowData",
                                                    n[2], k, b.addedrow);
                                                h("_empty", f, e);
                                            } else c.reloadAfterSubmit ? a(f).trigger("reloadGrid") : a(f).jqGrid("addRowData", n[2], k, b.addedrow);
                                        } else {
                                            if (c.reloadAfterSubmit) {
                                                a(f).trigger("reloadGrid");
                                                c.closeAfterEdit || setTimeout(function() { a(f).jqGrid("setSelection", k[E]); }, 1E3);
                                            } else f.p.treeGrid === true ? a(f).jqGrid("setTreeRow", k[E], k) : a(f).jqGrid("setRowData", k[E], k);
                                            c.closeAfterEdit && hideModal("#" + m.themodal, { gb: "#gbox_" + l, jqm: b.jqModal, onClose: c.onClose });
                                        }
                                        if (a.isFunction(c.afterComplete)) {
                                            g = x;
                                            setTimeout(function() {
                                                c.afterComplete(g,
                                                    k, a("#" + e));
                                                g = null;
                                            }, 500);
                                        }
                                    }
                                    c.processing = false;
                                    if (c.checkOnSubmit || c.checkOnUpdate) {
                                        a("#" + e).data("disabled", false);
                                        if (c._savedData[f.p.id + "_id"] != "_empty")for (var C in c._savedData)if (k[C])c._savedData[C] = k[C];
                                    }
                                    a("#sData", "#" + j + "_2").removeClass("ui-state-active");
                                    try {
                                        a(":input:visible", "#" + e)[0].focus();
                                    } catch (T) {
                                    }
                                },
                                error: function(x, P, C) {
                                    a("#FormError>td", "#" + j).html(P + " : " + C);
                                    a("#FormError", "#" + j).show();
                                    c.processing = false;
                                    a("#" + e).data("disabled", false);
                                    a("#sData", "#" + j + "_2").removeClass("ui-state-active");
                                }
                            },
                            a.jgrid.ajaxOptions, c.ajaxEditOptions);
                        if (!v.url && !c.useDataProxy)
                            if (a.isFunction(f.p.dataProxy))c.useDataProxy = true;
                            else {
                                n[0] = false;
                                n[1] += " " + a.jgrid.errors.nourl;
                            }
                        if (n[0])c.useDataProxy ? f.p.dataProxy.call(f, v, "set_" + f.p.id) : a.ajax(v);
                    }
                    if (n[0] === false) {
                        a("#FormError>td", "#" + j).html(n[1]);
                        a("#FormError", "#" + j).show();
                    }
                }

                function H(g, n) {
                    var v = false, r;
                    for (r in g)
                        if (g[r] != n[r]) {
                            v = true;
                            break;
                        }
                    return v;
                }

                var f = this;
                if (f.grid && d) {
                    var l = f.p.id,
                        e = "FrmGrid_" + l,
                        j = "TblGrid_" + l,
                        m = {
                            themodal: "editmod" + l,
                            modalhead: "edithd" +
                                l,
                            modalcontent: "editcnt" + l,
                            scrollelm: e
                        },
                        u = a.isFunction(c.beforeShowForm) ? c.beforeShowForm : false,
                        Q = a.isFunction(c.afterShowForm) ? c.afterShowForm : false,
                        o = a.isFunction(c.beforeInitData) ? c.beforeInitData : false,
                        s = a.isFunction(c.onInitializeForm) ? c.onInitializeForm : false,
                        y = 1,
                        J = 0,
                        k,
                        i,
                        w,
                        O;
                    if (d == "new") {
                        d = "_empty";
                        b.caption = b.addCaption;
                    } else b.caption = b.editCaption;
                    b.recreateForm === true && a("#" + m.themodal).html() != null && a("#" + m.themodal).remove();
                    var S = true;
                    if (b.checkOnUpdate && b.jqModal && !b.modal)S = false;
                    if (a("#" +
                        m.themodal).html() != null) {
                        a(".ui-jqdialog-title", "#" + m.modalhead).html(b.caption);
                        a("#FormError", "#" + j).hide();
                        if (c.topinfo) {
                            a(".topinfo", "#" + j + "_2").html(c.topinfo);
                            a(".tinfo", "#" + j + "_2").show();
                        } else a(".tinfo", "#" + j + "_2").hide();
                        if (c.bottominfo) {
                            a(".bottominfo", "#" + j + "_2").html(c.bottominfo);
                            a(".binfo", "#" + j + "_2").show();
                        } else a(".binfo", "#" + j + "_2").hide();
                        o && o(a("#" + e));
                        h(d, f, e);
                        d == "_empty" || !c.viewPagerButtons ? a("#pData, #nData", "#" + j + "_2").hide() : a("#pData, #nData", "#" + j + "_2").show();
                        if (c.processing ===
                            true) {
                            c.processing = false;
                            a("#sData", "#" + j + "_2").removeClass("ui-state-active");
                        }
                        if (a("#" + e).data("disabled") === true) {
                            a(".confirm", "#" + m.themodal).hide();
                            a("#" + e).data("disabled", false);
                        }
                        u && u(a("#" + e));
                        a("#" + m.themodal).data("onClose", c.onClose);
                        viewModal("#" + m.themodal, { gbox: "#gbox_" + l, jqm: b.jqModal, jqM: false, closeoverlay: S, modal: b.modal });
                        S || a(".jqmOverlay").click(function() {
                            if (!t())return false;
                            hideModal("#" + m.themodal, { gb: "#gbox_" + l, jqm: b.jqModal, onClose: c.onClose });
                            return false;
                        });
                        Q && Q(a("#" + e));
                    } else {
                        a(f.p.colModel).each(function() {
                            var g =
                                this.formoptions;
                            y = Math.max(y, g ? g.colpos || 0 : 0);
                            J = Math.max(J, g ? g.rowpos || 0 : 0);
                        });
                        var I = isNaN(b.dataheight) ? b.dataheight : b.dataheight + "px", K;
                        I = a("<form name='FormPost' id='" + e + "' class='FormGrid' onSubmit='return false;' style='width:100%;overflow:auto;position:relative;height:" + I + ";'></form>").data("disabled", false);
                        var L = a("<table id='" + j + "' class='EditTable' cellspacing='0' cellpading='0' border='0'><tbody></tbody></table>");
                        a(I).append(L);
                        K = a("<tr id='FormError' style='display:none'><td class='ui-state-error' colspan='" +
                            y * 2 + "'></td></tr>");
                        K[0].rp = 0;
                        a(L).append(K);
                        K = a("<tr style='display:none' class='tinfo'><td class='topinfo' colspan='" + y * 2 + "'>" + c.topinfo + "</td></tr>");
                        K[0].rp = 0;
                        a(L).append(K);
                        o && o(a("#" + e));
                        K = (o = f.p.direction == "rtl" ? true : false) ? "nData" : "pData";
                        var N = o ? "pData" : "nData";
                        z(d, f, L, y);
                        K = "<a href='javascript:void(0)' id='" + K + "' class='fm-button ui-state-default ui-corner-left'><span class='ui-icon ui-icon-triangle-1-w'></span></div>";
                        N = "<a href='javascript:void(0)' id='" + N + "' class='fm-button ui-state-default ui-corner-right'><span class='ui-icon ui-icon-triangle-1-e'></span></div>";
                        var Z = "<a href='javascript:void(0)' id='sData' class='fm-button ui-state-default ui-corner-all'>" + b.bSubmit + "</a>", $ = "<a href='javascript:void(0)' id='cData' class='fm-button ui-state-default ui-corner-all'>" + b.bCancel + "</a>";
                        K = "<table border='0' class='EditTable' id='" + j + "_2'><tbody><tr id='Act_Buttons'><td class='navButton ui-widget-content'>" + (o ? N + K : K + N) + "</td><td class='EditButton ui-widget-content'>" + Z + $ + "</td></tr>";
                        K += "<tr style='display:none' class='binfo'><td class='bottominfo' colspan='2'>" +
                            c.bottominfo + "</td></tr>";
                        K += "</tbody></table>";
                        if (J > 0) {
                            var aa = [];
                            a.each(a(L)[0].rows, function(g, n) { aa[g] = n; });
                            aa.sort(function(g, n) {
                                if (g.rp > n.rp)return 1;
                                if (g.rp < n.rp)return-1;
                                return 0;
                            });
                            a.each(aa, function(g, n) { a("tbody", L).append(n); });
                        }
                        b.gbox = "#gbox_" + l;
                        var Y = false;
                        if (b.closeOnEscape === true) {
                            b.closeOnEscape = false;
                            Y = true;
                        }
                        I = a("<span></span>").append(I).append(K);
                        createModal(m, I, b, "#gview_" + f.p.id, a("#gview_" + f.p.id)[0]);
                        if (o) {
                            a("#pData, #nData", "#" + j + "_2").css("float", "right");
                            a(".EditButton", "#" + j +
                                "_2").css("text-align", "left");
                        }
                        c.topinfo && a(".tinfo", "#" + j + "_2").show();
                        c.bottominfo && a(".binfo", "#" + j + "_2").show();
                        K = I = null;
                        a("#" + m.themodal).keydown(function(g) {
                            var n = g.target;
                            if (a("#" + e).data("disabled") === true)return false;
                            if (c.savekey[0] === true && g.which == c.savekey[1])
                                if (n.tagName != "TEXTAREA") {
                                    a("#sData", "#" + j + "_2").trigger("click");
                                    return false;
                                }
                            if (g.which === 27) {
                                if (!t())return false;
                                Y && hideModal(this, { gb: b.gbox, jqm: b.jqModal, onClose: c.onClose });
                                return false;
                            }
                            if (c.navkeys[0] === true) {
                                if (a("#id_g",
                                    "#" + j).val() == "_empty")return true;
                                if (g.which == c.navkeys[1]) {
                                    a("#pData", "#" + j + "_2").trigger("click");
                                    return false;
                                }
                                if (g.which == c.navkeys[2]) {
                                    a("#nData", "#" + j + "_2").trigger("click");
                                    return false;
                                }
                            }
                        });
                        if (b.checkOnUpdate) {
                            a("a.ui-jqdialog-titlebar-close span", "#" + m.themodal).removeClass("jqmClose");
                            a("a.ui-jqdialog-titlebar-close", "#" + m.themodal).unbind("click").click(function() {
                                if (!t())return false;
                                hideModal("#" + m.themodal, { gb: "#gbox_" + l, jqm: b.jqModal, onClose: c.onClose });
                                return false;
                            });
                        }
                        b.saveicon = a.extend([
                            true,
                            "left", "ui-icon-disk"
                        ], b.saveicon);
                        b.closeicon = a.extend([true, "left", "ui-icon-close"], b.closeicon);
                        if (b.saveicon[0] === true)a("#sData", "#" + j + "_2").addClass(b.saveicon[1] == "right" ? "fm-button-icon-right" : "fm-button-icon-left").append("<span class='ui-icon " + b.saveicon[2] + "'></span>");
                        if (b.closeicon[0] === true)a("#cData", "#" + j + "_2").addClass(b.closeicon[1] == "right" ? "fm-button-icon-right" : "fm-button-icon-left").append("<span class='ui-icon " + b.closeicon[2] + "'></span>");
                        if (c.checkOnSubmit || c.checkOnUpdate) {
                            Z =
                                "<a href='javascript:void(0)' id='sNew' class='fm-button ui-state-default ui-corner-all' style='z-index:1002'>" + b.bYes + "</a>";
                            N = "<a href='javascript:void(0)' id='nNew' class='fm-button ui-state-default ui-corner-all' style='z-index:1002'>" + b.bNo + "</a>";
                            $ = "<a href='javascript:void(0)' id='cNew' class='fm-button ui-state-default ui-corner-all' style='z-index:1002'>" + b.bExit + "</a>";
                            I = b.zIndex || 999;
                            I++;
                            a("<div class='ui-widget-overlay jqgrid-overlay confirm' style='z-index:" + I + ";display:none;'>&#160;" +
                            (a.browser.msie && a.browser.version == 6 ? '<iframe style="display:block;position:absolute;z-index:-1;filter:Alpha(Opacity=\'0\');" src="javascript:false;"></iframe>' : "") + "</div><div class='confirm ui-widget-content ui-jqconfirm' style='z-index:" + (I + 1) + "'>" + b.saveData + "<br/><br/>" + Z + N + $ + "</div>").insertAfter("#" + e);
                            a("#sNew", "#" + m.themodal).click(function() {
                                p();
                                a("#" + e).data("disabled", false);
                                a(".confirm", "#" + m.themodal).hide();
                                return false;
                            });
                            a("#nNew", "#" + m.themodal).click(function() {
                                a(".confirm", "#" +
                                    m.themodal).hide();
                                a("#" + e).data("disabled", false);
                                setTimeout(function() { a(":input", "#" + e)[0].focus(); }, 0);
                                return false;
                            });
                            a("#cNew", "#" + m.themodal).click(function() {
                                a(".confirm", "#" + m.themodal).hide();
                                a("#" + e).data("disabled", false);
                                hideModal("#" + m.themodal, { gb: "#gbox_" + l, jqm: b.jqModal, onClose: c.onClose });
                                return false;
                            });
                        }
                        s && s(a("#" + e));
                        d == "_empty" || !c.viewPagerButtons ? a("#pData,#nData", "#" + j + "_2").hide() : a("#pData,#nData", "#" + j + "_2").show();
                        u && u(a("#" + e));
                        a("#" + m.themodal).data("onClose", c.onClose);
                        viewModal("#" + m.themodal, { gbox: "#gbox_" + l, jqm: b.jqModal, closeoverlay: S, modal: b.modal });
                        S || a(".jqmOverlay").click(function() {
                            if (!t())return false;
                            hideModal("#" + m.themodal, { gb: "#gbox_" + l, jqm: b.jqModal, onClose: c.onClose });
                            return false;
                        });
                        Q && Q(a("#" + e));
                        a(".fm-button", "#" + m.themodal).hover(function() { a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                        a("#sData", "#" + j + "_2").click(function() {
                            k = {};
                            i = {};
                            a("#FormError", "#" + j).hide();
                            F();
                            if (k[f.p.id + "_id"] == "_empty")p();
                            else if (b.checkOnSubmit ===
                                true) {
                                w = a.extend({}, k, i);
                                if (O = H(w, c._savedData)) {
                                    a("#" + e).data("disabled", true);
                                    a(".confirm", "#" + m.themodal).show();
                                } else p();
                            } else p();
                            return false;
                        });
                        a("#cData", "#" + j + "_2").click(function() {
                            if (!t())return false;
                            hideModal("#" + m.themodal, { gb: "#gbox_" + l, jqm: b.jqModal, onClose: c.onClose });
                            return false;
                        });
                        a("#nData", "#" + j + "_2").click(function() {
                            if (!t())return false;
                            a("#FormError", "#" + j).hide();
                            var g = D();
                            g[0] = parseInt(g[0], 10);
                            if (g[0] != -1 && g[1][g[0] + 1]) {
                                a.isFunction(b.onclickPgButtons) && b.onclickPgButtons("next",
                                    a("#" + e), g[1][g[0]]);
                                h(g[1][g[0] + 1], f, e);
                                a(f).jqGrid("setSelection", g[1][g[0] + 1]);
                                a.isFunction(b.afterclickPgButtons) && b.afterclickPgButtons("next", a("#" + e), g[1][g[0] + 1]);
                                q(g[0] + 1, g[1].length - 1);
                            }
                            return false;
                        });
                        a("#pData", "#" + j + "_2").click(function() {
                            if (!t())return false;
                            a("#FormError", "#" + j).hide();
                            var g = D();
                            if (g[0] != -1 && g[1][g[0] - 1]) {
                                a.isFunction(b.onclickPgButtons) && b.onclickPgButtons("prev", a("#" + e), g[1][g[0]]);
                                h(g[1][g[0] - 1], f, e);
                                a(f).jqGrid("setSelection", g[1][g[0] - 1]);
                                a.isFunction(b.afterclickPgButtons) &&
                                    b.afterclickPgButtons("prev", a("#" + e), g[1][g[0] - 1]);
                                q(g[0] - 1, g[1].length - 1);
                            }
                            return false;
                        });
                    }
                    u = D();
                    q(u[0], u[1].length - 1);
                }
            });
        },
        viewGridRow: function(d, b) {
            b = a.extend({ top: 0, left: 0, width: 0, height: "auto", dataheight: "auto", modal: false, drag: true, resize: true, jqModal: true, closeOnEscape: false, labelswidth: "30%", closeicon: [], navkeys: [false, 38, 40], onClose: null, beforeShowForm: null, viewPagerButtons: true }, a.jgrid.view, b || {});
            return this.each(function() {
                function q() {
                    if (b.closeOnEscape === true || b.navkeys[0] === true)
                        setTimeout(function() {
                            a(".ui-jqdialog-titlebar-close",
                                "#" + l.modalhead).focus();
                        }, 0);
                }

                function D(i, w) {
                    i === 0 ? a("#pData", "#" + f + "_2").addClass("ui-state-disabled") : a("#pData", "#" + f + "_2").removeClass("ui-state-disabled");
                    i == w ? a("#nData", "#" + f + "_2").addClass("ui-state-disabled") : a("#nData", "#" + f + "_2").removeClass("ui-state-disabled");
                }

                function t() {
                    var i = a(h).jqGrid("getDataIDs"), w = a("#id_g", "#" + f).val();
                    return[a.inArray(w, i), i];
                }

                function F(i, w, O, S) {
                    for (var I,
                        K,
                        L,
                        N = 0,
                        Z,
                        $,
                        aa = [],
                        Y = false,
                        g = "<td class='CaptionTD form-view-label ui-widget-content' width='" + b.labelswidth +
                            "'>&#160;</td><td class='DataTD form-view-data ui-helper-reset ui-widget-content'>&#160;</td>",
                        n = "",
                        v = ["integer", "number", "currency"],
                        r = 0,
                        E = 0,
                        A,
                        B,
                        M,
                        x = 1; x <= S; x++)n += x == 1 ? g : "<td class='CaptionTD form-view-label ui-widget-content'>&#160;</td><td class='DataTD form-view-data ui-widget-content'>&#160;</td>";
                    a(w.p.colModel).each(function() {
                        K = this.editrules && this.editrules.edithidden === true ? false : this.hidden === true ? true : false;
                        if (!K && this.align === "right")
                            if (this.formatter && a.inArray(this.formatter, v) !== -1)
                                r =
                                    Math.max(r, parseInt(this.width, 10));
                            else E = Math.max(E, parseInt(this.width, 10));
                    });
                    A = r !== 0 ? r : E !== 0 ? E : 0;
                    Y = a(w).jqGrid("getInd", i);
                    a(w.p.colModel).each(function(P) {
                        I = this.name;
                        B = false;
                        $ = (K = this.editrules && this.editrules.edithidden === true ? false : this.hidden === true ? true : false) ? "style='display:none'" : "";
                        M = typeof this.viewable != "boolean" ? true : this.viewable;
                        if (I !== "cb" && I !== "subgrid" && I !== "rn" && M) {
                            Z = Y === false ? "" : I == w.p.ExpandColumn && w.p.treeGrid === true ? a("td:eq(" + P + ")", w.rows[Y]).text() : a("td:eq(" + P + ")", w.rows[Y]).html();
                            B = this.align === "right" && A !== 0 ? true : false;
                            a.extend({}, this.editoptions || {}, { id: I, name: I });
                            var C = a.extend({}, { rowabove: false, rowcontent: "" }, this.formoptions || {}), T = parseInt(C.rowpos, 10) || N + 1, G = parseInt((parseInt(C.colpos, 10) || 1) * 2, 10);
                            if (C.rowabove) {
                                var V = a("<tr><td class='contentinfo' colspan='" + S * 2 + "'>" + C.rowcontent + "</td></tr>");
                                a(O).append(V);
                                V[0].rp = T;
                            }
                            L = a(O).find("tr[rowpos=" + T + "]");
                            if (L.length === 0) {
                                L = a("<tr " + $ + " rowpos='" + T + "'></tr>").addClass("FormData").attr("id", "trv_" + I);
                                a(L).append(n);
                                a(O).append(L);
                                L[0].rp = T;
                            }
                            a("td:eq(" + (G - 2) + ")", L[0]).html("<b>" + (typeof C.label === "undefined" ? w.p.colNames[P] : C.label) + "</b>");
                            a("td:eq(" + (G - 1) + ")", L[0]).append("<span>" + Z + "</span>").attr("id", "v_" + I);
                            B && a("td:eq(" + (G - 1) + ") span", L[0]).css({ "text-align": "right", width: A + "px" });
                            aa[N] = P;
                            N++;
                        }
                    });
                    if (N > 0) {
                        i = a("<tr class='FormData' style='display:none'><td class='CaptionTD'></td><td colspan='" + (S * 2 - 1) + "' class='DataTD'><input class='FormElement' id='id_g' type='text' name='id' value='" + i + "'/></td></tr>");
                        i[0].rp = N + 99;
                        a(O).append(i);
                    }
                    return aa;
                }

                function z(i, w) {
                    var O, S, I = 0, K, L;
                    if (L = a(w).jqGrid("getInd", i, true)) {
                        a("td", L).each(function(N) {
                            O = w.p.colModel[N].name;
                            S = w.p.colModel[N].editrules && w.p.colModel[N].editrules.edithidden === true ? false : w.p.colModel[N].hidden === true ? true : false;
                            if (O !== "cb" && O !== "subgrid" && O !== "rn") {
                                K = O == w.p.ExpandColumn && w.p.treeGrid === true ? a(this).text() : a(this).html();
                                a.extend({}, w.p.colModel[N].editoptions || {});
                                O = a.jgrid.jqID("v_" + O);
                                a("#" + O + " span", "#" + f).html(K);
                                S && a("#" + O, "#" + f).parents("tr:first").hide();
                                I++;
                            }
                        });
                        I >
                            0 && a("#id_g", "#" + f).val(i);
                    }
                }

                var h = this;
                if (h.grid && d) {
                    if (!b.imgpath)b.imgpath = h.p.imgpath;
                    var p = h.p.id, H = "ViewGrid_" + p, f = "ViewTbl_" + p, l = { themodal: "viewmod" + p, modalhead: "viewhd" + p, modalcontent: "viewcnt" + p, scrollelm: H }, e = 1, j = 0;
                    if (a("#" + l.themodal).html() != null) {
                        a(".ui-jqdialog-title", "#" + l.modalhead).html(b.caption);
                        a("#FormError", "#" + f).hide();
                        z(d, h);
                        a.isFunction(b.beforeShowForm) && b.beforeShowForm(a("#" + H));
                        viewModal("#" + l.themodal, { gbox: "#gbox_" + p, jqm: b.jqModal, jqM: false, modal: b.modal });
                        q();
                    } else {
                        a(h.p.colModel).each(function() {
                            var i =
                                this.formoptions;
                            e = Math.max(e, i ? i.colpos || 0 : 0);
                            j = Math.max(j, i ? i.rowpos || 0 : 0);
                        });
                        var m = isNaN(b.dataheight) ? b.dataheight : b.dataheight + "px", u = a("<form name='FormPost' id='" + H + "' class='FormGrid' style='width:100%;overflow:auto;position:relative;height:" + m + ";'></form>"), Q = a("<table id='" + f + "' class='EditTable' cellspacing='1' cellpading='2' border='0' style='table-layout:fixed'><tbody></tbody></table>");
                        a(u).append(Q);
                        F(d, h, Q, e);
                        m = h.p.direction == "rtl" ? true : false;
                        var o = "<a href='javascript:void(0)' id='" +
                            (m ? "nData" : "pData") + "' class='fm-button ui-state-default ui-corner-left'><span class='ui-icon ui-icon-triangle-1-w'></span></div>",
                            s = "<a href='javascript:void(0)' id='" + (m ? "pData" : "nData") + "' class='fm-button ui-state-default ui-corner-right'><span class='ui-icon ui-icon-triangle-1-e'></span></div>",
                            y = "<a href='javascript:void(0)' id='cData' class='fm-button ui-state-default ui-corner-all'>" + b.bClose + "</a>";
                        if (j > 0) {
                            var J = [];
                            a.each(a(Q)[0].rows, function(i, w) { J[i] = w; });
                            J.sort(function(i, w) {
                                if (i.rp > w.rp)return 1;
                                if (i.rp < w.rp)return-1;
                                return 0;
                            });
                            a.each(J, function(i, w) { a("tbody", Q).append(w); });
                        }
                        b.gbox = "#gbox_" + p;
                        var k = false;
                        if (b.closeOnEscape === true) {
                            b.closeOnEscape = false;
                            k = true;
                        }
                        u = a("<span></span>").append(u).append("<table border='0' class='EditTable' id='" + f + "_2'><tbody><tr id='Act_Buttons'><td class='navButton ui-widget-content' width='" + b.labelswidth + "'>" + (m ? s + o : o + s) + "</td><td class='EditButton ui-widget-content'>" + y + "</td></tr></tbody></table>");
                        createModal(l, u, b, "#gview_" + h.p.id, a("#gview_" + h.p.id)[0]);
                        if (m) {
                            a("#pData, #nData", "#" + f + "_2").css("float", "right");
                            a(".EditButton", "#" + f + "_2").css("text-align", "left");
                        }
                        b.viewPagerButtons || a("#pData, #nData", "#" + f + "_2").hide();
                        u = null;
                        a("#" + l.themodal).keydown(function(i) {
                            if (i.which === 27) {
                                k && hideModal(this, { gb: b.gbox, jqm: b.jqModal, onClose: b.onClose });
                                return false;
                            }
                            if (b.navkeys[0] === true) {
                                if (i.which === b.navkeys[1]) {
                                    a("#pData", "#" + f + "_2").trigger("click");
                                    return false;
                                }
                                if (i.which === b.navkeys[2]) {
                                    a("#nData", "#" + f + "_2").trigger("click");
                                    return false;
                                }
                            }
                        });
                        b.closeicon =
                            a.extend([true, "left", "ui-icon-close"], b.closeicon);
                        if (b.closeicon[0] === true)a("#cData", "#" + f + "_2").addClass(b.closeicon[1] == "right" ? "fm-button-icon-right" : "fm-button-icon-left").append("<span class='ui-icon " + b.closeicon[2] + "'></span>");
                        a.isFunction(b.beforeShowForm) && b.beforeShowForm(a("#" + H));
                        viewModal("#" + l.themodal, { gbox: "#gbox_" + p, jqm: b.jqModal, modal: b.modal });
                        a(".fm-button:not(.ui-state-disabled)", "#" + f + "_2").hover(function() { a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                        q();
                        a("#cData", "#" + f + "_2").click(function() {
                            hideModal("#" + l.themodal, { gb: "#gbox_" + p, jqm: b.jqModal, onClose: b.onClose });
                            return false;
                        });
                        a("#nData", "#" + f + "_2").click(function() {
                            a("#FormError", "#" + f).hide();
                            var i = t();
                            i[0] = parseInt(i[0], 10);
                            if (i[0] != -1 && i[1][i[0] + 1]) {
                                a.isFunction(b.onclickPgButtons) && b.onclickPgButtons("next", a("#" + H), i[1][i[0]]);
                                z(i[1][i[0] + 1], h);
                                a(h).jqGrid("setSelection", i[1][i[0] + 1]);
                                a.isFunction(b.afterclickPgButtons) && b.afterclickPgButtons("next", a("#" + H), i[1][i[0] + 1]);
                                D(i[0] + 1, i[1].length -
                                    1);
                            }
                            q();
                            return false;
                        });
                        a("#pData", "#" + f + "_2").click(function() {
                            a("#FormError", "#" + f).hide();
                            var i = t();
                            if (i[0] != -1 && i[1][i[0] - 1]) {
                                a.isFunction(b.onclickPgButtons) && b.onclickPgButtons("prev", a("#" + H), i[1][i[0]]);
                                z(i[1][i[0] - 1], h);
                                a(h).jqGrid("setSelection", i[1][i[0] - 1]);
                                a.isFunction(b.afterclickPgButtons) && b.afterclickPgButtons("prev", a("#" + H), i[1][i[0] - 1]);
                                D(i[0] - 1, i[1].length - 1);
                            }
                            q();
                            return false;
                        });
                    }
                    m = t();
                    D(m[0], m[1].length - 1);
                }
            });
        },
        delGridRow: function(d, b) {
            c = b = a.extend({
                top: 0,
                left: 0,
                width: 240,
                height: "auto",
                dataheight: "auto",
                modal: false,
                drag: true,
                resize: true,
                url: "",
                mtype: "POST",
                reloadAfterSubmit: true,
                beforeShowForm: null,
                afterShowForm: null,
                beforeSubmit: null,
                onclickSubmit: null,
                afterSubmit: null,
                jqModal: true,
                closeOnEscape: false,
                delData: {},
                delicon: [],
                cancelicon: [],
                onClose: null,
                ajaxDelOptions: {},
                processing: false,
                serializeDelData: null,
                useDataProxy: false
            }, a.jgrid.del, b || {});
            return this.each(function() {
                var q = this;
                if (q.grid)
                    if (d) {
                        var D = typeof b.beforeShowForm === "function" ? true : false,
                            t = typeof b.afterShowForm ===
                                "function" ? true : false,
                            F = q.p.id,
                            z = {},
                            h = "DelTbl_" + F,
                            p,
                            H,
                            f,
                            l,
                            e = { themodal: "delmod" + F, modalhead: "delhd" + F, modalcontent: "delcnt" + F, scrollelm: h };
                        if (jQuery.isArray(d))d = d.join();
                        if (a("#" + e.themodal).html() != null) {
                            a("#DelData>td", "#" + h).text(d);
                            a("#DelError", "#" + h).hide();
                            if (c.processing === true) {
                                c.processing = false;
                                a("#dData", "#" + h).removeClass("ui-state-active");
                            }
                            D && b.beforeShowForm(a("#" + h));
                            viewModal("#" + e.themodal, { gbox: "#gbox_" + F, jqm: b.jqModal, jqM: false, modal: b.modal });
                        } else {
                            var j = isNaN(b.dataheight) ? b.dataheight :
                                b.dataheight + "px";
                            j = "<div id='" + h + "' class='formdata' style='width:100%;overflow:auto;position:relative;height:" + j + ";'>";
                            j += "<table class='DelTable'><tbody>";
                            j += "<tr id='DelError' style='display:none'><td class='ui-state-error'></td></tr>";
                            j += "<tr id='DelData' style='display:none'><td >" + d + "</td></tr>";
                            j += '<tr><td class="delmsg" style="white-space:pre;">' + b.msg + "</td></tr><tr><td >&#160;</td></tr>";
                            j += "</tbody></table></div>";
                            j += "<table cellspacing='0' cellpadding='0' border='0' class='EditTable' id='" +
                                h + "_2'><tbody><tr><td class='DataTD ui-widget-content'></td></tr><tr style='display:block;height:3px;'><td></td></tr><tr><td class='DelButton EditButton'>" + ("<a href='javascript:void(0)' id='dData' class='fm-button ui-state-default ui-corner-all'>" + b.bSubmit + "</a>") + "&#160;" + ("<a href='javascript:void(0)' id='eData' class='fm-button ui-state-default ui-corner-all'>" + b.bCancel + "</a>") + "</td></tr></tbody></table>";
                            b.gbox = "#gbox_" + F;
                            createModal(e, j, b, "#gview_" + q.p.id, a("#gview_" + q.p.id)[0]);
                            a(".fm-button",
                                "#" + h + "_2").hover(function() { a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                            b.delicon = a.extend([true, "left", "ui-icon-scissors"], b.delicon);
                            b.cancelicon = a.extend([true, "left", "ui-icon-cancel"], b.cancelicon);
                            if (b.delicon[0] === true)a("#dData", "#" + h + "_2").addClass(b.delicon[1] == "right" ? "fm-button-icon-right" : "fm-button-icon-left").append("<span class='ui-icon " + b.delicon[2] + "'></span>");
                            if (b.cancelicon[0] === true)
                                a("#eData", "#" + h + "_2").addClass(b.cancelicon[1] ==
                                    "right" ? "fm-button-icon-right" : "fm-button-icon-left").append("<span class='ui-icon " + b.cancelicon[2] + "'></span>");
                            a("#dData", "#" + h + "_2").click(function() {
                                var m = [true, ""];
                                z = {};
                                var u = a("#DelData>td", "#" + h).text();
                                if (typeof b.onclickSubmit === "function")z = b.onclickSubmit(c, u) || {};
                                if (typeof b.beforeSubmit === "function")m = b.beforeSubmit(u);
                                if (m[0] && !c.processing) {
                                    c.processing = true;
                                    a(this).addClass("ui-state-active");
                                    f = q.p.prmNames;
                                    p = a.extend({}, c.delData, z);
                                    l = f.oper;
                                    p[l] = f.deloper;
                                    H = f.id;
                                    p[H] = u;
                                    var Q = a.extend({
                                        url: c.url ?
                                            c.url : a(q).jqGrid("getGridParam", "editurl"),
                                        type: b.mtype,
                                        data: a.isFunction(b.serializeDelData) ? b.serializeDelData(p) : p,
                                        complete: function(o, s) {
                                            if (s != "success") {
                                                m[0] = false;
                                                m[1] = a.isFunction(c.errorTextFormat) ? c.errorTextFormat(o) : s + " Status: '" + o.statusText + "'. Error code: " + o.status;
                                            } else if (typeof c.afterSubmit === "function")m = c.afterSubmit(o, p);
                                            if (m[0] === false) {
                                                a("#DelError>td", "#" + h).html(m[1]);
                                                a("#DelError", "#" + h).show();
                                            } else {
                                                if (c.reloadAfterSubmit)a(q).trigger("reloadGrid");
                                                else {
                                                    s = [];
                                                    s = u.split(",");
                                                    if (q.p.treeGrid === true)
                                                        try {
                                                            a(q).jqGrid("delTreeNode", s[0]);
                                                        } catch (y) {
                                                        }
                                                    else for (var J = 0; J < s.length; J++)a(q).jqGrid("delRowData", s[J]);
                                                    q.p.selrow = null;
                                                    q.p.selarrrow = [];
                                                }
                                                a.isFunction(c.afterComplete) && setTimeout(function() { c.afterComplete(o, u); }, 500);
                                            }
                                            c.processing = false;
                                            a("#dData", "#" + h + "_2").removeClass("ui-state-active");
                                            m[0] && hideModal("#" + e.themodal, { gb: "#gbox_" + F, jqm: b.jqModal, onClose: c.onClose });
                                        },
                                        error: function(o, s, y) {
                                            a("#DelError>td", "#" + h).html(s + " : " + y);
                                            a("#DelError", "#" + h).show();
                                            c.processing =
                                                false;
                                            a("#dData", "#" + h + "_2").removeClass("ui-state-active");
                                        }
                                    }, a.jgrid.ajaxOptions, b.ajaxDelOptions);
                                    if (!Q.url && !c.useDataProxy)
                                        if (a.isFunction(q.p.dataProxy))c.useDataProxy = true;
                                        else {
                                            m[0] = false;
                                            m[1] += " " + a.jgrid.errors.nourl;
                                        }
                                    if (m[0])c.useDataProxy ? q.p.dataProxy.call(q, Q, "del_" + q.p.id) : a.ajax(Q);
                                }
                                if (m[0] === false) {
                                    a("#DelError>td", "#" + h).html(m[1]);
                                    a("#DelError", "#" + h).show();
                                }
                                return false;
                            });
                            a("#eData", "#" + h + "_2").click(function() {
                                hideModal("#" + e.themodal, { gb: "#gbox_" + F, jqm: b.jqModal, onClose: c.onClose });
                                return false;
                            });
                            D && b.beforeShowForm(a("#" + h));
                            viewModal("#" + e.themodal, { gbox: "#gbox_" + F, jqm: b.jqModal, modal: b.modal });
                        }
                        t && b.afterShowForm(a("#" + h));
                        b.closeOnEscape === true && setTimeout(function() { a(".ui-jqdialog-titlebar-close", "#" + e.modalhead).focus(); }, 0);
                    }
            });
        },
        navGrid: function(d, b, q, D, t, F, z) {
            b = a.extend({
                edit: true,
                editicon: "ui-icon-pencil",
                add: true,
                addicon: "ui-icon-plus",
                del: true,
                delicon: "ui-icon-trash",
                search: true,
                searchicon: "ui-icon-search",
                refresh: true,
                refreshicon: "ui-icon-refresh",
                refreshstate: "firstpage",
                view: false,
                viewicon: "ui-icon-document",
                position: "left",
                closeOnEscape: true,
                beforeRefresh: null,
                afterRefresh: null,
                cloneToTop: false
            }, a.jgrid.nav, b || {});
            return this.each(function() {
                var h = { themodal: "alertmod", modalhead: "alerthd", modalcontent: "alertcnt" }, p = this, H, f, l;
                if (!(!p.grid || typeof d != "string")) {
                    if (a("#" + h.themodal).html() === null) {
                        if (typeof window.innerWidth != "undefined") {
                            H = window.innerWidth;
                            f = window.innerHeight;
                        } else if (typeof document.documentElement != "undefined" && typeof document.documentElement.clientWidth !=
                            "undefined" && document.documentElement.clientWidth !== 0) {
                            H = document.documentElement.clientWidth;
                            f = document.documentElement.clientHeight;
                        } else {
                            H = 1024;
                            f = 768;
                        }
                        createModal(h, "<div>" + b.alerttext + "</div><span tabindex='0'><span tabindex='-1' id='jqg_alrt'></span></span>", { gbox: "#gbox_" + p.p.id, jqModal: true, drag: true, resize: true, caption: b.alertcap, top: f / 2 - 25, left: H / 2 - 100, width: 200, height: "auto", closeOnEscape: b.closeOnEscape }, "", "", true);
                    }
                    H = 1;
                    if (b.cloneToTop && p.p.toppager)H = 2;
                    for (f = 0; f < H; f++) {
                        var e = a("<table cellspacing='0' cellpadding='0' border='0' class='ui-pg-table navtable' style='float:left;table-layout:auto;'><tbody><tr></tr></tbody></table>"),
                            j,
                            m;
                        if (f === 0) {
                            j = d;
                            m = p.p.id;
                            if (j == p.p.toppager) {
                                m += "_top";
                                H = 1;
                            }
                        } else {
                            j = p.p.toppager;
                            m = p.p.id + "_top";
                        }
                        p.p.direction == "rtl" && a(e).attr("dir", "rtl").css("float", "right");
                        if (b.add) {
                            D = D || {};
                            l = a("<td class='ui-pg-button ui-corner-all'></td>");
                            a(l).append("<div class='ui-pg-div'><span class='ui-icon " + b.addicon + "'></span>" + b.addtext + "</div>");
                            a("tr", e).append(l);
                            a(l, e).attr({ title: b.addtitle || "", id: D.id || "add_" + m }).click(function() {
                                a(this).hasClass("ui-state-disabled") || (typeof b.addfunc == "function" ? b.addfunc() :
                                    a(p).jqGrid("editGridRow", "new", D));
                                return false;
                            }).hover(function() { a(this).hasClass("ui-state-disabled") || a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                            l = null;
                        }
                        if (b.edit) {
                            l = a("<td class='ui-pg-button ui-corner-all'></td>");
                            q = q || {};
                            a(l).append("<div class='ui-pg-div'><span class='ui-icon " + b.editicon + "'></span>" + b.edittext + "</div>");
                            a("tr", e).append(l);
                            a(l, e).attr({ title: b.edittitle || "", id: q.id || "edit_" + m }).click(function() {
                                if (!a(this).hasClass("ui-state-disabled")) {
                                    var u =
                                        p.p.selrow;
                                    if (u)typeof b.editfunc == "function" ? b.editfunc(u) : a(p).jqGrid("editGridRow", u, q);
                                    else {
                                        viewModal("#" + h.themodal, { gbox: "#gbox_" + p.p.id, jqm: true });
                                        a("#jqg_alrt").focus();
                                    }
                                }
                                return false;
                            }).hover(function() { a(this).hasClass("ui-state-disabled") || a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                            l = null;
                        }
                        if (b.view) {
                            l = a("<td class='ui-pg-button ui-corner-all'></td>");
                            z = z || {};
                            a(l).append("<div class='ui-pg-div'><span class='ui-icon " + b.viewicon + "'></span>" + b.viewtext +
                                "</div>");
                            a("tr", e).append(l);
                            a(l, e).attr({ title: b.viewtitle || "", id: z.id || "view_" + m }).click(function() {
                                if (!a(this).hasClass("ui-state-disabled")) {
                                    var u = p.p.selrow;
                                    if (u)a(p).jqGrid("viewGridRow", u, z);
                                    else {
                                        viewModal("#" + h.themodal, { gbox: "#gbox_" + p.p.id, jqm: true });
                                        a("#jqg_alrt").focus();
                                    }
                                }
                                return false;
                            }).hover(function() { a(this).hasClass("ui-state-disabled") || a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                            l = null;
                        }
                        if (b.del) {
                            l = a("<td class='ui-pg-button ui-corner-all'></td>");
                            t = t || {};
                            a(l).append("<div class='ui-pg-div'><span class='ui-icon " + b.delicon + "'></span>" + b.deltext + "</div>");
                            a("tr", e).append(l);
                            a(l, e).attr({ title: b.deltitle || "", id: t.id || "del_" + m }).click(function() {
                                if (!a(this).hasClass("ui-state-disabled")) {
                                    var u;
                                    if (p.p.multiselect) {
                                        u = p.p.selarrrow;
                                        if (u.length === 0)u = null;
                                    } else u = p.p.selrow;
                                    if (u)"function" == typeof b.delfunc ? b.delfunc(u) : a(p).jqGrid("delGridRow", u, t);
                                    else {
                                        viewModal("#" + h.themodal, { gbox: "#gbox_" + p.p.id, jqm: true });
                                        a("#jqg_alrt").focus();
                                    }
                                }
                                return false;
                            }).hover(function() {
                                a(this).hasClass("ui-state-disabled") ||
                                    a(this).addClass("ui-state-hover");
                            }, function() { a(this).removeClass("ui-state-hover"); });
                            l = null;
                        }
                        if (b.add || b.edit || b.del || b.view)a("tr", e).append("<td class='ui-pg-button ui-state-disabled' style='width:4px;'><span class='ui-separator'></span></td>");
                        if (b.search) {
                            l = a("<td class='ui-pg-button ui-corner-all'></td>");
                            F = F || {};
                            a(l).append("<div class='ui-pg-div'><span class='ui-icon " + b.searchicon + "'></span>" + b.searchtext + "</div>");
                            a("tr", e).append(l);
                            a(l, e).attr({
                                title: b.searchtitle || "",
                                id: F.id || "search_" +
                                    m
                            }).click(function() {
                                a(this).hasClass("ui-state-disabled") || a(p).jqGrid("searchGrid", F);
                                return false;
                            }).hover(function() { a(this).hasClass("ui-state-disabled") || a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                            l = null;
                        }
                        if (b.refresh) {
                            l = a("<td class='ui-pg-button ui-corner-all'></td>");
                            a(l).append("<div class='ui-pg-div'><span class='ui-icon " + b.refreshicon + "'></span>" + b.refreshtext + "</div>");
                            a("tr", e).append(l);
                            a(l, e).attr({ title: b.refreshtitle || "", id: "refresh_" + m }).click(function() {
                                if (!a(this).hasClass("ui-state-disabled")) {
                                    a.isFunction(b.beforeRefresh) &&
                                        b.beforeRefresh();
                                    p.p.search = false;
                                    try {
                                        a("#fbox_" + p.p.id).searchFilter().reset();
                                        a.isFunction(p.clearToolbar) && p.clearToolbar(false);
                                    } catch (u) {
                                    }
                                    switch (b.refreshstate) {
                                    case "firstpage":
                                        a(p).trigger("reloadGrid", [{ page: 1 }]);
                                        break;
                                    case "current":
                                        a(p).trigger("reloadGrid", [{ current: true }]);
                                        break;
                                    }
                                    a.isFunction(b.afterRefresh) && b.afterRefresh();
                                }
                                return false;
                            }).hover(function() { a(this).hasClass("ui-state-disabled") || a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                            l = null;
                        }
                        l =
                            a(".ui-jqgrid").css("font-size") || "11px";
                        a("body").append("<div id='testpg2' class='ui-jqgrid ui-widget ui-widget-content' style='font-size:" + l + ";visibility:hidden;' ></div>");
                        l = a(e).clone().appendTo("#testpg2").width();
                        a("#testpg2").remove();
                        a(j + "_" + b.position, j).append(e);
                        if (p.p._nvtd) {
                            if (l > p.p._nvtd[0]) {
                                a(j + "_" + b.position, j).width(l);
                                p.p._nvtd[0] = l;
                            }
                            p.p._nvtd[1] = l;
                        }
                        e = l = l = null;
                    }
                }
            });
        },
        navButtonAdd: function(d, b) {
            b = a.extend({
                caption: "newButton",
                title: "",
                buttonicon: "ui-icon-newwin",
                onClickButton: null,
                position: "last",
                cursor: "pointer"
            }, b || {});
            return this.each(function() {
                if (this.grid) {
                    if (d.indexOf("#") !== 0)d = "#" + d;
                    var q = a(".navtable", d)[0], D = this;
                    if (q) {
                        var t = a("<td></td>");
                        b.buttonicon.toString().toUpperCase() == "NONE" ? a(t).addClass("ui-pg-button ui-corner-all").append("<div class='ui-pg-div'>" + b.caption + "</div>") : a(t).addClass("ui-pg-button ui-corner-all").append("<div class='ui-pg-div'><span class='ui-icon " + b.buttonicon + "'></span>" + b.caption + "</div>");
                        b.id && a(t).attr("id", b.id);
                        if (b.position == "first")
                            q.rows[0].cells.length ===
                                0 ? a("tr", q).append(t) : a("tr td:eq(0)", q).before(t);
                        else a("tr", q).append(t);
                        a(t, q).attr("title", b.title || "").click(function(F) {
                            a(this).hasClass("ui-state-disabled") || a.isFunction(b.onClickButton) && b.onClickButton.call(D, F);
                            return false;
                        }).hover(function() { a(this).hasClass("ui-state-disabled") || a(this).addClass("ui-state-hover"); }, function() { a(this).removeClass("ui-state-hover"); });
                    }
                }
            });
        },
        navSeparatorAdd: function(d, b) {
            b = a.extend({ sepclass: "ui-separator", sepcontent: "" }, b || {});
            return this.each(function() {
                if (this.grid) {
                    if (d.indexOf("#") !==
                        0)d = "#" + d;
                    var q = a(".navtable", d)[0];
                    if (q) {
                        var D = "<td class='ui-pg-button ui-state-disabled' style='width:4px;'><span class='" + b.sepclass + "'></span>" + b.sepcontent + "</td>";
                        a("tr", q).append(D);
                    }
                }
            });
        },
        GridToForm: function(d, b) {
            return this.each(function() {
                var q = this;
                if (q.grid) {
                    var D = a(q).jqGrid("getRowData", d);
                    if (D)
                        for (var t in D)
                            a("[name=" + t + "]", b).is("input:radio") || a("[name=" + t + "]", b).is("input:checkbox") ? a("[name=" + t + "]", b).each(function() {
                                a(this).val() == D[t] ? a(this).attr("checked", "checked") : a(this).attr("checked",
                                    "");
                            }) : a("[name=" + t + "]", b).val(D[t]);
                }
            });
        },
        FormToGrid: function(d, b, q, D) {
            return this.each(function() {
                var t = this;
                if (t.grid) {
                    q || (q = "set");
                    D || (D = "first");
                    var F = a(b).serializeArray(), z = {};
                    a.each(F, function(h, p) { z[p.name] = p.value; });
                    if (q == "add")a(t).jqGrid("addRowData", d, z, D);
                    else q == "set" && a(t).jqGrid("setRowData", d, z);
                }
            });
        }
    });
})(jQuery);
jQuery.fn.searchFilter = function(k, H) {
    function I(e, l, v) {
        this.$ = e;
        this.add = function(a) {
            a == null ? e.find(".ui-add-last").click() : e.find(".sf:eq(" + a + ") .ui-add").click();
            return this;
        };
        this.del = function(a) {
            a == null ? e.find(".sf:last .ui-del").click() : e.find(".sf:eq(" + a + ") .ui-del").click();
            return this;
        };
        this.search = function() {
            e.find(".ui-search").click();
            return this;
        };
        this.reset = function() {
            e.find(".ui-reset").click();
            return this;
        };
        this.close = function() {
            e.find(".ui-closer").click();
            return this;
        };
        if (l != null) {
            function C() {
                jQuery(this).toggleClass("ui-state-hover");
                return false;
            }

            function D(a) {
                jQuery(this).toggleClass("ui-state-active", a.type == "mousedown");
                return false;
            }

            function m(a, b) { return"<option value='" + a + "'>" + b + "</option>"; }

            function w(a, b, d) { return"<select class='" + a + "'" + (d ? " style='display:none;'" : "") + ">" + b + "</select>"; }

            function E(a, b) {
                a = e.find("tr.sf td.data " + a);
                a[0] != null && b(a);
            }

            function F(a, b) {
                var d = e.find("tr.sf td.data " + a);
                d[0] != null && jQuery.each(b, function() { this.data != null ? d.bind(this.type, this.data, this.fn) : d.bind(this.type, this.fn); });
            }

            var f = jQuery.extend({},
                    jQuery.fn.searchFilter.defaults, v),
                n = -1,
                r = "";
            jQuery.each(f.groupOps, function() { r += m(this.op, this.text); });
            r = "<select name='groupOp'>" + r + "</select>";
            e.html("").addClass("ui-searchFilter").append("<div class='ui-widget-overlay' style='z-index: -1'>&#160;</div><table class='ui-widget-content ui-corner-all'><thead><tr><td colspan='5' class='ui-widget-header ui-corner-all' style='line-height: 18px;'><div class='ui-closer ui-state-default ui-corner-all ui-helper-clearfix' style='float: right;'><span class='ui-icon ui-icon-close'></span></div>" +
                f.windowTitle + "</td></tr></thead><tbody><tr class='sf'><td class='fields'></td><td class='ops'></td><td class='data'></td><td><div class='ui-del ui-state-default ui-corner-all'><span class='ui-icon ui-icon-minus'></span></div></td><td><div class='ui-add ui-state-default ui-corner-all'><span class='ui-icon ui-icon-plus'></span></div></td></tr><tr><td colspan='5' class='divider'><div>&#160;</div></td></tr></tbody><tfoot><tr><td colspan='3'><span class='ui-reset ui-state-default ui-corner-all' style='display: inline-block; float: left;'><span class='ui-icon ui-icon-arrowreturnthick-1-w' style='float: left;'></span><span style='line-height: 18px; padding: 0 7px 0 3px;'>" +
                f.resetText + "</span></span><span class='ui-search ui-state-default ui-corner-all' style='display: inline-block; float: right;'><span class='ui-icon ui-icon-search' style='float: left;'></span><span style='line-height: 18px; padding: 0 7px 0 3px;'>" + f.searchText + "</span></span><span class='matchText'>" + f.matchText + "</span> " + r + " <span class='rulesText'>" + f.rulesText + "</span></td><td>&#160;</td><td><div class='ui-add-last ui-state-default ui-corner-all'><span class='ui-icon ui-icon-plusthick'></span></div></td></tr></tfoot></table>");
            var x = e.find("tr.sf"), G = x.find("td.fields"), y = x.find("td.ops"), o = x.find("td.data"), s = "";
            jQuery.each(f.operators, function() { s += m(this.op, this.text); });
            s = w("default", s, true);
            y.append(s);
            o.append("<input type='text' class='default' style='display:none;' />");
            var t = "", z = false, p = false;
            jQuery.each(l, function(a) {
                t += m(this.itemval, this.text);
                if (this.ops != null) {
                    z = true;
                    var b = "";
                    jQuery.each(this.ops, function() { b += m(this.op, this.text); });
                    b = w("field" + a, b, true);
                    y.append(b);
                }
                if (this.dataUrl != null) {
                    if (a > n)n = a;
                    p = true;
                    var d = this.dataEvents, c = this.dataInit, g = this.buildSelect;
                    jQuery.ajax(jQuery.extend({
                        url: this.dataUrl,
                        complete: function(h) {
                            h = g != null ? jQuery("<div />").append(g(h)) : jQuery("<div />").append(h.responseText);
                            h.find("select").addClass("field" + a).hide();
                            o.append(h.html());
                            c && E(".field" + a, c);
                            d && F(".field" + a, d);
                            a == n && e.find("tr.sf td.fields select[name='field']").change();
                        }
                    }, f.ajaxSelectOptions));
                } else if (this.dataValues != null) {
                    p = true;
                    var i = "";
                    jQuery.each(this.dataValues, function() { i += m(this.value, this.text); });
                    i = w("field" + a, i, true);
                    o.append(i);
                } else if (this.dataEvents != null || this.dataInit != null) {
                    p = true;
                    i = "<input type='text' class='field" + a + "' />";
                    o.append(i);
                }
                this.dataInit != null && a != n && E(".field" + a, this.dataInit);
                this.dataEvents != null && a != n && F(".field" + a, this.dataEvents);
            });
            t = "<select name='field'>" + t + "</select>";
            G.append(t);
            l = G.find("select[name='field']");
            z ? l.change(function(a) {
                var b = a.target.selectedIndex;
                a = jQuery(a.target).parents("tr.sf").find("td.ops");
                a.find("select").removeAttr("name").hide();
                b = a.find(".field" +
                    b);
                if (b[0] == null)b = a.find(".default");
                b.attr("name", "op").show();
            }) : y.find(".default").attr("name", "op").show();
            p ? l.change(function(a) {
                var b = a.target.selectedIndex;
                a = jQuery(a.target).parents("tr.sf").find("td.data");
                a.find("select, input").removeClass("vdata").hide();
                b = a.find(".field" + b);
                if (b[0] == null)b = a.find(".default");
                b.show().addClass("vdata");
            }) : o.find(".default").show().addClass("vdata");
            if (z || p)l.change();
            e.find(".ui-state-default").hover(C, C).mousedown(D).mouseup(D);
            e.find(".ui-closer").click(function() {
                f.onClose(jQuery(e.selector));
                return false;
            });
            e.find(".ui-del").click(function(a) {
                a = jQuery(a.target).parents(".sf");
                if (a.siblings(".sf").length > 0) {
                    f.datepickerFix === true && jQuery.fn.datepicker !== undefined && a.find(".hasDatepicker").datepicker("destroy");
                    a.remove();
                } else {
                    a.find("select[name='field']")[0].selectedIndex = 0;
                    a.find("select[name='op']")[0].selectedIndex = 0;
                    a.find(".data input").val("");
                    a.find(".data select").each(function() { this.selectedIndex = 0; });
                    a.find("select[name='field']").change();
                }
                return false;
            });
            e.find(".ui-add").click(function(a) {
                a =
                    jQuery(a.target).parents(".sf");
                var b = a.clone(true).insertAfter(a);
                b.find(".ui-state-default").removeClass("ui-state-hover ui-state-active");
                if (f.clone) {
                    b.find("select[name='field']")[0].selectedIndex = a.find("select[name='field']")[0].selectedIndex;
                    if (b.find("select[name='op']")[0] != null)b.find("select[name='op']").focus()[0].selectedIndex = a.find("select[name='op']")[0].selectedIndex;
                    var d = b.find("select.vdata");
                    if (d[0] != null)d[0].selectedIndex = a.find("select.vdata")[0].selectedIndex;
                } else {
                    b.find(".data input").val("");
                    b.find("select[name='field']").focus();
                }
                f.datepickerFix === true && jQuery.fn.datepicker !== undefined && a.find(".hasDatepicker").each(function() {
                    var c = jQuery.data(this, "datepicker").settings;
                    b.find("#" + this.id).unbind().removeAttr("id").removeClass("hasDatepicker").datepicker(c);
                });
                b.find("select[name='field']").change();
                return false;
            });
            e.find(".ui-search").click(function() {
                var a = jQuery(e.selector), b, d = a.find("select[name='groupOp'] :selected").val();
                b = f.stringResult ? '{"groupOp":"' + d + '","rules":[' : {
                    groupOp: d,
                    rules: []
                };
                a.find(".sf").each(function(c) {
                    var g = jQuery(this).find("select[name='field'] :selected").val(), i = jQuery(this).find("select[name='op'] :selected").val(), h = jQuery(this).find("input.vdata, select.vdata :selected").val();
                    h += "";
                    h = h.replace(/\\/g, "\\\\").replace(/\"/g, '\\"');
                    if (f.stringResult) {
                        if (c > 0)b += ",";
                        b += '{"field":"' + g + '",';
                        b += '"op":"' + i + '",';
                        b += '"data":"' + h + '"}';
                    } else b.rules.push({ field: g, op: i, data: h });
                });
                if (f.stringResult)b += "]}";
                f.onSearch(b);
                return false;
            });
            e.find(".ui-reset").click(function() {
                var a =
                    jQuery(e.selector);
                a.find(".ui-del").click();
                a.find("select[name='groupOp']")[0].selectedIndex = 0;
                f.onReset();
                return false;
            });
            e.find(".ui-add-last").click(function() {
                var a = jQuery(e.selector + " .sf:last"), b = a.clone(true).insertAfter(a);
                b.find(".ui-state-default").removeClass("ui-state-hover ui-state-active");
                b.find(".data input").val("");
                b.find("select[name='field']").focus();
                f.datepickerFix === true && jQuery.fn.datepicker !== undefined && a.find(".hasDatepicker").each(function() {
                    var d = jQuery.data(this, "datepicker").settings;
                    b.find("#" + this.id).unbind().removeAttr("id").removeClass("hasDatepicker").datepicker(d);
                });
                b.find("select[name='field']").change();
                return false;
            });
            this.setGroupOp = function(a) {
                selDOMobj = this.$.find("select[name='groupOp']")[0];
                var b = {}, d = selDOMobj.options.length, c;
                for (c = 0; c < d; c++)b[selDOMobj.options[c].value] = c;
                selDOMobj.selectedIndex = b[a];
                $(selDOMobj).change();
            };
            this.setFilter = function(a) {
                var b = a.sfref;
                a = a.filter;
                var d = [], c, g, i, h, j = {};
                selDOMobj = b.find("select[name='field']")[0];
                c = 0;
                for (i = selDOMobj.options.length; c <
                    i; c++) {
                    j[selDOMobj.options[c].value] = { index: c, ops: {} };
                    d.push(selDOMobj.options[c].value);
                }
                c = 0;
                for (i = d.length; c < i; c++) {
                    if (selDOMobj = b.find(".ops > select[class='field" + c + "']")[0]) {
                        g = 0;
                        for (h = selDOMobj.options.length; g < h; g++)j[d[c]].ops[selDOMobj.options[g].value] = g;
                    }
                    if (selDOMobj = b.find(".data > select[class='field" + c + "']")[0]) {
                        j[d[c]].data = {};
                        g = 0;
                        for (h = selDOMobj.options.length; g < h; g++)j[d[c]].data[selDOMobj.options[g].value] = g;
                    }
                }
                var u, q, A, B;
                d = a.field;
                if (j[d])u = j[d].index;
                if (u != null) {
                    q = j[d].ops[a.op];
                    if (q ===
                        undefined) {
                        c = 0;
                        for (i = v.operators.length; c < i; c++)
                            if (v.operators[c].op == a.op) {
                                q = c;
                                break;
                            }
                    }
                    A = a.data;
                    B = j[d].data == null ? -1 : j[d].data[A];
                }
                if (u != null && q != null && B != null) {
                    b.find("select[name='field']")[0].selectedIndex = u;
                    b.find("select[name='field']").change();
                    b.find("select[name='op']")[0].selectedIndex = q;
                    b.find("input.vdata").val(A);
                    if (b = b.find("select.vdata")[0])b.selectedIndex = B;
                    return true;
                } else return false;
            };
        }
    }

    return new I(this, k, H);
};
jQuery.fn.searchFilter.version = "1.2.9";
jQuery.fn.searchFilter.defaults = {
    clone: true,
    datepickerFix: true,
    onReset: function(k) { alert("Reset Clicked. Data Returned: " + k); },
    onSearch: function(k) { alert("Search Clicked. Data Returned: " + k); },
    onClose: function(k) { k.hide(); },
    groupOps: [{ op: "AND", text: "all" }, { op: "OR", text: "any" }],
    operators: [
        { op: "eq", text: "is equal to" }, { op: "ne", text: "is not equal to" }, { op: "lt", text: "is less than" }, { op: "le", text: "is less or equal to" }, { op: "gt", text: "is greater than" }, { op: "ge", text: "is greater or equal to" }, { op: "in", text: "is in" },
        { op: "ni", text: "is not in" }, { op: "bw", text: "begins with" }, { op: "bn", text: "does not begin with" }, { op: "ew", text: "ends with" }, { op: "en", text: "does not end with" }, { op: "cn", text: "contains" }, { op: "nc", text: "does not contain" }
    ],
    matchText: "match",
    rulesText: "rules",
    resetText: "Reset",
    searchText: "Search",
    stringResult: true,
    windowTitle: "Search Rules",
    ajaxSelectOptions: {}
};